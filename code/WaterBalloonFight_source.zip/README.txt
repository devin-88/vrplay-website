VRPLAY: Water Balloon Fight
Source archive, Devin Marais, University of Cape Town, 2026

Contents
  MyScripts/            All C# scripts written for the environment (29 files), with their Unity .meta files
  ProjectSettings/      Unity project settings, including the XR, input and physics configuration
  manifest.json         The package manifest (Packages/manifest.json) listing the packages and versions used

Built with Unity 6 (6000.3.17f1), the XR Interaction Toolkit and OpenXR, targeting the HTC Vive Pro.

Not included
  3D models, textures, audio, materials, scenes and prefabs. They are third-party or very large and are left out
  to keep this archive small. The scripts are complete and readable on their own; to run the environment the full
  Unity project is needed.
