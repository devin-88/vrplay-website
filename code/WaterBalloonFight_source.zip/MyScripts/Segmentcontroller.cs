using UnityEngine;
using System.Collections;

// controls the full sequence of events in the experience

public class SegmentController : MonoBehaviour
{

    public static event System.Action<string> SegmentStarted;

    [SerializeField] private NpcSkill npcSkill;
    [SerializeField] private SkillEvaluator playerSkillEvaluator;
    [SerializeField] private NpcAdvancedMoves npcAdvancedMoves;
    [SerializeField] private NpcSpeech npcSpeech;
    [SerializeField] private NpcAnimationDriver npcAnimationDriver;
    [SerializeField] private GameObject instructionPopup;
    [SerializeField] private GameObject bucketGlow;
    [SerializeField] private NpcController npcController;
    [SerializeField] private FadeScreen fadeScreen;

    [Header("Segment Durations (seconds)")]
    [SerializeField] private float initiationDuration = 30f;
    [SerializeField] private float familiarisationDuration = 30f;
    [SerializeField] private float evaluationDuration = 30f;
    [SerializeField] private float correctionDuration = 30f;
    [SerializeField] private float fairGamePlayDuration = 60f;
    [SerializeField] private float closingDuration = 15f;
    [SerializeField] private float closingFadeDelay = 3f; // pause before the fade to black occurs

    [Header("Rounds")]
    [SerializeField] private int totalRounds = 3;

    [Header("Initiation")]
    [SerializeField] private float introDelay = 5f; // time before intro audio starts
    [SerializeField] private float postIntroPause = 1f; // pause between the npc finishing its line and starting to throw
    [SerializeField] private float minimumIntroHold = 3f; // holds the npc still this long even if no intro clip is assigned yet

    private SkillEvaluator.PlayerClass currentPlayerClass = SkillEvaluator.PlayerClass.Novice;

    private void Start()
    {
        StartCoroutine(RunExperience());
    }

    private IEnumerator RunExperience() // yield forces everything to wait until that method is done
    {
        yield return Initiation();
        yield return Familiarisation();

        for (int round = 1; round <= totalRounds; round++)
        {
            Debug.Log("----- ROUND " + round + " -----");
            yield return Evaluation();
            yield return Correction();
            SetAdvancedMoveProbability(round);
            yield return FairGamePlay();
        }

        yield return Closing();
        Debug.Log("Experience Complete");
    }

    #region Segments

    private IEnumerator Initiation()
    {
        LogSegment("Initiation");
        SetNpcSkill(NpcSkill.SkillLevel.NoviceMinus);
        currentPlayerClass = SkillEvaluator.PlayerClass.Novice;
        ApplyPlayerAssists(SkillEvaluator.PlayerClass.Novice);
        SetAdvancedProbability(0f);

        yield return new WaitForSeconds(introDelay);
        float lineDuration = PlayIntroAudio();
        WaveAtPlayer();
        ShowInstructionPopup();
        GlowBucket();

        // hold the npc still until it has finished speaking and waving
        float introHold = Mathf.Max(lineDuration, minimumIntroHold) + postIntroPause;
        yield return new WaitForSeconds(introHold);

        StartNpcGameplay();

        float remaining = initiationDuration - introDelay - introHold;
        if (remaining > 0f)
        {
            yield return new WaitForSeconds(remaining);
        }

        HideInstructionPopup();
        StopBucketGlow();
    }

    private IEnumerator Familiarisation()
    {
        LogSegment("Familiarisation");
        SetNpcSkill(NpcSkill.SkillLevel.Novice);
        ApplyPlayerAssists(SkillEvaluator.PlayerClass.Novice);
        yield return new WaitForSeconds(familiarisationDuration);
    }

    private IEnumerator Evaluation()
    {
        LogSegment("Evaluation");
        SetNpcSkill(NpcSkill.SkillLevel.Intermediate);
        ApplyPlayerAssists(SkillEvaluator.PlayerClass.Novice);
        SetAdvancedProbability(0f); // to avoid npc intercepts from occurring which would skew the player's hit accuracy

        if (playerSkillEvaluator != null)
        {
            playerSkillEvaluator.BeginEval();
        }

        yield return new WaitForSeconds(evaluationDuration);

        if (playerSkillEvaluator != null)
        {
            currentPlayerClass = playerSkillEvaluator.EndEval();
        }
        Debug.Log("Player classified: " + currentPlayerClass);
    }

    private IEnumerator Correction()
    {
        LogSegment("Correction");

        int npcSkillLevel;
        if (currentPlayerClass == SkillEvaluator.PlayerClass.Expert)
        {
            npcSkillLevel = (int)currentPlayerClass + 1; // expert plus
        }
        else
        {
            npcSkillLevel = (int)currentPlayerClass - 1; // one below
        }

        SetNpcSkill((NpcSkill.SkillLevel)npcSkillLevel);
        ApplyPlayerAssists(currentPlayerClass);

        yield return new WaitForSeconds(correctionDuration);
    }

    private IEnumerator FairGamePlay()
    {
        LogSegment("Fair Game Play");
        SetNpcSkill((NpcSkill.SkillLevel)(int)currentPlayerClass);
        ApplyPlayerAssists(currentPlayerClass);
        yield return new WaitForSeconds(fairGamePlayDuration);
    }

    private IEnumerator Closing()
    {
        LogSegment("Closing");
        SetNpcSkill(NpcSkill.SkillLevel.Novice);
        ApplyPlayerAssists(currentPlayerClass);
        SetAdvancedProbability(0f);

        yield return new WaitForSeconds(closingDuration);

        PlayEndAudio();
        StopNpcThrowing();

        yield return new WaitForSeconds(closingFadeDelay);
        FadeToBlack();
    }

    #endregion

    #region Helper Methods

    private void SetNpcSkill(NpcSkill.SkillLevel npcSkillLevel)
    {
        if (npcSkill != null)
        {
            npcSkill.SetSkill(npcSkillLevel);
        }
    }

    private void ApplyPlayerAssists(SkillEvaluator.PlayerClass playerClass)
    {
        if (PlayerAssist.Instance != null)
        {
            PlayerAssist.Instance.SetProfile(playerClass);
        }
    }

    private void SetAdvancedMoveProbability(int round)
    {
        float prob = 0f;
        if (round == 2) prob = 0.3f;
        else if (round == 3) prob = 0.6f;
        SetAdvancedProbability(prob);
    }

    private void SetAdvancedProbability(float prob)
    {
        if (npcAdvancedMoves != null)
        {
            npcAdvancedMoves.SetAdvancedProbability(prob);
        }
    }

    private void StartNpcGameplay()
    {
        if (npcController != null)
        {
            npcController.ReleaseHold();
        }
    }

    private void LogSegment(string segmentName)
    {
        Debug.Log("Segment: " + segmentName);
        SegmentStarted?.Invoke(segmentName);
    }

    #endregion

   #region Scene Effects

    private float PlayIntroAudio()
    {
        if (npcSpeech != null)
        {
            return npcSpeech.PlayIntro();
        }
        return 0f;
    }

    private void PlayEndAudio()
    {
        if (npcSpeech != null)
        {
            npcSpeech.PlayClosing();
        }
    }

    private void WaveAtPlayer()
    {
        if (npcAnimationDriver != null)
        {
            npcAnimationDriver.PlayWave();
        }
    }

    private void ShowInstructionPopup()
    {
        if (instructionPopup != null)
        {
            instructionPopup.SetActive(true);
        }
    }

    private void HideInstructionPopup()
    {
        if (instructionPopup != null)
        {
            instructionPopup.SetActive(false);
        }
    }

    private void GlowBucket()
    {
        if (bucketGlow != null)
        {
            bucketGlow.SetActive(true);
        }
    }

    private void StopBucketGlow()
    {
        if (bucketGlow != null)
        {
            bucketGlow.SetActive(false);
        }
    }

    private void StopNpcThrowing()
    {
        if (npcController != null)
        {
            npcController.HoldStanding(); // same hold used during the opening, so the npc stands and stops playing
        }
    }

    private void FadeToBlack()
    {
        if (fadeScreen != null)
        {
            fadeScreen.FadeToBlack();
        }
    }

    #endregion
}