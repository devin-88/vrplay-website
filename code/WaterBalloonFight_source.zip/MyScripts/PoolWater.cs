using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

// handles a balloon entering the pool

[RequireComponent(typeof(Collider))]
public class PoolWater : MonoBehaviour
{
    #region Inspector Fields
    [Header("Entry Effects")]
    [SerializeField] private GameObject splashEffect; 
    [SerializeField] private AudioClip splashSound; 
    [SerializeField] private float splashScale = 1.5f; 
    [SerializeField] private float splashLifetime = 3f; 

    [Header("Sinking")]
    [SerializeField] private float waterLinearDamping = 10f; // resistance of the water to movement
    [SerializeField] private float waterAngularDamping = 5f; // resistance of the water to spinning
    [SerializeField] private float destroyAfterSeconds = 8f; // how long a sunk balloon rests on the floor before being removed
    [SerializeField] private float entrySpeedRetained = 0.12f; // fraction of the balloon's speed kept when it hits the water
    [SerializeField] private float splashHeightOffset = 0.05f; // lifts the splash just above the waterline
    #endregion

    private Collider waterVolume;

    private void Awake()
    {
        waterVolume = GetComponent<Collider>();
    }

    private void OnTriggerEnter(Collider enteringObject)
    {
        Debug.Log("PoolWater trigger fired by: " + enteringObject.gameObject.name);
        BalloonBreak balloon = enteringObject.GetComponent<BalloonBreak>();
        if (balloon == null)
        {
            return; // only balloons are handled here
        }

        Rigidbody rb = enteringObject.GetComponent<Rigidbody>();
        if (rb == null)
        {
            return; // only something with a rigidbofy can sink
        }

        // ignore a balloon the player is currently holding over the water
        XRGrabInteractable grabbable = enteringObject.GetComponent<XRGrabInteractable>();
        if (grabbable != null && grabbable.isSelected)
        {
            return;
        }

        // the balloon will now settle on the pool floor rather than popping against it.
        balloon.DisableBursting();

        PlayEntryEffects(enteringObject.transform.position);

        // The water slows the balloon rather than gravity being ignored
        rb.linearDamping = waterLinearDamping;
        rb.angularDamping = waterAngularDamping;
        // water takes most of the entry speed away immediately
        rb.linearVelocity *= entrySpeedRetained;
        rb.angularVelocity *= entrySpeedRetained;

        Destroy(enteringObject.gameObject, destroyAfterSeconds);
    }

    private void PlayEntryEffects(Vector3 balloonPosition)
    {
        // the trigger fires a little below the surface, so lift the effect back up to the waterline
        Vector3 entryPoint = new Vector3(balloonPosition.x, waterVolume.bounds.max.y + splashHeightOffset, balloonPosition.z);

        if (splashEffect != null)
        {
            GameObject splash = Instantiate(splashEffect, entryPoint, Quaternion.identity);
            splash.transform.localScale *= splashScale;

            ParticleSystem particles = splash.GetComponentInChildren<ParticleSystem>();
            if (particles != null)
            {
                particles.Play(true);
            }

            Destroy(splash, splashLifetime);
        }

        if (splashSound != null)
        {
            AudioSource.PlayClipAtPoint(splashSound, entryPoint);
        }
    }
}