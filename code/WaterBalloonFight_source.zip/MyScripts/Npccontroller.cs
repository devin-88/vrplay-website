using UnityEngine;

// class to control the npc states

public class NpcController : MonoBehaviour
{
    public enum NpcState{Hiding, Stalking, Throwing, SideThrowing, Intercepting, Ducking}

    // add throwing event for animator
    public event System.Action<NpcAdvancedMoves.AdvancedMove?> OnThrowStarted; // carries either null or an advanced move

    #region Inspector Fields
    [SerializeField] private NpcThrower thrower;
    [SerializeField] private ThreatDetector threatDetector;
    [SerializeField] private OpportunityDetector opportunityDetector;
    [SerializeField] private NpcAdvancedMoves advancedMoves;
    [SerializeField] private Transform body;

    [Header("Timing")]
    [SerializeField] private float hideDuration = 1.5f;
    [SerializeField] private float stalkDuration = 3f;
    [SerializeField] private float reactionTime = 0.5f; // changes per state - see the setter below
    [SerializeField] private float throwInterval = 3f;

    [Header("Duck/Stand")]
    [SerializeField] private float duckDepth = 0.4f; // how far below spawn head height the ducking position is
    [SerializeField] private float moveSpeed = 6f; 

    [Header("Stand Position Variation")]
    [SerializeField] private float standDriftSideways = 0.25f; // metres either side of the original stand point
    [SerializeField] private float standDriftForward = 0.1f; // metres forward or back

    [Header("Side Throw")]
    [SerializeField] private float sideOffset = -1f; // how much the npc moves to the side, and direction from minus sign
    [SerializeField] private float sideThrowTimeout = 1.5f; // how long the npc will stay in side throw state without throwing before retreating

    [Header("Intercepting Throw")]
    [SerializeField] private float pauseAfterInterceptDuration = 0.3f; // how long stay standing after throwing intercept move
    
    [Header("Wait For Animations to Finish")]
    [SerializeField] private float maxWaitForReleaseDuration = 2f; // max time we will give a release to occur before ducking
    #endregion

    #region Runtime Variables
    private const float closeEnoughToSideThrowPosition = 0.05f; // how close the npc needs to be to the side throw position to throw

    private NpcState state = NpcState.Hiding; // starting npc state
    public NpcState CurrentState => state; // so its accessible for the animator
    public bool SideThrowStanding => (state == NpcState.SideThrowing && throwExecuted); // for the animator, so it knows when npc is standing in the side throw move
    private float timer = 0f; // running timer
    private float reactionTimer = 0f; // measures time elapsed since a stimulus (threat or opportunity) was identified
    private float lastThrowTime = -999f; // when the npc last threw, used for cooldowns 
    private Vector3 standPosition;
    private Vector3 standDrift = Vector3.zero; // rerolled each time the npc rises, so it does not always pop up in the same place
    private Vector3 sideStandPosition; // for the standing position when throwing in the side throw
    private Vector3 duckPosition;
    private Vector3 sidePosition;
    private bool hold = true;
    public bool IsHeldStanding => hold;

    private NpcAdvancedMoves.AdvancedMove? pendingActionMove = null;

    private bool throwExecuted = false; // meaning "throw started" or "throw signal sent"
    private bool throwFinished = false; // if end of animation event triggered
    private bool throwReleased = false; // if the animation event triggered

    public int SideMovement
    { // 0 = not moving side ways, 1 = moving side ways out to pos, 2 = moving side ways back behind barrier (for the animator)
        get
        {
            if (state == NpcState.SideThrowing && !throwExecuted)
            {
                return 1; // hasn't thrown yet, still on the way to throwing pos
            }
            if (state == NpcState.Ducking)
            {
                Vector3 toDuckPos = DuckTarget() - body.localPosition;
                toDuckPos.y = 0; // measuring horizontal distance only
                if (toDuckPos.magnitude > closeEnoughToSideThrowPosition)
                {
                    return 2; // has thrown, but isn't at duck pos yet
                }
            }
            return 0;
        }
    }
    #endregion

    #region Setters
    public void SetReactionTime(float seconds) {reactionTime = seconds;}
    public void SetThrowInterval(float seconds) {throwInterval = seconds;}
    public void ReleaseHold()
    {
        hold = false;
        timer = 0f; // start the hiding cycle cleanly rather than partway through
    }

    public void HoldStanding()
    {
        hold = true;
        state = NpcState.Hiding; // so gameplay resumes from the start of the cycle when released
        timer = 0f;
    }
    #endregion

    #region Start
    private void Start()
    {
        standPosition = body.localPosition;
        duckPosition = standPosition - Vector3.up*duckDepth;
        sidePosition = duckPosition + Vector3.right*sideOffset; // move out at same height as when ducking
        sideStandPosition = standPosition + Vector3.right*sideOffset; // move out to side throwing position at the standing height
    }
    #endregion

    #region State Cases
    private void Update() // runs every frame
    {
        if (hold)
        {
            MoveBodyTowards(standPosition); // keep it standing
            return;
        }
        timer += Time.deltaTime; // increment by the time between the previous and current frame

        // begin the state switching
        switch(state)
        {
            case NpcState.Hiding:
            {
                MoveBodyTowards(DuckTarget());
                if (timer >= hideDuration)
                {
                    // time to come out of hiding - select the next move before so
                    // must choose before in case of a side throw, which never stands up (ie. comes out of hiding in the standard sense)
                    NpcAdvancedMoves.AdvancedMove? chosenMove = null; // reset the chosen moven
                    if (advancedMoves != null)
                    {
                        chosenMove = advancedMoves.ChooseMove();
                    }
                    bool offCd = ((Time.time - lastThrowTime) >= throwInterval);

                    if (chosenMove == NpcAdvancedMoves.AdvancedMove.SideThrow && offCd)
                    {
                        pendingActionMove = null;
                        ChangeState(NpcState.SideThrowing);
                    }
                    else
                    {
                        // if it's a side throw, discard it because we're not off cooldown (the side throw doesnt wait for an opportunity)
                        if (chosenMove == NpcAdvancedMoves.AdvancedMove.SideThrow)
                        {
                            chosenMove = null;
                        }
                        pendingActionMove = chosenMove;
                        ChangeState(NpcState.Stalking);
                    }
                }
                break;
            }
            case NpcState.Stalking:
            {
                MoveBodyTowards(StandTarget());

                bool threatPresent = (threatDetector != null && threatDetector.ThreatIncoming());
                bool opportunityPresent = (opportunityDetector != null && opportunityDetector.IsOpportunity());
                bool offCd = ((Time.time - lastThrowTime) >= throwInterval);
                // priority: 1 = threat, 2 = opportunity
                if (threatPresent)
                {
                    reactionTimer += Time.deltaTime;
                    if (reactionTimer >= reactionTime)
                    {
                        Rigidbody incomingBalloon = threatDetector.GetIncomingBalloon();
                        Debug.Log("DOING CHECK");
                        bool interceptSelected = (
                            incomingBalloon != null &&
                            advancedMoves != null &&
                            advancedMoves.ShouldIntercept() && // do the prob roll
                            advancedMoves.CanInterceptInTime(incomingBalloon)
                        ); // definitive bool indicating if the intercept will occur

                        if (interceptSelected)
                        {
                            pendingActionMove = NpcAdvancedMoves.AdvancedMove.Intercept; // any other advanced move is overwritten, because threat matters more than opportunity
                            ChangeState(NpcState.Throwing);
                            Debug.Log("INTERCEPT CHOSEN " + Time.time);
                        }
                        else
                        {
                            Debug.Log("DUCKING FOR THREAT");
                            ChangeState(NpcState.Ducking);
                        }
                    }
                }
                else if (opportunityPresent && offCd)
                {
                    reactionTimer += Time.deltaTime;
                    if (reactionTimer >= reactionTime)
                    {
                        ChangeState(NpcState.Throwing); // make a throw
                    } // otherwise remain in stalking state
                }
                else
                {
                    reactionTimer = 0f; // nothing to react to (no stimulus) so reset reactionTimer
                    if (timer >= stalkDuration)
                    {
                        ChangeState(NpcState.Ducking);
                    }
                }
                break;
            }
            case NpcState.Throwing:
            {
                if (!throwExecuted) // check that no throw occurred
                {
                    OnThrowStarted?.Invoke(pendingActionMove);
                    pendingActionMove = null; // reset it
                    throwExecuted = true;
                }

                MoveBodyTowards(StandTarget());
                if (throwFinished)
                {
                    reactionTimer += Time.deltaTime;
                    if (reactionTimer >= reactionTime)
                    {
                        ChangeState(NpcState.Ducking);
                    }
                }
                else if (timer >= maxWaitForReleaseDuration) // fail safe
                {
                    if (!throwReleased)
                    {
                        Debug.Log("Throw release event didnt fire");
                    }
                    ChangeState(NpcState.Ducking);
                }
                break;
            }
            case NpcState.SideThrowing:
            {
                if (!throwExecuted)
                {
                    MoveBodyTowards(sidePosition); // npc isn't throwing, so move to side position at the duck height level
                }
                else
                {
                    MoveBodyTowards(sideStandPosition); // npc is throwing, which happens when standing, so must stand up
                }

                if (!throwExecuted && (Vector3.Distance(body.localPosition, sidePosition) < closeEnoughToSideThrowPosition || timer >= sideThrowTimeout))
                {
                    // hasn't thrown yet, but has reached the horizontal pos, so it now needs to stand and throw
                    Debug.Log("SIDE THROW");
                    OnThrowStarted?.Invoke(NpcAdvancedMoves.AdvancedMove.SideThrow);
                    throwExecuted = true;
                }

                if (throwExecuted)
                {
                    if (throwFinished)
                    {
                        reactionTimer += Time.deltaTime;
                        if (reactionTimer >= reactionTime)
                        {
                            ChangeState(NpcState.Ducking);
                        }
                    }
                    else if (timer >= maxWaitForReleaseDuration + sideThrowTimeout)
                    {
                        if (!throwReleased)
                        {
                            Debug.Log("Side throw never released");
                        }
                        ChangeState(NpcState.Ducking);
                    }
                }
                break;
            }
            case NpcState.Intercepting:
            {
                MoveBodyTowards(StandTarget());
                if (timer >= pauseAfterInterceptDuration) // so that the npc watches the intercept happen (realism)
                {
                    ChangeState(NpcState.Ducking);
                }
                break;
            }
            case NpcState.Ducking:
            {
                MoveBodyTowards(DuckTarget());
                if (body.localPosition == DuckTarget())
                {
                    ChangeState(NpcState.Hiding);
                }
                break;
            }
        }
    }
    #endregion

    #region State Changer
    private void ChangeState(NpcState newState)
    {
        state = newState;
        timer = 0f; // reset the timer
        reactionTimer = 0f; // reset reaction timer (time since last stimulus detected)
        throwExecuted = false; // reset
        throwReleased = false; // reset
        throwFinished = false; // reset
        if (newState == NpcState.Hiding)
        {
            RerollStandDrift(); // a new spot each time the npc comes up
        }
    }
    #endregion

    #region Body Movers
    private void MoveBodyTowards(Vector3 targetPosition)
    {
        body.localPosition = Vector3.MoveTowards(body.localPosition, targetPosition, moveSpeed*Time.deltaTime);
    }

    // the original stand point plus a small random offset (to add variation to npc position)
    private Vector3 StandTarget()
    {
        return standPosition + standDrift;
    }

    private Vector3 DuckTarget()
    {
        return duckPosition + standDrift;
    }

    private void RerollStandDrift()
    {
        standDrift = new Vector3(
            Random.Range(-standDriftSideways, standDriftSideways),
            0f, // height is set by the duck/stand system, so leave it alone
            Random.Range(-standDriftForward, standDriftForward)
        );
    }
    #endregion
 
    #region Animator Methods

    public void ReleaseThrow(NpcAdvancedMoves.AdvancedMove? move, int hand) // gets called during the animation's play through
    {
        if (state != NpcState.Throwing && state!= NpcState.SideThrowing)
        {
            Debug.Log("release arrived but state was " + state);
            return; // the fail safe fired, and the npc has already ducked, so dont throw
        }

        throwReleased = true;

        if (move == null)
        {
            if (thrower != null) // standard throw
            {
                thrower.ThrowBalloon();
                lastThrowTime = Time.time; // for the cooldown calculations
            }
        }
        else if (move == NpcAdvancedMoves.AdvancedMove.Intercept)
        {
            Rigidbody incomingBalloon = null;
            if (threatDetector != null)
            {
                incomingBalloon = threatDetector.GetIncomingBalloon();
            }
            bool intercepted = false;
            if (incomingBalloon != null && advancedMoves != null)
            {
                intercepted = advancedMoves.ExecuteIntercept(incomingBalloon);
            }
            if (intercepted)
            {
                ChangeState(NpcState.Intercepting);
            }
            else
            {
                ChangeState(NpcState.Ducking); // threat gone, hence duck 
            }
        }
        else if (move == NpcAdvancedMoves.AdvancedMove.SideThrow)
        {
            if (thrower != null)
            {
                thrower.ThrowBalloon(); // a standard throw, just from the side throwing position
                lastThrowTime = Time.time; // for the cooldown, resets when the throw is made exactly
            }
        }
        else
        {
            // let the other advanced moves (which are all offensive) happen
            if (advancedMoves != null)
            {
                advancedMoves.ExecuteThrowGeneric(move.Value, hand);
                lastThrowTime = Time.time;
            }
        }
    }

    public void ThrowCompleted(NpcAdvancedMoves.AdvancedMove? move)
    {
        if (state != NpcState.Throwing && state != NpcState.SideThrowing)
        {
            return; // the state has been moved, so don't need to change the animation here anymore
        }
        throwFinished = true;
    }

    #endregion
}