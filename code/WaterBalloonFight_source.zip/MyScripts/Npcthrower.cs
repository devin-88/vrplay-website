using UnityEngine;

// handles the throwing mechanics of the npc

public class NpcThrower : MonoBehaviour
{

    public static event System.Action NpcThrew;

    #region Properties and Fields
    [SerializeField] private GameObject balloonPrefab;
    [SerializeField] private Transform mainHand; // npc's left hand (in the actual VE)
    [SerializeField] private Transform offHand; // npc's right hand (in the actual VE)
    [SerializeField] private Transform target; // the player's head (main camera)

    [Header("Aiming")]
    [SerializeField] private Vector3 targetOffset = new Vector3(0f, -0.35f, 0f); // arbitrarily chosen offset from player head
    [SerializeField] private float groundYPosition = 0f; // where the ground starts (used by the slingshot throws which aim for the ground)

    [Header("Difficulty Levers")]
    [SerializeField] private float flightTime = 1f; // time balloon takes to land
    [SerializeField] private float throwSpread = 0f; // range of angles the npc can throw the balloon in, centred at the aim point (target)
    [Range(0f, 1f)] [SerializeField] private float comicalDeliberateMissRate = 0f; // likelihood of making a deliberate miss throw for comical effect
    [SerializeField] private float comicalDeliberateMissAngle = 35f; // how many degrees off the aim point the throw is

    public void SetFlightTime(float seconds) { flightTime = seconds; }
    public void SetThrowSpread(float degrees) { throwSpread = degrees; }
    public void SetComicalDeliberateMissRate(float rate) { comicalDeliberateMissRate = rate; }

    #endregion

    private Vector3 AimPoint() // gives the actual aim point (the player's torso)
    {
        return target.position + targetOffset; 
    }

    #region Normal Throws
    public void ThrowBalloon() // variant 1 (no args, uses class flight time)
    {
        ThrowBalloon(flightTime);
    }

    public void ThrowBalloon(float givenFlightTime) // variant 2 (uses a specific flight time)
    {
        if (target == null)
        {
            return;
        }

        PerformThrow(mainHand, AimPoint(), givenFlightTime);
    }
    #endregion

    #region Helper Methods
    private Vector3 OffsetAim(Vector3 throwOrigin, Vector3 originalAimPoint, float angularError, bool deliberateMiss)
    {
        // changes the npc's aim point from the player's torso, to provide variation in the npc throws
        // also enables us to implement the throw spread and deliberate misses
        // hence, provides variation and implements npc difficulty levers
        // converts an angle into a displacement of the original aim point 
        // creates a circle around the original aim point, then selects a point in that circle to be the new aim point

        if (angularError <= 0f)
        {
            return originalAimPoint; // don't need to change the aim point
        }

        Vector3 forward = originalAimPoint - throwOrigin; // vector from throwOrigin to the aim point (npc to player)
        float distance = forward.magnitude;
        if (distance < 0.01f)
        {
            return originalAimPoint; // basically no distance between the points, don't entertain further
        }
        forward/=distance;
        // create xy plane for the disk
        // right = x plane, up = y plane, forward = z plane
        Vector3 discRight = Vector3.Cross(Vector3.up, forward);
        if (discRight.sqrMagnitude < 0.001f)
        {
            discRight = Vector3.right; // line throw is near vertical so just make disc right the same as the world right
        }
        discRight.Normalize(); // need to make the right vector length one (if the angle between Vector3.up and forward isnt 90 degrees, then right isnt length 1)
        Vector3 discUp = Vector3.Cross(forward, discRight);
        // don't need to normalize up because forward and right are already 90 degrees apart

        float radius = distance*Mathf.Tan(angularError*Mathf.Deg2Rad); // the opposite side of the right triangle made with the throw line and angle 
        // Tan requires for angle to be in radians

        if (deliberateMiss)
        {
            float side = 1f;
            if (Random.value < 0.5f)
            {
                side = -1f;
            }
            return (originalAimPoint + discRight*radius*side); // change the aim point to be the extreme left or extreme right (9am or 3pm clock positions)
        }

        Vector2 disc = Random.insideUnitCircle; // chooses random xy point in the unit circle (which has radius of 1)
        return (originalAimPoint + discRight*(disc.x*radius) + discUp*(disc.y*radius)); // scale the unit circle coord by the radius of the actual disc
    }

    private Rigidbody SpawnNpcBalloon(Transform npcHand) // spawn a balloon that can burst into the npc's hand
    {
        GameObject balloon = Instantiate(balloonPrefab, npcHand.position, Quaternion.identity);
        BalloonBreak breakScript = balloon.GetComponent<BalloonBreak>();
        if (breakScript != null)
        {
            breakScript.EnableBursting(); // npc never selects the balloon, hence balloon won't be set to burstable through selectExited
        }
        NpcThrew?.Invoke();
        return balloon.GetComponent<Rigidbody>();
    }

    private Vector3 CalculateLaunchVelocity(Vector3 throwOrigin, Vector3 target, float givenFlightTime)
    {
        // using displacement = velocity*time + 0.5*acceleration*time*time
        // rearrange to be velocity = displacement/time - 0.5*acceleration*time
        // gravity is the only force acting on the balloon once in the air, hence gravity = acceleration here

        Vector3 displacement = target - throwOrigin; // vector from throwOrigin to target
        return (displacement/givenFlightTime - 0.5f*Physics.gravity*givenFlightTime);
    }

    private void PerformThrow(Transform npcHand, Vector3 originalAimPoint, float givenFlightTime)
    {
        if (balloonPrefab == null || npcHand == null)
        {
            return; // don't throw
        }

        Vector3 finalAimPoint;

        // determine if it will be a deliberate miss throw, or a standard throw
        if (Random.value < comicalDeliberateMissRate)
        {
            finalAimPoint = OffsetAim(npcHand.position, originalAimPoint, comicalDeliberateMissAngle, true);
            Debug.Log("Deliberate miss");
        }
        else
        {
            finalAimPoint = OffsetAim(npcHand.position, originalAimPoint, throwSpread, false);
        }

        Rigidbody rb = SpawnNpcBalloon(npcHand); // spawn a balloon that can burst in the npc's hand
        if (rb == null)
        {
            return; // don't throw
        }

        rb.linearVelocity = CalculateLaunchVelocity(npcHand.position, finalAimPoint, givenFlightTime);
    }
    #endregion

    #region Advanced Moves

    public void HighThrow(float givenFlightTime, float landInFrontBy)
    // this throw goes very high in the air and lands in front of the player (onto the ground)
    // chose to land it in front, because the player could not detect the high throw occurred otherwise
    {
        if (target == null || mainHand == null)
        {
            return; // don't throw
        }
        
        if (landInFrontBy <= 0f) // aim at the player as usual
        {
            PerformThrow(mainHand, AimPoint(), givenFlightTime);
            return; 
        }

        Vector3 toTarget = target.position - mainHand.position; // vector from npc's hand to the player's position (direction vector)
        toTarget.y = 0f; // flatten the direction of the aim to be horizontal, so that the change in aim point is purely horizontal (xz plane)

        Vector3 aim = target.position; // position vector
        // the check below prevents division by zero in .normalized (even though Unity prevents against it itself), so it's a double check essentially
        // is sqrMagnitude is <= 0.0001, then the aim and toTarget lie on the same xz plane hence (0, 0, 0) in toTarget, which has length 0 therefore divisor of 0
        if (toTarget.sqrMagnitude > 0.0001f) // magnitude returns the sqr root magnitude (true magnitude) which is more expensive, so just use sqr of it and sqr of the threshold of 0.1
        {
            aim -= toTarget.normalized*landInFrontBy; // move the aim point to be closer to the throw origin, so it lands in front of the player
        }
        aim.y = groundYPosition; // move the aim point to be onto the ground

        PerformThrow(mainHand, aim, givenFlightTime);
    }

    public void TwoHandedThrowHalf(float lateralOffset, int hand) // to perform the two handed throw, have to do two animations each with a different hand and aim point
    {
        // hand = 0 = mainHand and hand = 1 = offHand
        // use the lateral offset so that the balloons aim to either side of the player, aligned with that hand (ie. left hand throw veers left)
        if (target == null || mainHand == null)
        {
            return; // don't throw
        }

        if (offHand == null)
        {
            ThrowBalloon(); // default to standard throw
            return;
        }

        Vector3 aimCentre = AimPoint(); // aim point of the throw
        Vector3 toTarget = aimCentre - mainHand.position; // direction vector from main hand to the aim point
        toTarget.y = 0f; // focus on the xz plane
        // we need each balloon to veer to the side of its releasing hand, but we need a robust way of determining which side each hand is on
        // we need some reference vector to do this, so we use the lateral vector below
        // vector pointing to the left or right of the toTarget vector (perp to world up and toTarget)
        Vector3 lateral = Vector3.Cross(Vector3.up, toTarget).normalized; 

        // anything pointing in the same direction as lateral = positive side
        // anything pointing in opposite direction of lateral = negative side
        // dot product can tell us if two vectors point in the same direction (positive = same dir, negative = opposite dir)
        // we only care about signs here, hence use Mathf.Sign = {-1, 0, 1}
        float offHandSide = Mathf.Sign(Vector3.Dot(offHand.position - mainHand.position, lateral));
        // if positive 1, then vector from main hand to off hand has same direction as lateral, meaning off hand is on the positive side
        // if negative 1, then off hand is on the negative side
        // if 0 then they are perp, the vector between the two hands is parallel to throw line (toTarget)
        // meaning the two hands are stacked vertically (= to world up which is perp to lateral), directly behind or in front each other in line with toTarget
        // or the vector between the two hands is zero (meaning the hands are at the same position)
        // if 0, we still want the balloons to veer in opposite directions, so we arbitrarily assign a value to the offHandSide
        if (offHandSide == 0f)
        {
            offHandSide = 1; // arbitrary choice
        }

        Vector3 aim;
        if (hand == 1)
        {
            // offHand
            aim = aimCentre + lateral*lateralOffset*offHandSide;
            PerformThrow(offHand, aim, flightTime);
        }
        else
        {
            // mainHand
            aim = aimCentre - lateral*lateralOffset*offHandSide;
            PerformThrow(mainHand, aim, flightTime);
        }
    }

    public void TwoHandedThrow(float lateralOffset) // throw two balloons, one in each hand, at the same time
    // needs a lateral offset so that the two balloons don't collide with each other during their flight
    {
        if (target == null || mainHand == null)
        {
            return; // don't throw
        }

        if (offHand == null)
        {
            ThrowBalloon(); // default to a regular throw
            return;
        }

        Vector3 aimCentre = AimPoint(); // aim point of the throw
        Vector3 toTarget = aimCentre - mainHand.position; // direction vector from main hand to the aim point
        toTarget.y = 0f; // focus on the xz plane
        // we need each balloon to veer to the side of its releasing hand, but we need a robust way of determining which side each hand is on
        // we need some reference vector to do this, so we use the lateral vector below
        // vector pointing to the left or right of the toTarget vector (perp to world up and toTarget)
        Vector3 lateral = Vector3.Cross(Vector3.up, toTarget).normalized; 

        // anything pointing in the same direction as lateral = positive side
        // anything pointing in opposite direction of lateral = negative side
        // dot product can tell us if two vectors point in the same direction (positive = same dir, negative = opposite dir)
        // we only care about signs here, hence use Mathf.Sign = {-1, 0, 1}
        float offHandSide = Mathf.Sign(Vector3.Dot(offHand.position - mainHand.position, lateral));
        // if positive 1, then vector from main hand to off hand has same direction as lateral, meaning off hand is on the positive side
        // if negative 1, then off hand is on the negative side
        // if 0 then they are perp, the vector between the two hands is parallel to throw line (toTarget)
        // meaning the two hands are stacked vertically (= to world up which is perp to lateral), directly behind or in front each other in line with toTarget
        // or the vector between the two hands is zero (meaning the hands are at the same position)
        // if 0, we still want the balloons to veer in opposite directions, so we arbitrarily assign a value to the offHandSide
        if (offHandSide == 0f)
        {
            offHandSide = 1; // arbitrary choice
        }

        // create the two opposite aims, the + and - ensure they always veer in opposite directions (hence never collide)
        Vector3 mainHandAim = aimCentre - lateral*lateralOffset*offHandSide;
        Vector3 offHandAim = aimCentre + lateral*lateralOffset*offHandSide;

        PerformThrow(mainHand, mainHandAim, flightTime);
        PerformThrow(offHand, offHandAim, flightTime);
    }

    public bool CanInterceptInTime(Rigidbody incomingBalloon, float releaseDelay, float minTimeToIntercept)
    {
        // determines if an intercept throw is feasible at the point where the balloon would be released during the throw animation
        // release delay = time for the throw animation wind up to occur
        if (mainHand == null || incomingBalloon == null)
        {
            return false; // can't do the throw
        }

        Vector3 toNpc = mainHand.position - incomingBalloon.position; // direction vector from balloon to npc
        // use horizontal velocity and distance to calculate exact landing time
        toNpc.y = 0; // only horizontal plane
        Vector3 horizontalVelocity = incomingBalloon.linearVelocity;
        horizontalVelocity.y = 0;
        float horizontalSpeed = horizontalVelocity.magnitude;

        if (horizontalSpeed < 0.01f)
        {
            return false; // the balloon throw is too weak for the intercept to seem necessary
        }

        float timeToArrive = toNpc.magnitude/horizontalSpeed;
        float needed = releaseDelay + minTimeToIntercept;
        Debug.Log("intercept gate: timeToArrive = " + timeToArrive + ", needed = " + needed);

        return (timeToArrive >= (releaseDelay + minTimeToIntercept)); // enough time to intercept with the animation delay taken into account
    }

    public bool InterceptThrow(Rigidbody incomingBalloon, float interceptFraction, float minTimeToIntercept)
    // throw a balloon at an incoming balloon to intercept the throw
    // the intercept happens at some point during the incoming balloon's flight (at some fraction of the time remaining before it lands)
    // we set some minimum time to intercept which indicates if the intercept can be made feasibly, without making an intercepting throw that seems unrealistic (realism)
    {
        if (balloonPrefab == null || mainHand == null || incomingBalloon == null)
        {
            return false; // don't throw
        }

        // we need to calculate the time it will take for the incoming balloon to arrive, to know if the intercept is feasible
        // we will use the horizontal component of the incoming balloon's velocity because it is constant whereas the vertical has gravity on it (hence, not constant)
        Vector3 toNpc = mainHand.position - incomingBalloon.position; // vector from balloon to npc
        toNpc.y = 0; // make the vector horizontal

        // extract the horizontal velocity of the incoming balloon
        Vector3 horizontalVelocity = incomingBalloon.linearVelocity;
        horizontalVelocity.y = 0; // make it only horizontal
        float horizontalSpeed = horizontalVelocity.magnitude;

        if (horizontalSpeed < 0.01f)
        {
            return false; // the balloon is going too slow, not much to intercept
        }

        float timeToArrive = toNpc.magnitude/horizontalSpeed; // using time = displacement/speed

        if (timeToArrive < minTimeToIntercept)
        {
            return false; // cannot perform the intercept in time
        }

        // determine what time along the incoming balloon's path it should be intercepted
        float interceptTime = Mathf.Max(timeToArrive*interceptFraction, 0.01f); // 0.01 is just a fail safe (this code shouldn't ever run, but it's just here in case)

        // predict the location the balloon will be at, at interceptTime
        // using change in displacement = velocity*time + 0.5*acceleration*time*time (where acceleration is just gravity)
        // and change is displacement = position at time seconds - starting position
        Vector3 predictedPosition = incomingBalloon.position
                                    + incomingBalloon.linearVelocity*interceptTime
                                    + 0.5f*Physics.gravity*interceptTime*interceptTime;
        
        // spawn the intercepting balloon and throw
        Rigidbody rb = SpawnNpcBalloon(mainHand);
        if (rb == null)
        {
            return false; // fail safe
        }
        rb.linearVelocity = CalculateLaunchVelocity(mainHand.position, predictedPosition, interceptTime);
        return true;
    }

    #endregion
}