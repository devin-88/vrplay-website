using UnityEngine;

// plays the npc's scripted spoken lines

public class NpcSpeech : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private AudioSource voiceSource; // the VoiceSource child

    [Header("Scripted Lines")]
    [SerializeField] private AudioClip introLine;
    [SerializeField] private AudioClip closingLine;
    #endregion

    #region Methods
    // returns how many seconds the line lasts, for throwing and fade to black waiting purposes
    public float PlayIntro()
    {
        return PlayLine(introLine);
    }

    public float PlayClosing()
    {
        return PlayLine(closingLine);
    }

    private float PlayLine(AudioClip clip)
    {
        if (voiceSource == null || clip == null)
        {
            return 0f; // nothing to play
        }

        // reset the pitch before playing (NpcHitResponse varies the pitch of the reactive lines on this same source)
        voiceSource.pitch = 1.09f;
        voiceSource.PlayOneShot(clip);

        return clip.length;
    }
    #endregion
}