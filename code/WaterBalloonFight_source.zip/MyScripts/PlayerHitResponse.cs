using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Inputs.Haptics;

// vibrates the participant's controllers when the npc's balloon lands on them

public class PlayerHitResponse : MonoBehaviour
{
    #region Inspector Fields
    [Header("Controllers")]
    [SerializeField] private HapticImpulsePlayer leftController;
    [SerializeField] private HapticImpulsePlayer rightController;

    [Header("Impulse")]
    [SerializeField] private float amplitude = 0.6f; // strength of the vibration (from 0 to 1)
    [SerializeField] private float duration = 0.25f; // seconds the vibration lasts
    #endregion

    #region Event Subscription
    private void OnEnable()
    {
        BalloonBreak.PlayerGotHit += HandlePlayerHit;
    }

    private void OnDisable()
    {
        BalloonBreak.PlayerGotHit -= HandlePlayerHit;
    }
    #endregion

    #region Methods
    private void HandlePlayerHit()
    {
        // both controllers
        SendImpulse(leftController);
        SendImpulse(rightController);
    }

    private void SendImpulse(HapticImpulsePlayer controller)
    {
        if (controller == null)
        {
            return; // not assigned, so skip it
        }

        controller.SendHapticImpulse(amplitude, duration);
    }
    #endregion
}