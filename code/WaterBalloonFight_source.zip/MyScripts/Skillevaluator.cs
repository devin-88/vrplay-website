using UnityEngine;
using System.Collections.Generic;

public class SkillEvaluator : MonoBehaviour
{
    public enum PlayerClass{Novice = 1, Intermediate = 2, Expert = 3}

    [SerializeField] private PlayerReactionTimer playerReactionTimer;

    [Header("Skill Level Thresholds")]
    [SerializeField] private float throwAccuracyIntermediate = 0.30f;
    [SerializeField] private float throwAccuracyExpert = 0.60f;
    [SerializeField] private float reactionTimeIntermediate = 0.75f;
    [SerializeField] private float reactionTimeExpert = 0.40f;
    [SerializeField] private float throwIntervalIntermediate = 5f;
    [SerializeField] private float throwIntervalExpert = 3f;

    private int throwCount = 0;
    private int hitCount = 0;
    private readonly List<float> throwTimes = new List<float>(); // locks down the reference (safety purposes)

    // last computed results
    public float LastHitAccuracy {get; private set;}
    public float LastReactionTime {get; private set;}
    public float LastThrowInterval {get; private set;}
    public int LastScore {get; private set;}
    public PlayerClass LastClass {get; private set;}

    private void OnPlayerThrew()
    {
        throwCount++;
        throwTimes.Add(Time.time);
    }

    private void OnPlayerHitNpc()
    {
        hitCount++;
    }

    private void OnEnable()
    {
        BalloonBreak.PlayerThrew += OnPlayerThrew;
        BalloonBreak.PlayerHitNpc += OnPlayerHitNpc;
    }

    private void OnDisable()
    {
        BalloonBreak.PlayerThrew -= OnPlayerThrew; 
        BalloonBreak.PlayerHitNpc -= OnPlayerHitNpc;
    }

    #region Helper Methods

    private int ScoreThrowAccuracy(float throwAccuracy)
    {
        if (throwAccuracy >= throwAccuracyExpert) return 3;
        if (throwAccuracy >= throwAccuracyIntermediate) return 2;
        return 1;
    }

    private int ScoreReactionTime(float reactionTime)
    {
        if (reactionTime <= reactionTimeExpert) return 3;
        if (reactionTime <= reactionTimeIntermediate) return 2;
        return 1;
    }

    private int ScoreThrowInterval(float throwInterval)
    {
        if (throwInterval <= throwIntervalExpert) return 3;
        if (throwInterval <= throwIntervalIntermediate) return 2;
        return 1;
    }

    private PlayerClass ClassifyPlayer(int totalScore)
    {
        if (totalScore <= 3) return PlayerClass.Novice;
        if (totalScore <= 6) return PlayerClass.Intermediate;
        return PlayerClass.Expert;
    }

    private float CalculateMeanThrowInterval() // calculates the throw interval, using the mean
    {
        float total = 0f;
        for (int i = 1; i < throwTimes.Count; i++)
        {
            total += throwTimes[i] - throwTimes[i - 1];
        }
        return (total/(throwTimes.Count - 1)); // -1 because the number of gaps between throws = number of throws - 1
    }
    #endregion

    [ContextMenu("Begin Evaluation")]
    public void BeginEval()
    {
        throwCount = 0;
        hitCount = 0;
        throwTimes.Clear();
        if (playerReactionTimer != null)
        {
            playerReactionTimer.ResetSamples();
        }
        Debug.Log("Evaluation started");
    }

    [ContextMenu("End Evaluation")]
    private void EndEvalWrapper()
    {
        EndEval();
    }

    public PlayerClass EndEval()
    {
        // throw accuracy
        int throwAccuracyScore;
        if (throwCount > 0)
        {
            LastHitAccuracy = (float)hitCount/throwCount; // so not an int
            throwAccuracyScore = ScoreThrowAccuracy(LastHitAccuracy);
        }
        else
        {
            LastHitAccuracy = 0f;
            throwAccuracyScore = 1;
        }

        // reaction time
        int reactionTimeScore;
        if (playerReactionTimer != null && playerReactionTimer.HasSamples)
        {
            LastReactionTime = playerReactionTimer.CalculateMedianReactionTime();
            reactionTimeScore = ScoreReactionTime(LastReactionTime);
        }
        else
        {
            LastReactionTime = 0f;
            reactionTimeScore = 1;
        }

        // throw interval
        int throwIntervalScore;
        if (throwTimes.Count >= 2) // at least one gap in between two throws
        {
            LastThrowInterval = CalculateMeanThrowInterval();
            throwIntervalScore = ScoreThrowInterval(LastThrowInterval);
        }
        else
        {
            LastThrowInterval = 0f;
            throwIntervalScore = 1;
        }

        // calculate final score
        LastScore = throwAccuracyScore + reactionTimeScore + throwIntervalScore;
        LastClass = ClassifyPlayer(LastScore);

        // for debugging
        Debug.Log(
            "Evaluation done. " +
            "Accuracy " + LastHitAccuracy.ToString("F2") + " (" + throwAccuracyScore + "), " +
            "Reaction " + LastReactionTime.ToString("F2") + "s (" + reactionTimeScore + "), " +
            "Interval " + LastThrowInterval.ToString("F2") + "s (" + throwIntervalScore + "), " +
            "Score " + LastScore + " -> " + LastClass);

        return LastClass;
    }
}