using UnityEngine;

// a measuring tape tool essentially
public class DistanceMeasurer : MonoBehaviour
{
    [SerializeField] private Transform pointA;
    [SerializeField] private Transform pointB;

    [ContextMenu("Measure Distance")]
    private void Measure()
    {
        if (pointA == null || pointB == null)
        {
            Debug.Log("Assign both points first");
            return;
        }

        float distance = Vector3.Distance(pointA.position, pointB.position);
        Debug.Log("Distance: " + distance.ToString("F2") + " m");
    }
}