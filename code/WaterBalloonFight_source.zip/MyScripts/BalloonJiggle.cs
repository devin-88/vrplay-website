using UnityEngine;

// Gives the balloon a soft wobble, per the "jiggling animation" 

public class BalloonJiggle : MonoBehaviour
{
    #region Inspector Fields
    [Header("Resting Wobble")]
    [SerializeField] private float restingAmount = 0.03f; // how far it squashes while sitting in the bucket, as a fraction of its size
    [SerializeField] private float wobbleSpeed = 6f; // wobbles per second

    [Header("Wobble After Being Thrown")]
    [SerializeField] private float thrownAmount = 0.12f; // how far it squashes just after being released
    [SerializeField] private float settleSpeed = 1.5f; // how quickly that extra wobble fades away
    #endregion

    private Vector3 baseScale;
    private float extraAmount;
    private float phase;

    #region Setup
    private void Start()
    {
        baseScale = transform.localScale;

        // a random starting point, so the balloons don't all pulse in unison
        phase = Random.Range(0f, Mathf.PI*2f);
    }
    #endregion

    #region Per Frame
    private void Update()
    {
        phase += wobbleSpeed*Time.deltaTime;

        // the extra wobble from being thrown fades back to nothing over time
        extraAmount = Mathf.MoveTowards(extraAmount, 0f, settleSpeed*Time.deltaTime);

        float amount = restingAmount + extraAmount;
        float squash = Mathf.Sin(phase)*amount;

        // squash and stretch: as the balloon gets shorter it also gets wider
        transform.localScale = new Vector3(
            baseScale.x*(1f + squash*0.5f),
            baseScale.y*(1f - squash),
            baseScale.z*(1f + squash*0.5f)
        );
    }
    #endregion

    #region Public
    // called when the balloon is released, so it wobbles harder for a moment before settling
    public void AddThrowWobble()
    {
        extraAmount = thrownAmount;
    }
    #endregion
}