using UnityEngine;

// Gives each balloon a random colour and a random size when it first spawns

public class BalloonAppearance : MonoBehaviour
{
    #region Inspector Fields
    [Header("Size")]
    [SerializeField] private bool randomiseSize = true;
    [SerializeField] private float minSize = 0.15f; // smallest scale a balloon can be
    [SerializeField] private float maxSize = 0.18f; // largest scale a balloon can be

    [Header("Colour")]
    [SerializeField] private Color[] palette; // the colours a balloon can be
    #endregion

    private void Awake()
    {
        if (randomiseSize)
        {
            ApplySize();
        }

        ApplyColour();
    }

    #region Methods
    private void ApplySize()
    {
        float balloonScale = Random.Range(minSize, maxSize);

        // the same value on all three axes, so the balloon stays proportional
        transform.localScale = new Vector3(balloonScale, balloonScale, balloonScale);
    }

    private void ApplyColour()
    {
        if (palette == null || palette.Length == 0)
        {
            return; // no palette set, so leave balloon with material's default colour
        }

        Color chosenColour = palette[Random.Range(0, palette.Length)];

        Renderer rend = GetComponentInChildren<Renderer>();
        if (rend == null)
        {
            return;
        }
        
        rend.material.color = chosenColour;
    }
    #endregion
}