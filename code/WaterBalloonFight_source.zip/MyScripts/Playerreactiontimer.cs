using UnityEngine;
using System.Collections.Generic;

// records the player's reaction speed for the player assist calculations

[RequireComponent(typeof(Collider))]
public class PlayerReactionTimer: MonoBehaviour
{
    public static event System.Action DuckDetected;
    public static event System.Action ThreatDetected;
    public static event System.Action<float> ReactionRecorded;
    [SerializeField] private Transform playerHead; // player's main camera
    [SerializeField] private float maxTimeToReact = 1.5f; // amount of time a reaction must take place in, for it to be counted as a reaction
    [SerializeField] private float slowestDuckSpeedAccepted = 0.05f; // speed of downward head movement that indicates ducking is occurring threshold
    [SerializeField] private float minTimeBetweenDucks = 0.1f;
    private float lastDuckTime = -999f;

    private readonly List<float> samples = new List<float>(); // reaction samples collected in the current window

    private bool hasPendingThreat = false; // indicates if there is a threat that still needs responding to
    private float pendingThreatBirthTime = 0f; // how long the threat has been present

    private float prevHeadY = 0f; // previous player head y position
    private bool wasMovingDown = false;

    private void OnEnable()
    {
        if (playerHead != null)
        {
            prevHeadY = playerHead.position.y;
        }
        wasMovingDown = false;
    }

    private void OnTriggerEnter(Collider incomingBalloon)
    {
        if (incomingBalloon.GetComponent<BalloonBreak>() == null) // verifying that it is a balloon
        {
            return;
        }

        Rigidbody rb = incomingBalloon.GetComponent<Rigidbody>();
        if (rb == null || playerHead == null)
        {
            return; // can't track any physics without them
        }

        Vector3 toPlayer = playerHead.position - incomingBalloon.transform.position; // vector from balloon to player
        // check that the balloon is heading towards the player (ie. is not a balloon thrown by the player)
        if (Vector3.Dot(rb.linearVelocity, toPlayer) > 0f) // going in same direction if positive
        {
            if (!hasPendingThreat) // if there is already a threat that needs responding to, keep that one as main focus as this is what the player would respond to first
            {
                pendingThreatBirthTime = Time.time;
                hasPendingThreat = true;
                ThreatDetected?.Invoke();
            }
        }
    }

    private void Update()
    {
        if (playerHead == null || Time.deltaTime <= 0f) // no head, or no frames have occurred yet
        {
            return;
        }

        if (hasPendingThreat && (Time.time - pendingThreatBirthTime > maxTimeToReact)) // discard threats that haven't been reacted to for too long, assume it has passed
        {
            hasPendingThreat = false;
        }

        float downwardSpeed = (prevHeadY - playerHead.position.y)/Time.deltaTime; // calculate how fast the player's head is moving per frame
        prevHeadY = playerHead.position.y; // update player head position

        bool movingDown = downwardSpeed > slowestDuckSpeedAccepted; // ensures even slow ducks are accounted for

        if (movingDown && !wasMovingDown && (Time.time - lastDuckTime >= minTimeBetweenDucks))
        {
            lastDuckTime = Time.time;
            DuckDetected?.Invoke();
            TryRecordReaction(); // record the onset of the ducking motion, not every frame the player is ducking
        }
        wasMovingDown = movingDown;
    }

    #region Helper Methods

    private void TryRecordReaction()
    {
        if (!hasPendingThreat)
        {
            return; // the movement was not in response to a threat, so don't record it
        }
        
        float reactionDelay = Time.time - pendingThreatBirthTime;
        if (reactionDelay <= maxTimeToReact)
        {
            samples.Add(reactionDelay);
            ReactionRecorded?.Invoke(reactionDelay);
        }
        hasPendingThreat = false; // threat has been responded to
    }
    public void ResetSamples()
    {
        samples.Clear();
        hasPendingThreat = false;
    }

    public bool HasSamples
    {
        get {return samples.Count > 0;}
    }

    public float CalculateMedianReactionTime()
    // using median to account for outliers
    {
        if (samples.Count == 0)
        {
            return 0f; // they didn't react at all
        }

        List<float> sortedSamples = new List<float>(samples);
        sortedSamples.Sort();

        int mid = sortedSamples.Count/2;
        if (sortedSamples.Count % 2 == 1) // odd number of elements
        {
            return sortedSamples[mid];
        }
        return (sortedSamples[mid - 1] + sortedSamples[mid])*0.5f; // get the average of the two, since it's even number of elements
    }
    #endregion
}