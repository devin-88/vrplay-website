using UnityEngine;

// PURPOSE:
// We need to track the player's hitbox so that collisions are accurate.
// However, we cannot track the body and the head together because if we did, the body would rotate with the head.
// In real life, the body does not always rotate with the head, hence we need to separate the two.
// This script is attached to the player's hitbox, and ensures its collider is always below the head and does not rotate with the head.

public class BodyFollower : MonoBehaviour
{
    [SerializeField] private Transform head; // the player's head (main camera position)
    [SerializeField] private float heightBelowHead = 0.6f; // how far below the head the torso starts (60cm default)

    private void Update()
    {
        if (head == null)
        {
            return;
        }

        Vector3 bodyPosition = head.position; // main camera position
        bodyPosition.y -= heightBelowHead; // only change the y position value
        transform.position = bodyPosition; // change position of the hitbox object this script is attached to
    }
}