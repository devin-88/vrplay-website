using UnityEngine;

[RequireComponent(typeof(Animator))]
public class NpcAnimationDriver : MonoBehaviour
{
    [SerializeField] private NpcController npcController;
    private Animator animator;
    private NpcAdvancedMoves.AdvancedMove? pendingReleaseMove;

    private void Awake()
    {
        animator = GetComponent<Animator>();
    }

    private void HandleThrow(NpcAdvancedMoves.AdvancedMove? move)
    {
        switch (move)
        {
            case null:
                animator.SetTrigger("StandardThrow");
                break;
            case NpcAdvancedMoves.AdvancedMove.HighVelocity:
                animator.SetTrigger("StandardThrow");
                break;
            case NpcAdvancedMoves.AdvancedMove.HighThrow:
                animator.SetTrigger("HighThrow");
                break;
            case NpcAdvancedMoves.AdvancedMove.TwoHanded:
                animator.SetTrigger("TwoHandedThrow");
                break;
            case NpcAdvancedMoves.AdvancedMove.Successive:
                animator.SetTrigger("SuccessiveThrow");
                break;
            case NpcAdvancedMoves.AdvancedMove.SideThrow:
                animator.SetTrigger("StandardThrow");
                break;
            case NpcAdvancedMoves.AdvancedMove.Intercept:
                animator.SetTrigger("InterceptThrow"); // fast throw clip
                break;
        }
        pendingReleaseMove = move;
    }

    private void OnEnable()
    {
        if (npcController != null)
        {
            npcController.OnThrowStarted += HandleThrow;
        }
    }

    private void OnDisable()
    {
        if (npcController != null)
        {
            npcController.OnThrowStarted -= HandleThrow;
        }
    }

    private void Update()
    {
        // change to standing if applicable
        bool isStanding = (
            npcController.CurrentState == NpcController.NpcState.Stalking ||
            npcController.CurrentState == NpcController.NpcState.Throwing ||
            npcController.CurrentState == NpcController.NpcState.Intercepting ||
            npcController.SideThrowStanding ||
            npcController.IsHeldStanding
        );
        animator.SetBool("IsStanding", isStanding);
        animator.SetInteger("SideMovement", npcController.SideMovement);
    }

    // relay method, because the animator is on the child of the npc root
    public void AnimationEvent_ReleaseThrow(int hand)
    {
        AnimatorClipInfo[] clipInfo = animator.GetCurrentAnimatorClipInfo(0);
        string clipName = "unknown";
        if (clipInfo.Length > 0)
        {
            clipName = clipInfo[0].clip.name;
        }
        Debug.Log("relay: release event arrived, move = " + pendingReleaseMove + ", clip = " + clipName + " , " + Time.time);
        if (npcController != null)
        {
            npcController.ReleaseThrow(pendingReleaseMove, hand); // call the actual method needed
        }
    }

    public void AnimationEvent_ThrowFinished() // called in the animator towards the end of the final clip in the sequence
    {
        if (npcController != null)
        {
            npcController.ThrowCompleted(pendingReleaseMove);
        }
    }

    public void PlayHitReaction()
    {
        animator.SetTrigger("Hit");
    }

    public void PlayWave()
    {
        animator.SetTrigger("Wave");
    }

    // called by NpcCelebration when the npc lands a hit and the roll succeeds
    public void PlayCheer()
    {
        animator.SetTrigger("Cheer");
    }
}
