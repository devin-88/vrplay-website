using UnityEngine;

// determines if a threat (to the npc) is detected and reports to the npc 

[RequireComponent(typeof(Collider))] // collider gives shape, occupied space, triggers collision event reporting
public class ThreatDetector : MonoBehaviour
{
    [SerializeField] private Transform npc; // the npc which this zone protects/reports to
    [SerializeField] private float threatMaxLifeSpan = 1f; // how long a threat is considered active, once identified

    private float threatAge = 0f; // how long the threat has been alive
    private Rigidbody incomingBalloon; // the threat object identified

    private void Awake()
    {
        threatAge = threatMaxLifeSpan;
    }

    private void Update()
    {
        if (threatAge < threatMaxLifeSpan)
        {
            threatAge += Time.deltaTime; // increase age of the threat each frame
        }
    }

    private void OnTriggerEnter(Collider collidingObject)
    {
        if (collidingObject.GetComponent<BalloonBreak>() == null) // all balloons have a BalloonBreak component, and we only consider threats to be balloons
        {
            return;
        }

        Rigidbody rb = collidingObject.GetComponent<Rigidbody>();

        if (rb == null)
        {
            return;
        }

        Vector3 vectorToNpc = npc.position - collidingObject.transform.position;

        // dot product produces a sign based on the angle between the vectors
        // positive dot product means theyre headed in roughly the same direction
        // negative dot product means theyre headed in opposite directions
        if (Vector3.Dot(rb.linearVelocity, vectorToNpc) > 0) // balloon is headed to the npc
        {
            threatAge = 0f; // reset threat age
            incomingBalloon = rb; // recognise the balloon as the incoming threat
        }
    }

    public bool ThreatIncoming()
    {
        return threatAge < threatMaxLifeSpan;
    }

    public Rigidbody GetIncomingBalloon()
    {
        if (threatAge < threatMaxLifeSpan)
        {
            return incomingBalloon;
        }

        return null;
    }
}