using UnityEngine;

// throwaway tester

public class TestThrower : MonoBehaviour
{
    [SerializeField] private GameObject balloonPrefab;
    [SerializeField] private Transform throwPoint;
    [SerializeField] private Transform target;          
    [SerializeField] private float throwInterval = 2.5f; 
    [SerializeField] private float flightTime = 1f;      

    private void Start()
    {
        // Self-firing
        InvokeRepeating(nameof(FireBalloon), throwInterval, throwInterval);
    }

    private void FireBalloon()
    {
        if (balloonPrefab == null || throwPoint == null || target == null)
        {
            return;
        }

        GameObject balloon = Instantiate(balloonPrefab, throwPoint.position, Quaternion.identity);

        // Arm it so it can actually burst on impact
        BalloonBreak breakScript = balloon.GetComponent<BalloonBreak>();
        if (breakScript != null)
        {
            breakScript.EnableBursting();
        }

        // Same aiming maths as the NPC, so the balloon arcs onto the target
        // properly rather than being flung
        Rigidbody rb = balloon.GetComponent<Rigidbody>();
        if (rb != null)
        {
            Vector3 displacement = target.position - throwPoint.position;
            Vector3 gravity = Physics.gravity;
            rb.linearVelocity = displacement / flightTime - 0.5f * gravity * flightTime;
        }
    }
}