using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

// controls how a balloon can burst and how throws/hits get reported

public class BalloonBreak : MonoBehaviour
{
    #region Definitions and Variables
    public static event System.Action PlayerThrew;
    public static event System.Action PlayerHitNpc;
    public static event System.Action PlayerGotHit;

    [SerializeField] private GameObject splashEffect;
    [SerializeField] private AudioClip splashSound;
    [SerializeField] private GameObject splashFaceEffect;

    private bool canBurst = false; // a balloon will only burst upon collision, once it has been released - prevents balloons from bursting upon spawning
    private bool thrownByPlayer = false;

    private XRGrabInteractable grabbable;
    #endregion

    #region Methods
    private void Awake()
    {
        grabbable = GetComponent<XRGrabInteractable>(); // finds the first component of type XRGrabInteractable attached to this instance
        if (grabbable != null)
        {
            grabbable.selectExited.AddListener(OnReleased);
            // selectExited fires when the interactor stops selecting the object
            // when selectExited fires, OnReleased will execute as well
        }
    }

    private void OnReleased(SelectExitEventArgs args)
    {
        canBurst = true;
        thrownByPlayer = true;
        PlayerThrew?.Invoke(); // execute the methods subscribed
        // "?" so that if no methods have subscribed to PlayerThrew, an error won't be thrown
    }

    // gets called outside of this class, so that the npc can throw balloons which can burst
    public void EnableBursting()
    {
        canBurst = true;
    }

    public void DisableBursting() // for pool purposes
    {
        canBurst = false;
    }

    // Unity calls this method whenever a collision happens with this object involved
    private void OnCollisionEnter(Collision collision)
    {
        if (!canBurst)
        {
            return; // do nothing, because the balloon hasn't been thrown
        }

        if (thrownByPlayer && collision.gameObject.CompareTag("PlayerBody")) // player threw it, and it landed on the player's body
        {
            return; // do nothing, because if a player throws it on their body in real life, the force wouldn't be enough for it to burst
        }

        if (thrownByPlayer && collision.gameObject.CompareTag("Npc")) // player threw it and it collided with the npc
        {
            PlayerHitNpc?.Invoke();
        }

        if (!thrownByPlayer && collision.gameObject.CompareTag("PlayerBody")) // npc threw it and it landed on the player
        {
            PlayerGotHit?.Invoke();
        }

        // visual and audio effects
        ContactPoint contact = collision.GetContact(0); // gets the point of the first collision

        if (splashEffect != null)
        {
            Instantiate(splashEffect, contact.point, Quaternion.identity);
            // contact.normal so that the splash's forward axis points away from the surface it collided with
            // hence the splash comes off the colliding surface
        }

        if (splashSound != null)
        {
            AudioSource.PlayClipAtPoint(splashSound, transform.position, 0.2f);
        }

        if (splashFaceEffect != null && Camera.main != null && collision.gameObject.CompareTag("PlayerBody"))
        {
            Transform camera = Camera.main.transform;
            GameObject faceSplash = Instantiate(splashFaceEffect, camera);
            faceSplash.transform.localPosition = new Vector3(0f, -0.35f, 0.1f); // move it a bit forward so it's visible
            faceSplash.transform.localRotation = Quaternion.identity;
        }

        Destroy(gameObject); // destroys the entire balloon and everything attached to it
        // calls onDestroy at end of frame
    }

    // Unity method called after Destroy(), at the end of that frame
    private void OnDestroy()
    {
        if (grabbable != null)
        {
            grabbable.selectExited.RemoveListener(OnReleased);
        }
    }
    #endregion
}