using UnityEngine;

// occasionally makes the npc celebrate after landing a balloon on the participant

public class NpcCelebration : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private NpcAnimationDriver animationDriver;
    [SerializeField] private NpcController npcController;

    [Header("Chance")]
    [Range(0f, 1f)]
    [SerializeField] private float celebrationChance = 0.1f; 
    [SerializeField] private float cooldown = 8f; // minimum seconds between celebrations

    [Header("Voice")]
    [SerializeField] private AudioSource voiceSource;
    [SerializeField] private AudioClip[] celebrationLines;
    #endregion

    private float lastCelebrationTime = -999f;

    #region Event Subscription
    private void OnEnable()
    {
        BalloonBreak.PlayerGotHit += HandleHitLanded;
    }

    private void OnDisable()
    {
        BalloonBreak.PlayerGotHit -= HandleHitLanded;
    }
    #endregion

    #region Methods
    private void HandleHitLanded()
    {
        if (Time.time - lastCelebrationTime < cooldown)
        {
            return; // celebrated too recently
        }

        if (Random.value > celebrationChance)
        {
            return; // the roll failed, so this hit passes without any celebration
        }

        if (!IsStanding())
        {
            return; // the celebration and crouched animations don't read well together
        }

        lastCelebrationTime = Time.time;

        if (animationDriver != null)
        {
            animationDriver.PlayCheer();
        }

        PlayCelebrationLine();
    }

    private bool IsStanding()
    {
        if (npcController == null)
        {
            return true; // no controller assigned, so don't block the celebration
        }

        return npcController.CurrentState == NpcController.NpcState.Stalking
            || npcController.CurrentState == NpcController.NpcState.Throwing
            || npcController.CurrentState == NpcController.NpcState.Intercepting
            || npcController.SideThrowStanding
            || npcController.IsHeldStanding;
    }

    private void PlayCelebrationLine()
    {
        if (voiceSource == null || celebrationLines == null || celebrationLines.Length == 0)
        {
            return; // only play sounds if there are sounds loaded
        }

        AudioClip line = celebrationLines[Random.Range(0, celebrationLines.Length)];
        if (line != null)
        {
            voiceSource.PlayOneShot(line);
        }
    }
    #endregion
}