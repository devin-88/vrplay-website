using UnityEngine;
using System.Text;
using System.Collections.Generic;
using System.IO;

// records everything the participant and the npc do during a session, with exact timestamps

public class SessionLogger : MonoBehaviour
{
    #region Inspector Fields
    [Header("Participant")]
    [SerializeField] private string participantId = "P01";

    [Header("Console Output")]
    [SerializeField] private bool logEveryEvent = true; // prints each event as it happens
    [SerializeField] private bool printPeriodically = true;
    [SerializeField] private float printInterval = 30f; // seconds between running totals, matches one segment

    [Header("File Output")]
    [SerializeField] private bool writeToFile = true;
    #endregion

    // rows are kept in memory and written once at the end
    private struct LogEntry
    {
        public float time;
        public string segment;
        public string eventName;
        public string value;
    }

    private readonly List<LogEntry> entries = new List<LogEntry>();

    private int playerThrowCount;
    private int npcThrowCount;
    private int hitsOnNpc;
    private int timesHitByNpc;
    private int duckCount;
    private int threatCount;
    private readonly List<float> reactionTimes = new List<float>();

    private string currentSegment = "PreStart";
    private float sessionStartTime;

    #region Event Subscription
    private void OnEnable()
    {
        BalloonBreak.PlayerThrew += OnPlayerThrew;
        BalloonBreak.PlayerHitNpc += OnPlayerHitNpc;
        BalloonBreak.PlayerGotHit += OnPlayerGotHit;

        NpcThrower.NpcThrew += OnNpcThrew;

        PlayerReactionTimer.DuckDetected += OnDuck;
        PlayerReactionTimer.ThreatDetected += OnThreat;
        PlayerReactionTimer.ReactionRecorded += OnReaction;

        SegmentController.SegmentStarted += OnSegmentStarted;
    }

    private void OnDisable()
    {
        BalloonBreak.PlayerThrew -= OnPlayerThrew;
        BalloonBreak.PlayerHitNpc -= OnPlayerHitNpc;
        BalloonBreak.PlayerGotHit -= OnPlayerGotHit;

        NpcThrower.NpcThrew -= OnNpcThrew;

        PlayerReactionTimer.DuckDetected -= OnDuck;
        PlayerReactionTimer.ThreatDetected -= OnThreat;
        PlayerReactionTimer.ReactionRecorded -= OnReaction;

        SegmentController.SegmentStarted -= OnSegmentStarted;
    }
    #endregion

    #region Setup
    private void Start()
    {
        sessionStartTime = Time.time;
        Record("session_start", participantId);

        if (printPeriodically)
        {
            InvokeRepeating(nameof(PrintTotals), printInterval, printInterval);
        }
    }
    #endregion

    #region Event Handlers
    private void OnPlayerThrew()
    {
        playerThrowCount++;
        Record("player_throw", playerThrowCount.ToString());
    }

    private void OnNpcThrew()
    {
        npcThrowCount++;
        Record("npc_throw", npcThrowCount.ToString());
    }

    private void OnPlayerHitNpc()
    {
        hitsOnNpc++;
        Record("hit_npc", hitsOnNpc.ToString());
    }

    private void OnPlayerGotHit()
    {
        timesHitByNpc++;
        Record("got_hit", timesHitByNpc.ToString());
    }

    private void OnDuck()
    {
        duckCount++;
        Record("duck", duckCount.ToString());
    }

    private void OnThreat()
    {
        threatCount++;
        Record("threat", threatCount.ToString());
    }

    private void OnReaction(float delaySeconds)
    {
        reactionTimes.Add(delaySeconds);
        Record("reaction", delaySeconds.ToString("F3"));
    }

    private void OnSegmentStarted(string segmentName)
    {
        currentSegment = segmentName;
        Record("segment_start", segmentName);
    }
    #endregion

    #region Recording
    private void Record(string eventName, string value)
    {
        LogEntry entry = new LogEntry();
        entry.time = ElapsedSeconds();
        entry.segment = currentSegment;
        entry.eventName = eventName;
        entry.value = value;

        entries.Add(entry);

        if (logEveryEvent)
        {
            Debug.Log(entry.time.ToString("F2") + "s [" + entry.segment + "] " + eventName + " " + value);
        }
    }

    private float ElapsedSeconds()
    {
        return Time.time - sessionStartTime;
    }
    #endregion

    #region Reporting
    [ContextMenu("Print Totals")]
    public void PrintTotals()
    {
        Debug.Log(BuildSummary());
    }

    private string BuildSummary()
    {
        StringBuilder summary = new StringBuilder();

        summary.AppendLine("=== Session totals: " + participantId + " ===");
        summary.AppendLine("Elapsed: " + ElapsedSeconds().ToString("F1") + " s");
        summary.AppendLine("Current segment: " + currentSegment);
        summary.AppendLine("Throws by participant: " + playerThrowCount);
        summary.AppendLine("Throws by npc: " + npcThrowCount);
        summary.AppendLine("Hits on npc: " + hitsOnNpc);
        summary.AppendLine("Hit accuracy: " + FormatAccuracy());
        summary.AppendLine("Times hit by npc: " + timesHitByNpc);
        summary.AppendLine("Ducks: " + duckCount);
        summary.AppendLine("Threats detected: " + threatCount);
        summary.AppendLine("Reactions recorded: " + reactionTimes.Count);
        summary.AppendLine("Median reaction time: " + FormatMedianReaction());
        summary.AppendLine("Events logged: " + entries.Count);

        return summary.ToString();
    }

    private string FormatAccuracy()
    {
        if (playerThrowCount == 0)
        {
            return "n/a, no throws yet";
        }

        float accuracy = (float)hitsOnNpc/playerThrowCount;
        return (accuracy*100f).ToString("F1") + " %";
    }

    private string FormatMedianReaction()
    {
        if (reactionTimes.Count == 0)
        {
            return "n/a, no reactions recorded";
        }

        // median rather than mean to account for outliers
        List<float> sorted = new List<float>(reactionTimes);
        sorted.Sort();

        int mid = sorted.Count/2;
        if (sorted.Count%2 == 1)
        {
            return sorted[mid].ToString("F3") + " s";
        }
        return ((sorted[mid - 1] + sorted[mid])*0.5f).ToString("F3") + " s";
    }
    #endregion

    #region Saving
    // runs when play mode stops
    private void OnApplicationQuit()
    {
        Record("session_end", "");
        PrintTotals();

        if (writeToFile)
        {
            SaveFiles();
        }
    }

    [ContextMenu("Save Now")]
    public void SaveFiles()
    {
        string stamp = System.DateTime.Now.ToString("yyyyMMdd_HHmmss");
        string folder = Path.Combine(Application.dataPath, "..", "Logs");
        Directory.CreateDirectory(folder);

        try
        {
            string eventPath = Path.Combine(folder, "VRPlay_" + participantId + "_" + stamp + "_events.csv");
            File.WriteAllText(eventPath, BuildCsv());

            string summaryPath = Path.Combine(folder, "VRPlay_" + participantId + "_" + stamp + "_summary.txt");
            File.WriteAllText(summaryPath, BuildSummary());

            Debug.Log("SessionLogger: saved to " + folder);
        }
        catch (System.Exception error)
        {
            Debug.LogWarning("SessionLogger: could not save. " + error.Message);
        }
    }

    private string BuildCsv()
    {
        StringBuilder csv = new StringBuilder();
        csv.AppendLine("time_seconds,segment,event,value"); // header rows

        foreach (LogEntry entry in entries)
        {
            csv.AppendLine(
                entry.time.ToString("F3") + "," +
                entry.segment + "," +
                entry.eventName + "," +
                entry.value
            );
        }

        return csv.ToString();
    }
    #endregion
}