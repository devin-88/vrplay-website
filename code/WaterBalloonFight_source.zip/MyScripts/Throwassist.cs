using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using System.Collections;

// calls the assists from PlayerAssist to be applied to the actual throw

[RequireComponent(typeof(Rigidbody))] // enforces that the object this ThrowAssist component is attached to, must have a rigidbody
public class ThrowAssist : MonoBehaviour
{
    private XRGrabInteractable grabbable;
    private Rigidbody rb;

    private void Awake()
    {
        rb = GetComponent<Rigidbody>();
        grabbable = GetComponent<XRGrabInteractable>();

        if (grabbable != null)
        {
            grabbable.selectExited.AddListener(OnReleased);
        }
    }

    private void OnReleased(SelectExitEventArgs args)
    {
        // wait for the initial velocity of the throw to be assigned before adjusting the throw
        // if did at same time, the assist could be overwritten or could use wrong values
        // use co routine, because it can wait across frames before running without freezing the whole game
        StartCoroutine(CorrectNextPhysicsStep2());
    }

    private IEnumerator CorrectNextPhysicsStep(Vector3 throwOrigin)
    {
        yield return new WaitForFixedUpdate(); // wait for a physics step to pass before adjusting the throw, this is the yield condition

        Debug.Log("XR handed over: " +rb.linearVelocity.magnitude.ToString("F2") + " m/s");

        if (PlayerAssist.Instance != null)
        {
            Debug.Log("Assist alive on '" + PlayerAssist.Instance.gameObject.name + "', component enabled = " + PlayerAssist.Instance.enabled);
            PlayerAssist.Instance.CorrectThrow(rb, throwOrigin); // assist the throw
            Debug.Log("After assist: " + rb.linearVelocity.magnitude.ToString("F2") + " m/s");
        }
        else
        {
            Debug.Log("Assist instance is null");
        }
    }

    private IEnumerator CorrectNextPhysicsStep2()
    {
        yield return new WaitForFixedUpdate();

        if (rb == null)
        {
            yield break; // balloon burst during that physics step
        }

        rb.isKinematic = false;

        Debug.Log("XR handed over: " +rb.linearVelocity.magnitude.ToString("F2") + " m/s");

        if (PlayerAssist.Instance != null)
        {
            Debug.Log("Assist alive on '" + PlayerAssist.Instance.gameObject.name + "', component enabled = " + PlayerAssist.Instance.enabled);
            PlayerAssist.Instance.CorrectThrow(rb, rb.position); // read its current position, not its origin
            Debug.Log("After assist: " + rb.linearVelocity.magnitude.ToString("F2") + " m/s");
        }
        else
        {
            Debug.Log("Assist instance is null");
        }
    }

    private void OnDestroy() // must have this, because each balloon gets its own throw assist
    {
        if (grabbable != null)
        {
            grabbable.selectExited.RemoveListener(OnReleased);
        }
    }
}