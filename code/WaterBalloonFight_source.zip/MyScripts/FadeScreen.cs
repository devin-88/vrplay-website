using UnityEngine;
using System.Collections;

// fades the participant's view to black at the end of the experience
// works by fading a small black sphere that sits around the headset camera

public class FadeScreen : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private Renderer fadeRenderer; // the sphere's renderer
    [SerializeField] private float defaultDuration = 3f; // default seconds a fade takes
    #endregion

    private Material fadeMaterial;
    private Color baseColour;
    private Coroutine activeFade;

    private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");
    private static readonly int LegacyColorId = Shader.PropertyToID("_Color");

    #region Setup
    private void Awake()
    {
        if (fadeRenderer == null)
        {
            fadeRenderer = GetComponent<Renderer>();
        }

        if (fadeRenderer == null)
        {
            Debug.LogError("FadeScreen: no renderer assigned, the fade won't appear");
            enabled = false;
            return;
        }

        fadeMaterial = fadeRenderer.material;
        baseColour = ReadColour();

        ApplyAlpha(0f);
        fadeRenderer.enabled = false; // switched off while clear
    }
    #endregion

    #region Public
    public void FadeToBlack()
    {
        FadeToBlack(defaultDuration);
    }

    public void FadeToBlack(float duration)
    {
        StartFade(1f, duration);
    }

    public void FadeFromBlack(float duration)
    {
        StartFade(0f, duration);
    }

    private void StartFade(float targetAlpha, float duration)
    {
        // stop any fade already in progress
        if (activeFade != null)
        {
            StopCoroutine(activeFade);
        }

        activeFade = StartCoroutine(FadeRoutine(targetAlpha, duration));
    }
    #endregion

    #region Fading
    private IEnumerator FadeRoutine(float targetAlpha, float duration)
    {
        fadeRenderer.enabled = true;

        float startAlpha = ReadColour().a;
        float elapsed = 0f;

        while (elapsed < duration)
        {
            // unscaled time
            elapsed += Time.unscaledDeltaTime;

            float progress = Mathf.Clamp01(elapsed/duration);
            ApplyAlpha(Mathf.Lerp(startAlpha, targetAlpha, progress));

            yield return null; // wait one frame
        }

        ApplyAlpha(targetAlpha); // land exactly on the target rather than near it

        if (targetAlpha <= 0f)
        {
            fadeRenderer.enabled = false; // fully clear, so stop drawing it
        }

        activeFade = null;
    }
    #endregion

    #region Material Helpers
    private Color ReadColour()
    {
        if (fadeMaterial.HasProperty(BaseColorId))
        {
            return fadeMaterial.GetColor(BaseColorId);
        }
        return fadeMaterial.GetColor(LegacyColorId);
    }

    private void ApplyAlpha(float alpha)
    {
        Color colour = new Color(baseColour.r, baseColour.g, baseColour.b, alpha);

        if (fadeMaterial.HasProperty(BaseColorId))
        {
            fadeMaterial.SetColor(BaseColorId, colour);
        }
        else
        {
            fadeMaterial.SetColor(LegacyColorId, colour);
        }
    }
    #endregion
}