using UnityEngine;

// class that determines whether or not the npc has a shot at the player
// the npc's line of sight to the player must be unobstructed for it to have the opportunity to hit the player

public class OpportunityDetector : MonoBehaviour
{
    [SerializeField] private Transform playerHead;
    [SerializeField] private Transform npcEye; // where the npc looks from
    [SerializeField] private LayerMask coverMask; // layers that block the npc's view

    public bool IsOpportunity()
    {
        if (playerHead == null || npcEye == null)
        {
            Debug.Log("No playerHead/npcEye");
            return false;
        }

        bool visionBlocked = Physics.Linecast(npcEye.position, playerHead.position, coverMask);
        // linecast determines if anything solid sits in between two points
        // coverMask indicates what objects count as obstructions (colliders in this layer count)

        return !visionBlocked; // no obstructions, hence there is an opportunity
    }
}