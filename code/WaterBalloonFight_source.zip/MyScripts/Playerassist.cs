using UnityEngine;

// class defining the player assist values and how they impact the motion of the balloon

public class PlayerAssist : MonoBehaviour
{
    public static PlayerAssist Instance { get; private set;} // static, so any player assist uses the same instance

    // inner class to represent an assist profile
    [System.Serializable]
    public class AssistProfile
    {
        public string label;
        public float angleAssistThreshold; // how many degrees the throw must be within of the target, to get assisted
        [Range(0f, 1f)] public float directionAssist; 
        // how much the direction of the balloon is corrected to the target
        // will correct the direction of the throw by x percent
        [Range(0f, 1f)] public float speedAssist; 
        // how much the speed is boosted to the ideal speed
        // will boost the speed of the balloon by x percent of (idealSpeed - actualSpeed)
    }

    [SerializeField] private Transform target; // the target (the npc)
    [SerializeField] private float chosenFlightTime = 0.8f; // chosen t in the equation of motion (how long balloon takes to land)
    [SerializeField] private float maxAssistedSpeed = 14f; // ceiling on the speed the balloon can be boosted to
    [SerializeField] private bool logAssistNumbers = false; // prints the working out of every math step to console

    [Header("Player Assist Profiles")]
    [SerializeField] private AssistProfile noviceProfile = new AssistProfile{
        label = "Novice", angleAssistThreshold = 12f, directionAssist = 0.5f, speedAssist = 0.8f
    };
    [SerializeField] private AssistProfile intermediateProfile = new AssistProfile{
        label = "Intermediate", angleAssistThreshold = 7f, directionAssist = 0.3f, speedAssist = 0.5f
    };
    [SerializeField] private AssistProfile expertProfile = new AssistProfile{
        label = "Expert", angleAssistThreshold = 2f, directionAssist = 0.1f, speedAssist = 0.2f
    };

    // current assist profile values
    private float currentAngleAssistThreshold;
    private float currentDirectionAssist;
    private float currentSpeedAssist;

    private void Awake() // runs when object first comes into existence
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("Multiple PlayerAssists, so using newest instance");
        }
        Instance = this;
        SetProfile(SkillEvaluator.PlayerClass.Novice); // default player assist class
    }

    public void SetProfile(SkillEvaluator.PlayerClass playerClass) // changes the player's assist profile
    {
        AssistProfile p;
        switch(playerClass)
        {
            case SkillEvaluator.PlayerClass.Novice:
                p = noviceProfile;
                break;
            
            case SkillEvaluator.PlayerClass.Intermediate:
                p = intermediateProfile;
                break;
            
            case SkillEvaluator.PlayerClass.Expert:
                p = expertProfile;
                break;

            default:
                return;
        }
        currentAngleAssistThreshold = p.angleAssistThreshold;
        currentDirectionAssist = p.directionAssist;
        currentSpeedAssist = p.speedAssist;
    }

    private bool TrySolveSpeedAlongDirection(Vector3 throwOrigin, Vector3 direction, out float requiredSpeed)
    {
        // returns bool indicating if the required speed can be calculated and calculates it if so
        requiredSpeed = 0f;

        if (target == null)
        {
            return false;
        }

        Vector3 toTarget = target.position - throwOrigin;
        Vector3 toTargetHorizontal = new Vector3(toTarget.x, 0f, toTarget.z);
        float horizontalDistance = toTargetHorizontal.magnitude;
        float heightDifference = toTarget.y;

        Vector3 directionHorizontal = new Vector3(direction.x, 0f, direction.z);
        float cosTheta = directionHorizontal.magnitude;
        float sinTheta = direction.y;

        if (horizontalDistance < 0.01f || cosTheta < 0.01f)
        {
            return false;
        }

        float tanTheta = sinTheta/cosTheta;
        float denominator = 2f*cosTheta*cosTheta*(horizontalDistance*tanTheta - heightDifference);

        if (denominator <= 0.01f)
        {
            return false;
        }

        float gravityMagnitude = -Physics.gravity.y; // Physics.gravity.y is negative
        requiredSpeed = Mathf.Sqrt(gravityMagnitude*horizontalDistance*horizontalDistance/denominator);
        return true;
    }

    public void CorrectThrow(Rigidbody rb, Vector3 throwOrigin) // applies the assists to the throw
    {
        if (rb == null || target == null)
        {
            return; // do nothing
        }

        // using displacement = velocity*time + 0.5*acceleration*time*time
        // we want to calculate the perfect velocity to derive the perfect speed and perfect direction from
        // hence, we rearrange to be velocity = displacement/time - 0.5*acceleration*time
        // but since the only force acting on the throw in the air is gravity, acceleration = gravity
        // we fixed the time to be chosenFlightTime

        Vector3 actualVelocity = rb.linearVelocity;
        float actualSpeed = actualVelocity.magnitude;
        Vector3 actualDirection = actualVelocity.normalized;

        if (actualSpeed < 0.01f) // not really a throw, could be that they just dropped it, so don't apply assists
        {
            return;
        }

        // calculate the perfect velocity
        Vector3 displacement = target.position - throwOrigin;
        Vector3 perfectVelocity = (displacement/chosenFlightTime) - (0.5f*Physics.gravity*chosenFlightTime);
        float perfectSpeed = perfectVelocity.magnitude;
        Vector3 perfectDirection = perfectVelocity.normalized;

        // check if throw is eligible for direction assist
        if (Vector3.Angle(actualDirection, perfectDirection) > currentAngleAssistThreshold)
        {
            return; // don't apply direction assist
        }

        // apply direction assist
        // using Slerp because the spherical nature ensures the direction vector keeps a length of one
        // Slerp(a, b, x) finds the point which is x of the distance from a to b
        Vector3 adjustedDirection = Vector3.Slerp(actualDirection, perfectDirection, currentDirectionAssist).normalized;

        // apply speed assist
        // using Lerp because the linear nature matches that of a scalar, and speed is a scalar
        // only apply this to under throws
        float adjustedSpeed = actualSpeed; // default
        float requiredSpeed;
        if (TrySolveSpeedAlongDirection(throwOrigin, adjustedDirection, out requiredSpeed))
        {
            if (requiredSpeed > actualSpeed)
            {
                adjustedSpeed = Mathf.Lerp(actualSpeed, perfectSpeed, currentSpeedAssist); // only boost if necessary
            }
        }

        adjustedSpeed = Mathf.Min(adjustedSpeed, maxAssistedSpeed);

        if (logAssistNumbers)
        {
            Debug.Log(
                    "Assist: actual " + actualSpeed.ToString("F2") +
                    ", perfect " + perfectSpeed.ToString("F2") +
                    ", required " + requiredSpeed.ToString("F2") +
                    ", final " + adjustedSpeed.ToString("F2") +
                    ", angle off " + Vector3.Angle(actualDirection, perfectDirection).ToString("F1") + " deg" +
                    ", distance " + Vector3.Distance(throwOrigin, target.position).ToString("F2") + " m");
        }

        // update the velocity
        rb.linearVelocity = adjustedSpeed * adjustedDirection;
    }
}