using UnityEngine;

// stores the different skill levels of an npc (the lever values get set in the inspector)

public class NpcSkill : MonoBehaviour
{
    [System.Serializable]
    public class SkillProfile
    {
        public string label;
        public float throwSpread;
        public float reactionTime;
        public float deliberateMissRate;
        public float throwInterval;
    }

    public enum SkillLevel{NoviceMinus = 0, Novice = 1, Intermediate = 2, Expert = 3, ExpertPlus = 4}

    [SerializeField] private NpcThrower thrower;
    [SerializeField] private NpcController npcController;
    [SerializeField] private SkillProfile[] profiles = new SkillProfile[5];
    [SerializeField] private SkillLevel startingLevel = SkillLevel.NoviceMinus;

    private void Start()
    {
        SetSkill(startingLevel);
    }

    public void SetSkill(SkillLevel level)
    {
        int index = (int)level;

        if (profiles == null || index < 0 || index >= profiles.Length || profiles[index] == null) // safety checks
        {
            return; // do nothing
        }

        SkillProfile profile = profiles[index];
        thrower.SetThrowSpread(profile.throwSpread);
        thrower.SetComicalDeliberateMissRate(profile.deliberateMissRate);
        npcController.SetReactionTime(profile.reactionTime);
        npcController.SetThrowInterval(profile.throwInterval);
    }
}