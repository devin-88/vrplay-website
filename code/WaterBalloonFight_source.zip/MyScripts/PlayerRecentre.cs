using UnityEngine;
using Unity.XR.CoreUtils;

// moves the XR Origin so that the participant's headset ends up at a chosen spawn marker

public class PlayerRecentre : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private XROrigin xrOrigin;
    [SerializeField] private Transform spawnMarker;
    [SerializeField] private bool recentreOnStart = true;
    [SerializeField] private float startDelay = 0.5f; // gives tracking system time to report a real headset position
    #endregion

    #region Setup
    private void Awake()
    {
        if (xrOrigin == null)
        {
            xrOrigin = GetComponent<XROrigin>();
        }
    }

    private void Start()
    {
        if (recentreOnStart)
        {
            // enforce a short delay here, to account for warm up lag
            Invoke(nameof(Recentre), startDelay);
        }
    }
    #endregion

    #region Recentre
    [ContextMenu("Recentre")]
    public void Recentre()
    {
        if (xrOrigin == null || spawnMarker == null)
        {
            Debug.LogWarning("PlayerRecentre: missing XR Origin or spawn marker, cannot recentre");
            return;
        }

        Transform headset = xrOrigin.Camera.transform;

        // keep the headset's own height
        Vector3 destination = new Vector3(
            spawnMarker.position.x,
            headset.position.y,
            spawnMarker.position.z
        );

        // shifts the origin
        xrOrigin.MoveCameraToWorldLocation(destination);

        // turn the participant to face the direction the spawnpoint orientation faces
        float angleDifference = Vector3.SignedAngle(
            Vector3.ProjectOnPlane(headset.forward, Vector3.up),
            Vector3.ProjectOnPlane(spawnMarker.forward, Vector3.up),
            Vector3.up
        );
        xrOrigin.RotateAroundCameraUsingOriginUp(angleDifference);
    }
    #endregion
}