using UnityEngine;
using System.IO;

// used to capture images of the VE for the final paper

public class TopDownCapture : MonoBehaviour
{
    public Camera captureCamera;
    public int width = 3000;
    public int height = 4000;
    public string fileName = "yard_topdown.png";

    [ContextMenu("Capture")]
    public void Capture()
    {
        var rt = new RenderTexture(width, height, 24);
        captureCamera.targetTexture = rt;
        captureCamera.Render();

        RenderTexture.active = rt;
        var tex = new Texture2D(width, height, TextureFormat.RGB24, false);
        tex.ReadPixels(new Rect(0, 0, width, height), 0, 0);
        tex.Apply();

        captureCamera.targetTexture = null;
        RenderTexture.active = null;

        string path = Path.Combine(Application.dataPath, "..", fileName);
        File.WriteAllBytes(path, tex.EncodeToPNG());
        DestroyImmediate(rt);
        DestroyImmediate(tex);
        Debug.Log("Saved top-down capture to " + path);
    }
}