using UnityEngine;
using System.Collections.Generic;

// keeps the bucket stocked with water balloons.

public class BucketSpawner : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private GameObject balloonPrefab;
    [SerializeField] private int targetCount = 20; // how many balloons we want at all times
    [SerializeField] private Transform spawnPoint; // where balloons spawn
    [SerializeField] private Transform existingBalloonParent; // the object holding the balloons placed by hand
    [SerializeField] private float spawnInterval = 0.2f; // seconds between balloons spawning
    [SerializeField] private float spawnSpread = 0.12f; // offset from spawnpoint balloons can spawn within
    #endregion

    private readonly List<GameObject> balloons = new List<GameObject>(); // stores all the current existing balloons

    private void Start() 
    {
        RegisterExistingBalloons(); // must run before the first stock check, or the bucket will double up

        InvokeRepeating(nameof(MaintainStock), 0f, spawnInterval); // will continue to run repeatedly every spawnInterval seconds, without Start() running every again
        // only accepts a string for the method name, hence nameof(MaintainStock)
        // 0f to make it start running immediately
    }

    #region Stock Control
    // adds the hand placed balloons into the tracking list
    private void RegisterExistingBalloons()
    {
        if (existingBalloonParent == null)
        {
            return; // no hand placed balloons, so the bucket fills itself from scratch
        }

        for (int i = 0; i < existingBalloonParent.childCount; i++)
        {
            balloons.Add(existingBalloonParent.GetChild(i).gameObject);
        }

        Debug.Log("BucketSpawner: found " + balloons.Count + " hand placed balloons");
    }

    private void MaintainStock() // spawns a new balloon if necessary one at a time
    {
        balloons.RemoveAll(b => b == null); // removes destroyed balloons from the balloon list

        if (balloons.Count < targetCount)
        {
            SpawnBalloon();
            // spawn one new balloon
        }
    }

    private void SpawnBalloon()
    {
        Vector3 offset = new Vector3(
            Random.Range(-spawnSpread, spawnSpread),
            Random.Range(0f, spawnSpread),
            Random.Range(-spawnSpread, spawnSpread)
        );
        // randomise spawnpoints within some offset limits to avoid spawn collisions
        // cap y at 0f so the balloons dont spawn below the ground and fall forever

        GameObject balloon = Instantiate(balloonPrefab, spawnPoint.position + offset, Random.rotation);
        balloons.Add(balloon);
    }
    #endregion
}