using UnityEngine;

// responds to the player landing a balloon on the npc

public class NpcHitResponse : MonoBehaviour
{
    #region Inspector Fields
    [SerializeField] private NpcAnimationDriver animationDriver;

    [Header("Confirmation Chime")]
    [SerializeField] private AudioSource chimeSource;
    [SerializeField] private AudioClip hitChime;

    [Header("NPC Spoken Line")]
    [SerializeField] private AudioSource voiceSource;
    [SerializeField] private AudioClip[] npcGetsHitLines; // the "npc gets hit" audio base 
    [SerializeField] private float voicePitchVariation = 0.06f; // keeps repeated lines from sounding identical
    #endregion

    #region Event Subscription
    private void OnEnable()
    {
        BalloonBreak.PlayerHitNpc += HandlePlayerHit;
    }

    private void OnDisable()
    {
        BalloonBreak.PlayerHitNpc -= HandlePlayerHit;
    }
    #endregion

    #region Methods
    private void HandlePlayerHit()
    {
        PlayChime();
        PlaySpokenLine();

        if (animationDriver != null)
        {
            animationDriver.PlayHitReaction();
        }
    }

    private void PlayChime()
    {
        if (chimeSource == null || hitChime == null)
        {
            return;
        }
        chimeSource.PlayOneShot(hitChime);
    }

    private void PlaySpokenLine()
    {
        if (voiceSource == null || npcGetsHitLines == null || npcGetsHitLines.Length == 0)
        {
            return; // only play sound if there is something to play
        }

        AudioClip line = npcGetsHitLines[Random.Range(0, npcGetsHitLines.Length)];
        if (line == null)
        {
            return; // an empty slot in the sound base
        }
        
        voiceSource.pitch = 1f + Random.Range(-voicePitchVariation, voicePitchVariation);
        voiceSource.PlayOneShot(line);
    }
    #endregion
}