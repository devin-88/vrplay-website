using UnityEngine;

// Implements the guardian system: if the participant
// approaches the edge of their 1.5m ring, a glowing wall fades in to indicate they cannot go further

public class BoundaryGuardian : MonoBehaviour
{
    #region Inspector Fields
    [Header("References")]
    [SerializeField] private Transform headset; // the main camera 
    [SerializeField] private Renderer wallRenderer; // the cylinder that forms the wall

    [Header("Boundary")]
    [SerializeField] private float boundaryRadius = 1.5f; 
    [SerializeField] private float warningBand = 0.4f; // how far inside the edge the wall starts fading in

    [Header("Appearance")]
    [SerializeField] private float maxAlpha = 0.55f; // opacity of the wall when the participant is at the edge
    [SerializeField] private float fadeSpeed = 6f; // how quickly the wall catches up to its final opacity
    #endregion

    private Material wallMaterial;
    private float currentAlpha;
    private Color baseColour;

    private static readonly int BaseColorId = Shader.PropertyToID("_BaseColor");
    private static readonly int LegacyColorId = Shader.PropertyToID("_Color");

    #region Setup
    private void Awake()
    {
        if (wallRenderer == null)
        {
            Debug.LogError("BoundaryGuardian: no wall renderer assigned, guardian will not appear");
            enabled = false;
            return;
        }

        wallMaterial = wallRenderer.material;
        baseColour = ReadColour();

        currentAlpha = 0f;
        ApplyAlpha(0f);
    }
    #endregion

    #region Per Frame
    private void Update()
    {
        if (headset == null)
        {
            return;
        }

        // measure horizontally only, as height doesn't matter for the guardian ring
        Vector3 offset = headset.position - transform.position;
        offset.y = 0f;
        float distanceFromCentre = offset.magnitude;

        float targetAlpha = CalculateTargetAlpha(distanceFromCentre);

        // ease towards the target rather than snapping
        currentAlpha = Mathf.MoveTowards(currentAlpha, targetAlpha, fadeSpeed*Time.deltaTime);
        ApplyAlpha(currentAlpha);
    }

    private float CalculateTargetAlpha(float distanceFromCentre)
    {
        float warningStart = boundaryRadius - warningBand;

        if (distanceFromCentre <= warningStart)
        {
            return 0f; // comfortably inside the ring, the wall stays invisible
        }

        // fade proportionally across the warning band, so the wall becomes more opaque the closer they get
        float progress = Mathf.InverseLerp(warningStart, boundaryRadius, distanceFromCentre);
        return progress*maxAlpha;
    }
    #endregion

    #region Material Helpers
    private Color ReadColour()
    {
        if (wallMaterial.HasProperty(BaseColorId))
        {
            return wallMaterial.GetColor(BaseColorId);
        }
        return wallMaterial.GetColor(LegacyColorId);
    }

    private void ApplyAlpha(float alpha)
    {
        Color colour = new Color(baseColour.r, baseColour.g, baseColour.b, alpha);

        if (wallMaterial.HasProperty(BaseColorId))
        {
            wallMaterial.SetColor(BaseColorId, colour);
        }
        else
        {
            wallMaterial.SetColor(LegacyColorId, colour);
        }
    }
    #endregion

    #region Gizmo
    private void OnDrawGizmosSelected()
    {
        // draws the ring and the warning band in the scene view
        Gizmos.color = Color.red;
        DrawRing(boundaryRadius);

        Gizmos.color = Color.yellow;
        DrawRing(boundaryRadius - warningBand);
    }

    private void DrawRing(float radius)
    {
        const int segments = 48;
        Vector3 previousPoint = transform.position + new Vector3(radius, 0f, 0f);

        for (int i = 1; i <= segments; i++)
        {
            float angle = i/(float)segments*Mathf.PI*2f;
            Vector3 nextPoint = transform.position + new Vector3(Mathf.Cos(angle)*radius, 0f, Mathf.Sin(angle)*radius);
            Gizmos.DrawLine(previousPoint, nextPoint);
            previousPoint = nextPoint;
        }
    }
    #endregion
}