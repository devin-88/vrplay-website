using UnityEngine;

public class NpcAdvancedMoves : MonoBehaviour
{
    public enum AdvancedMove {Successive, HighVelocity, SideThrow, TwoHanded, HighThrow, Intercept} // all offensive move, intercept is a defensive move hence separate to this
    
    [SerializeField] private NpcThrower npcThrower;
    [Range(0f, 1f)] [SerializeField] private float advancedMoveProbability = 0f;

    [Header("Successive Throw")]
    [SerializeField] private float successiveThrowGap = 0.3f;

    [Header("High Velocity Throw")]
    [SerializeField] private float highVelocityFlightTime = 0.5f;

    [Header("High Throw")]
    [SerializeField] private float highThrowFlightTime = 1.4f;
    [SerializeField] private float highThrowLandInFrontBy = 1.2f;

    [Header("Two Handed Throw")]
    [SerializeField] private float twoHandedSpread = 0.5f; // metres either side of the target

    [Header("Intercept Throw")]
    [Range(0.1f, 0.9f)] [SerializeField] private float interceptFraction = 0.5f; // intercept halfway through balloon's remaining flight
    [SerializeField] private float minTimeToIntercept = 0.15f;
    [Range(0f, 1f)] [SerializeField] private float interceptProbabilityScaler = 0.2f; // probability scaler of making the defensive move, relative to the prob of offensive move
    [SerializeField] private float interceptReleaseDelay = 0.2f; // amount of time for the throwing animation to reach point where balloon is released

    private static readonly AdvancedMove[] offensiveMoves = {AdvancedMove.Successive, AdvancedMove.HighVelocity, AdvancedMove.SideThrow, AdvancedMove.TwoHanded, AdvancedMove.HighThrow};
    // pool to choose from for the offensive moves, where the only defensive move is the intercept throw

    public void SetAdvancedProbability(float prob)
    {
        advancedMoveProbability = prob;
    }

    public AdvancedMove? ChooseMove() // "?" so that returning null is allowed
    {
        if (npcThrower == null || Random.value >= advancedMoveProbability)
        {
            return null; // don't choose an advanced move
        }
        return offensiveMoves[Random.Range(0, offensiveMoves.Length)]; // randomly choose one of the offensive advanced moves
    }

    public bool ShouldIntercept() // determines if an intercept throw should be made using its prob
    {
        if (npcThrower == null)
        {
            return false;
        }

        return (Random.value < advancedMoveProbability*interceptProbabilityScaler); 
    }

    public bool CanInterceptInTime(Rigidbody incomingBalloon)
    {
        if (npcThrower == null || incomingBalloon == null)
        {
            return false;
        }
        return npcThrower.CanInterceptInTime(incomingBalloon, interceptReleaseDelay, minTimeToIntercept);
    }

    public bool ExecuteIntercept(Rigidbody incomingBalloon) // prompts for the intercept throw to occur and indicates if it occurred or if it was unviable
    {
        bool didIntercept = npcThrower.InterceptThrow(incomingBalloon, interceptFraction, minTimeToIntercept);
        return didIntercept; 
    }

    public void ExecuteThrowGeneric(AdvancedMove chosenMove, int hand) // doesn't handle side throw because thats movement related, which is controlled by the npc controller
    {
        switch (chosenMove)
        {
            case AdvancedMove.Successive:
                npcThrower.ThrowBalloon(); // the release event will call this method twice, hence making two
                break;
            case AdvancedMove.HighVelocity:
                npcThrower.ThrowBalloon(highVelocityFlightTime); // decreasing the flight time increases the velocity
                break;
            case AdvancedMove.TwoHanded:
                npcThrower.TwoHandedThrowHalf(twoHandedSpread, hand);
                break;
            case AdvancedMove.HighThrow:
                npcThrower.HighThrow(highThrowFlightTime, highThrowLandInFrontBy);
                Debug.Log("HIGH THROW");
                break;
        }
    }
}