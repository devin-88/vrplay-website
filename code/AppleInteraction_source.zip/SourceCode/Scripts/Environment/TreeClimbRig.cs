using UnityEngine;

/// <summary>
/// Holds branch platforms and a curved trunk climb path.
/// Walking is blocked by ClimbSegment capsules + TrunkWalkBlocker (a MeshCollider
/// on the non-uniformly scaled Tree cannot cook and will not stop anyone).
/// </summary>
public class TreeClimbRig : MonoBehaviour
{
    public static TreeClimbRig Instance { get; private set; }

    public Transform tree;
    public TrunkClimbPath trunkPath;
    public Transform[] platforms = new Transform[0];

    public Vector3 TrunkBase => trunkPath != null ? trunkPath.BasePosition : transform.position;

    void Awake()
    {
        Instance = this;
        EnsureCreated();
    }

    void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    public void EnsureCreated()
    {
        if (tree == null)
        {
            var found = GameObject.Find("Tree");
            if (found != null)
                tree = found.transform;
        }

        FreezeTree();

        if (trunkPath == null)
            trunkPath = GetComponent<TrunkClimbPath>();
        if (trunkPath == null)
            trunkPath = gameObject.AddComponent<TrunkClimbPath>();

        var leftover = transform.Find("ClimbTrunk");
        if (leftover != null)
            leftover.gameObject.SetActive(false);

        trunkPath.CollectWaypoints();
        if (trunkPath.Waypoints == null || trunkPath.Waypoints.Length < 2)
            CreateWaypointsFromExistingTrunk();

        EnsureTreeMeshClimb();

        // Capsules (not the MeshCollider on the scaled Tree) are what block walking.
        // Fit them to the cooked climb mesh so the solid volume matches the bark.
        if (tree != null && trunkPath != null && trunkPath.Waypoints != null && trunkPath.Waypoints.Length >= 2)
            trunkPath.FitToVisualTrunk(tree);

        CollectPlatforms();
        if (trunkPath.Waypoints != null && trunkPath.Waypoints.Length >= 2)
            trunkPath.RebuildSegments();

        EnsureTrunkWalkBlocker();
    }

    /// <summary>
    /// Extra solid capsule at the trunk base. MeshCollider on Tree cannot cook at
    /// non-uniform scale; this is what actually stops the player and squirrel.
    /// </summary>
    void EnsureTrunkWalkBlocker()
    {
        if (tree == null || trunkPath == null)
            return;

        Transform blocker = transform.Find("TrunkWalkBlocker");
        if (blocker == null)
        {
            var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
            go.name = "TrunkWalkBlocker";
            blocker = go.transform;
            blocker.SetParent(transform, true);
            var renderer = go.GetComponent<Renderer>();
            if (renderer != null)
                renderer.enabled = false;
        }

        Vector3 basePos = trunkPath.BasePosition;
        float solidRadius = Mathf.Max(trunkPath.radius, 1.85f);
        float height = 7.5f;
        blocker.position = new Vector3(basePos.x, basePos.y + height * 0.45f, basePos.z);
        blocker.rotation = Quaternion.identity;
        blocker.localScale = Vector3.one;

        var capsule = blocker.GetComponent<CapsuleCollider>();
        if (capsule == null)
            capsule = blocker.gameObject.AddComponent<CapsuleCollider>();
        capsule.direction = 1;
        capsule.radius = solidRadius;
        capsule.height = height;
        capsule.center = Vector3.zero;
        capsule.isTrigger = false;

        var rb = blocker.GetComponent<Rigidbody>();
        if (rb == null)
            rb = blocker.gameObject.AddComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.useGravity = false;

        var climb = blocker.GetComponent<UnityEngine.XR.Interaction.Toolkit.Locomotion.Climbing.ClimbInteractable>();
        if (climb != null)
            DestroyPlayModeSafe(climb);

        var obstacle = blocker.GetComponent<UnityEngine.AI.NavMeshObstacle>();
        if (obstacle == null)
            obstacle = blocker.gameObject.AddComponent<UnityEngine.AI.NavMeshObstacle>();
        obstacle.shape = UnityEngine.AI.NavMeshObstacleShape.Capsule;
        obstacle.radius = solidRadius;
        obstacle.height = height;
        obstacle.carving = true;
        obstacle.carveOnlyStationary = true;
    }

    public void EnsureTreeMeshClimb()
    {
        if (tree == null)
            return;

        if (trunkPath == null)
            trunkPath = GetComponent<TrunkClimbPath>();

        var filter = tree.GetComponent<MeshFilter>();
        if (filter == null)
            filter = tree.GetComponentInChildren<MeshFilter>();
        if (filter == null || filter.sharedMesh == null)
            return;

        // Non-convex MeshColliders cannot cook on a non-uniformly scaled tree (3, 1.5, 3).
        // Bake the visual mesh into world space on a uniformly scaled helper.
        Transform helper = transform.Find("TreeClimbMesh");
        var meshCollider = helper != null ? helper.GetComponent<MeshCollider>() : null;
        bool needsBake = helper == null || meshCollider == null ||
                         meshCollider.sharedMesh == null ||
                         meshCollider.bounds.extents.sqrMagnitude < 0.01f;

        if (helper == null)
            helper = new GameObject("TreeClimbMesh").transform;

        helper.SetParent(null);
        helper.position = Vector3.zero;
        helper.rotation = Quaternion.identity;
        helper.localScale = Vector3.one;

        if (meshCollider == null)
            meshCollider = helper.gameObject.AddComponent<MeshCollider>();

        if (needsBake)
        {
            var saved = Resources.Load<UnityEngine.Mesh>("TwistedTree_ClimbBake");
#if UNITY_EDITOR
            if (saved == null)
                saved = UnityEditor.AssetDatabase.LoadAssetAtPath<UnityEngine.Mesh>(
                    "Assets/_Recovery/TwistedTree_ClimbBake.asset");
#endif
            meshCollider.sharedMesh = saved != null ? saved : BakeWorldMesh(filter);
        }

        helper.SetParent(transform, true);
        meshCollider.convex = false;
        meshCollider.isTrigger = false;

        if (trunkPath != null)
            trunkPath.treeMesh = meshCollider;

        var provider = FindFirstObjectByType<UnityEngine.XR.Interaction.Toolkit.Locomotion.Climbing.ClimbProvider>();
        var climb = helper.GetComponent<UnityEngine.XR.Interaction.Toolkit.Locomotion.Climbing.ClimbInteractable>();
        if (climb == null)
            climb = helper.gameObject.AddComponent<UnityEngine.XR.Interaction.Toolkit.Locomotion.Climbing.ClimbInteractable>();
        climb.climbProvider = provider;
        climb.climbTransform = helper;
        climb.filterInteractionByDistance = true;
        climb.maxInteractionDistance = trunkPath != null ? trunkPath.maxHandDistance : 0.75f;
        climb.distanceCalculationMode = UnityEngine.XR.Interaction.Toolkit.Interactables.XRBaseInteractable.DistanceCalculationMode.ColliderVolume;
        climb.selectMode = UnityEngine.XR.Interaction.Toolkit.Interactables.InteractableSelectMode.Multiple;

        MakeKinematic(helper.gameObject);

        // Full-tree mesh includes canopy; CharacterController should not collide with it
        // or you get stuck under branches. Trunk ClimbSegment capsules block walking.
        IgnorePlayerTreeColliders(meshCollider);
    }

    public void IgnorePlayerTreeColliders(Collider meshCollider = null)
    {
        var controller = FindFirstObjectByType<CharacterController>();
        if (controller == null)
            return;

        if (meshCollider == null)
        {
            var helper = transform.Find("TreeClimbMesh");
            if (helper != null)
                meshCollider = helper.GetComponent<Collider>();
        }

        if (meshCollider != null)
            Physics.IgnoreCollision(controller, meshCollider, true);

        // Branch platforms are for standing after climbing, not hop landings.
        CollectPlatforms();
        for (int i = 0; i < platforms.Length; i++)
        {
            if (platforms[i] == null)
                continue;
            var col = platforms[i].GetComponent<Collider>();
            if (col != null)
                Physics.IgnoreCollision(controller, col, true);
        }

        if (tree != null)
        {
            var treePlatforms = tree.GetComponentsInChildren<Collider>(true);
            for (int i = 0; i < treePlatforms.Length; i++)
            {
                var col = treePlatforms[i];
                if (col != null && col.name.StartsWith("BranchPlatform"))
                    Physics.IgnoreCollision(controller, col, true);
            }
        }
    }

    void FreezeTree()
    {
        if (tree == null)
            return;

        var climb = tree.GetComponent<UnityEngine.XR.Interaction.Toolkit.Locomotion.Climbing.ClimbInteractable>();
        if (climb != null)
            DestroyPlayModeSafe(climb);

        // Non-convex MeshColliders do not cook on non-uniform scale (Tree is 3,1.5,3).
        // A MeshCollider on Tree will never block the player or squirrel — disable it.
        var meshCols = tree.GetComponents<MeshCollider>();
        for (int i = 0; i < meshCols.Length; i++)
        {
            if (meshCols[i] != null)
                meshCols[i].enabled = false;
        }

        MakeKinematic(tree.gameObject);
        var rb = tree.GetComponent<Rigidbody>();
        if (rb != null)
            DestroyPlayModeSafe(rb);
    }

    static void MakeKinematic(GameObject go)
    {
        var rb = go.GetComponent<Rigidbody>();
        if (rb == null)
            return;
        rb.isKinematic = true;
        rb.useGravity = false;
        rb.linearVelocity = Vector3.zero;
        rb.angularVelocity = Vector3.zero;
        rb.constraints = RigidbodyConstraints.FreezeAll;
    }

    static void DestroyPlayModeSafe(Object obj)
    {
        if (obj == null)
            return;
        if (Application.isPlaying)
            Object.Destroy(obj);
        else
            Object.DestroyImmediate(obj);
    }

    static Mesh BakeWorldMesh(MeshFilter filter)
    {
        var source = filter.sharedMesh;
        var baked = new UnityEngine.Mesh();
        baked.name = source.name + "_ClimbBake";
        var verts = source.vertices;
        var matrix = filter.transform.localToWorldMatrix;
        for (int i = 0; i < verts.Length; i++)
            verts[i] = matrix.MultiplyPoint3x4(verts[i]);
        baked.vertices = verts;
        baked.triangles = source.triangles;
        if (source.normals != null && source.normals.Length == verts.Length)
        {
            var normals = source.normals;
            for (int i = 0; i < normals.Length; i++)
                normals[i] = matrix.MultiplyVector(normals[i]).normalized;
            baked.normals = normals;
        }
        else
        {
            baked.RecalculateNormals();
        }

        baked.RecalculateBounds();
        return baked;
    }

    public Vector3 GetApproachPoint()
    {
        if (trunkPath != null)
            return trunkPath.GetApproachPoint();

        Vector3 point = TrunkBase + Vector3.forward * 1.5f;
        if (UnityEngine.AI.NavMesh.SamplePosition(point, out var hit, 4f, UnityEngine.AI.NavMesh.AllAreas))
            return hit.position;
        return point;
    }

    public Vector3 GetPerchPoint(int index = 0)
    {
        CollectPlatforms();
        if (platforms != null && platforms.Length > 0)
        {
            index = Mathf.Clamp(index, 0, platforms.Length - 1);
            if (platforms[index] != null)
                return platforms[index].position + Vector3.up * 0.15f;
        }

        if (trunkPath != null)
            return trunkPath.GetPointAlongPath(0.35f);
        return TrunkBase + Vector3.up * 1.5f;
    }

    public Vector3 GetClimbPoint(float t)
    {
        return GetClimbSurfacePoint(t, Vector3.forward);
    }

    public Vector3 GetClimbSurfacePoint(float t, Vector3 preferredOutward)
    {
        if (trunkPath != null)
            return trunkPath.GetSurfacePoint(t, preferredOutward, 0.18f);
        return TrunkBase + Vector3.up * (t * 3f);
    }

    void CollectPlatforms()
    {
        var found = new System.Collections.Generic.List<Transform>();
        foreach (Transform child in transform)
        {
            if (child.name.StartsWith("BranchPlatform"))
                found.Add(child);
        }

        found.Sort((a, b) => a.position.y.CompareTo(b.position.y));
        platforms = found.ToArray();
    }

    void CreateWaypointsFromExistingTrunk()
    {
        var oldTrunk = transform.Find("ClimbTrunk");
        Vector3 bottom;
        Vector3 top;

        if (oldTrunk != null)
        {
            var capsule = oldTrunk.GetComponent<CapsuleCollider>();
            float height = capsule != null ? capsule.height * oldTrunk.lossyScale.y : 6f;
            Vector3 up = oldTrunk.up;
            bottom = oldTrunk.position - up * (height * 0.5f);
            top = oldTrunk.position + up * (height * 0.5f);
            oldTrunk.gameObject.SetActive(false);
        }
        else
        {
            bottom = transform.position;
            top = bottom + Vector3.up * 6f;
        }

        trunkPath.EnsureDefaultWaypoints(bottom, top, 5);
    }
}
