using UnityEngine;

/// <summary>
/// Soft motes on the lowest branch that brighten when the participant is near the trunk.
/// </summary>
[RequireComponent(typeof(ParticleSystem))]
public class ClimbHintMotes : MonoBehaviour
{
    public Transform trunk;
    public float nearDistance = 2.2f;
    public float farRate = 4f;
    public float nearRate = 18f;

    ParticleSystem motes;
    ParticleSystem.EmissionModule emission;

    void Awake()
    {
        motes = GetComponent<ParticleSystem>();
        emission = motes.emission;
    }

    void Update()
    {
        if (PlayWorld.Instance == null || PlayWorld.Instance.player == null || trunk == null)
            return;

        float dist = Vector3.Distance(PlayWorld.Instance.player.position, trunk.position);
        float t = 1f - Mathf.Clamp01(dist / nearDistance);
        emission.rateOverTime = Mathf.Lerp(farRate, nearRate, t);
    }
}
