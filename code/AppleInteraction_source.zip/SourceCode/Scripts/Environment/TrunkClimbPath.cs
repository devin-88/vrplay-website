using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Climbing;

/// <summary>
/// Makes a curved trunk climbable by placing overlapping capsules between waypoints.
/// Move the Waypoint children along the bark, then the segments rebuild automatically.
/// </summary>
[ExecuteAlways]
public class TrunkClimbPath : MonoBehaviour
{
    public static TrunkClimbPath Instance { get; private set; }

    [Tooltip("World-space radius of the solid trunk. Make this large enough that you cannot walk into the bark.")]
    public float radius = 1.45f;

    [Tooltip("How close a hand must be to a capsule surface to grip.")]
    public float maxHandDistance = 0.75f;

    [Tooltip("Extra overlap between neighbouring capsules so there are no grip gaps.")]
    public float segmentOverlap = 0.45f;

    [Tooltip("Split long spans into shorter capsules so curved bark stays covered.")]
    public float maxSegmentLength = 1.15f;

    [Tooltip("Show the collision capsules in play mode so you can line them up with the bark.")]
    public bool showSegmentVisuals;

    [Tooltip("Mesh collider on the visual tree. Used to snap climb points onto the bark.")]
    public MeshCollider treeMesh;

    public float[] waypointRadii = new float[0];

    Transform[] waypoints = new Transform[0];

    public Transform[] Waypoints => waypoints;
    public Vector3 BasePosition => waypoints != null && waypoints.Length > 0 && waypoints[0] != null
        ? waypoints[0].position
        : transform.position;

    void OnEnable()
    {
        Instance = this;
        CollectWaypoints();
    }

    void Awake()
    {
        Instance = this;
        CollectWaypoints();
        if (Application.isPlaying)
            RebuildSegments();
    }

    void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    void OnValidate()
    {
        radius = Mathf.Max(0.15f, radius);
        maxHandDistance = Mathf.Max(0.1f, maxHandDistance);
    }

    [ContextMenu("Rebuild Climb Segments")]
    public void RebuildSegments()
    {
        CollectWaypoints();
        if (waypoints.Length < 2)
            return;

        ClearSegments();

        var provider = FindFirstObjectByType<ClimbProvider>();
        int segmentIndex = 0;
        for (int i = 0; i < waypoints.Length - 1; i++)
        {
            if (waypoints[i] == null || waypoints[i + 1] == null)
                continue;

            Vector3 a = waypoints[i].position;
            Vector3 b = waypoints[i + 1].position;
            float span = Vector3.Distance(a, b);
            int pieces = Mathf.Max(1, Mathf.CeilToInt(span / Mathf.Max(0.4f, maxSegmentLength)));
            float radiusA = GetWaypointRadius(i);
            float radiusB = GetWaypointRadius(i + 1);

            for (int p = 0; p < pieces; p++)
            {
                float t0 = (float)p / pieces;
                float t1 = (float)(p + 1) / pieces;
                Vector3 p0 = Vector3.Lerp(a, b, t0);
                Vector3 p1 = Vector3.Lerp(a, b, t1);
                float pieceRadius = Mathf.Lerp(radiusA, radiusB, (t0 + t1) * 0.5f);
                CreateSegment(segmentIndex++, p0, p1, pieceRadius, provider);
            }
        }
    }

    float GetWaypointRadius(int index)
    {
        if (waypointRadii != null && index >= 0 && index < waypointRadii.Length && waypointRadii[index] > 0.15f)
            return waypointRadii[index];
        return radius;
    }

    public Vector3 GetApproachPoint()
    {
        Vector3 origin = BasePosition;
        Vector3 outward = Vector3.forward;
        if (waypoints != null && waypoints.Length >= 2 && waypoints[0] != null && waypoints[1] != null)
        {
            Vector3 along = waypoints[1].position - waypoints[0].position;
            along.y = 0f;
            Vector3 side = Vector3.Cross(Vector3.up, along.sqrMagnitude > 0.01f ? along.normalized : Vector3.forward);
            outward = side.sqrMagnitude > 0.01f ? side.normalized : Vector3.forward;
        }

        Vector3 point = origin + outward * (radius + 0.9f);
        if (UnityEngine.AI.NavMesh.SamplePosition(point, out var hit, 4f, UnityEngine.AI.NavMesh.AllAreas))
            return hit.position;
        return new Vector3(point.x, origin.y, point.z);
    }

    public Vector3 GetPointAlongPath(float t)
    {
        CollectWaypoints();
        if (waypoints == null || waypoints.Length == 0)
            return transform.position;
        if (waypoints.Length == 1)
            return waypoints[0].position;

        t = Mathf.Clamp01(t);
        float total = 0f;
        for (int i = 0; i < waypoints.Length - 1; i++)
        {
            if (waypoints[i] != null && waypoints[i + 1] != null)
                total += Vector3.Distance(waypoints[i].position, waypoints[i + 1].position);
        }

        if (total < 0.001f)
            return waypoints[0].position;

        float target = t * total;
        float walked = 0f;
        for (int i = 0; i < waypoints.Length - 1; i++)
        {
            if (waypoints[i] == null || waypoints[i + 1] == null)
                continue;
            float span = Vector3.Distance(waypoints[i].position, waypoints[i + 1].position);
            if (walked + span >= target || i == waypoints.Length - 2)
            {
                float local = span < 0.001f ? 0f : (target - walked) / span;
                return Vector3.Lerp(waypoints[i].position, waypoints[i + 1].position, local);
            }
            walked += span;
        }

        return waypoints[waypoints.Length - 1].position;
    }

    public Vector3 GetPathTangent(float t)
    {
        CollectWaypoints();
        if (waypoints == null || waypoints.Length < 2)
            return Vector3.up;

        t = Mathf.Clamp01(t);
        int index = Mathf.Clamp(Mathf.FloorToInt(t * (waypoints.Length - 1.001f)), 0, waypoints.Length - 2);
        if (waypoints[index] == null || waypoints[index + 1] == null)
            return Vector3.up;

        Vector3 tangent = waypoints[index + 1].position - waypoints[index].position;
        return tangent.sqrMagnitude > 0.001f ? tangent.normalized : Vector3.up;
    }

    public Vector3 GetOutwardDirection(float t, Vector3 preferred)
    {
        Vector3 tangent = GetPathTangent(t);
        Vector3 outward = Vector3.Cross(tangent, Vector3.up);
        if (outward.sqrMagnitude < 0.001f)
            outward = Vector3.Cross(tangent, Vector3.right);
        outward.Normalize();

        Vector3 flatPreferred = preferred;
        flatPreferred.y = 0f;
        if (flatPreferred.sqrMagnitude > 0.001f && Vector3.Dot(outward, flatPreferred) < 0f)
            outward = -outward;

        return outward;
    }

    public Vector3 GetSurfacePoint(float t, Vector3 preferredOutward, float extraOffset = 0.15f)
    {
        Vector3 center = GetPointAlongPath(t);
        Vector3 outward = GetOutwardDirection(t, preferredOutward);
        float localRadius = GetRadiusAt(t);

        if (TryRaycastTree(center + outward * (localRadius + 2.2f), -outward, localRadius + 2.5f, out var hit))
            return hit.point + hit.normal * extraOffset;

        return center + outward * (localRadius + extraOffset);
    }

    public bool TryGetClosestCenterline(Vector3 worldPoint, out Vector3 closest, out Vector3 outward)
    {
        CollectWaypoints();
        closest = BasePosition;
        outward = Vector3.forward;
        if (waypoints == null || waypoints.Length < 2)
            return false;

        float best = float.MaxValue;
        bool found = false;
        for (int i = 0; i < waypoints.Length - 1; i++)
        {
            if (waypoints[i] == null || waypoints[i + 1] == null)
                continue;

            Vector3 a = waypoints[i].position;
            Vector3 b = waypoints[i + 1].position;
            Vector3 ab = b - a;
            float lengthSq = ab.sqrMagnitude;
            if (lengthSq < 0.0001f)
                continue;

            float u = Mathf.Clamp01(Vector3.Dot(worldPoint - a, ab) / lengthSq);
            Vector3 point = a + ab * u;
            float dist = (worldPoint - point).sqrMagnitude;
            if (dist < best)
            {
                best = dist;
                closest = point;
                Vector3 tangent = ab / Mathf.Sqrt(lengthSq);
                outward = Vector3.Cross(tangent, Vector3.up);
                if (outward.sqrMagnitude < 0.001f)
                    outward = Vector3.forward;
                outward.Normalize();
                Vector3 away = worldPoint - point;
                away.y = 0f;
                if (away.sqrMagnitude > 0.001f && Vector3.Dot(outward, away) < 0f)
                    outward = -outward;
                found = true;
            }
        }

        return found;
    }

    [ContextMenu("Fit Path To Visual Trunk")]
    public void FitToVisualTrunkFromMenu()
    {
        var tree = GameObject.Find("Tree");
        if (tree != null)
            FitToVisualTrunk(tree.transform);
    }

    public void FitToVisualTrunk(Transform tree)
    {
        CollectWaypoints();
        if (waypoints == null || waypoints.Length < 2)
            return;

        if (treeMesh == null)
        {
            var climbMesh = GameObject.Find("TreeClimbMesh");
            if (climbMesh != null)
                treeMesh = climbMesh.GetComponent<MeshCollider>();
        }

        if (treeMesh == null && tree != null)
        {
            var filter = tree.GetComponentInChildren<MeshFilter>();
            if (filter != null)
                treeMesh = filter.GetComponent<MeshCollider>();
        }

        waypointRadii = new float[waypoints.Length];
        Vector3 trunkHint = tree != null ? tree.position : waypoints[0].position;
        Vector3 guess = trunkHint;
        float sum = 0f;
        int counted = 0;

        for (int i = 0; i < waypoints.Length; i++)
        {
            if (waypoints[i] == null)
                continue;

            float y = waypoints[i].position.y;
            Vector3 seed = new Vector3(guess.x, y, guess.z);
            bool sampled = TrySampleSlice(seed, out Vector3 center, out float localRadius);
            if (!sampled)
            {
                seed = new Vector3(trunkHint.x, y, trunkHint.z);
                sampled = TrySampleSlice(seed, out center, out localRadius);
            }

            if (!sampled)
                sampled = TrySampleSliceNear(new Vector3(trunkHint.x, y, trunkHint.z), out center, out localRadius);

            if (sampled)
            {
                Vector3 flatDelta = center - guess;
                flatDelta.y = 0f;
                // Reject canopy / branch outliers that yank the climb path sideways.
                float maxDrift = i <= 1 ? 2.2f : 1.15f;
                if (flatDelta.magnitude > maxDrift && i > 0)
                    sampled = false;
            }

            if (sampled)
            {
                // Blend toward previous centerline so the climb path stays trunk-shaped.
                Vector3 blended = Vector3.Lerp(guess, center, i == 0 ? 1f : 0.65f);
                waypoints[i].position = new Vector3(blended.x, y, blended.z);
                waypointRadii[i] = Mathf.Clamp(localRadius + 0.35f, 0.7f, 2.6f);
                guess = waypoints[i].position;
                sum += waypointRadii[i];
                counted++;
            }
            else
            {
                // Keep the path near the visual trunk even when a slice sample fails.
                if (tree != null)
                {
                    Vector3 keep = Vector3.Lerp(guess, trunkHint, 0.35f);
                    waypoints[i].position = new Vector3(keep.x, y, keep.z);
                    guess = waypoints[i].position;
                }

                float fallback = i > 0 && waypointRadii[i - 1] > 0.15f ? waypointRadii[i - 1] : Mathf.Max(radius, 1.6f);
                waypointRadii[i] = fallback;
                sum += waypointRadii[i];
                counted++;
            }
        }

        if (counted > 0)
            radius = Mathf.Clamp(sum / counted, 0.9f, 2.8f);
    }

    bool TrySampleSliceNear(Vector3 seed, out Vector3 center, out float localRadius)
    {
        center = seed;
        localRadius = 0f;
        float[] offsets = { 0.8f, 1.6f, 2.4f };
        for (int o = 0; o < offsets.Length; o++)
        {
            for (int i = 0; i < 8; i++)
            {
                float angle = i * Mathf.PI * 0.25f;
                Vector3 trySeed = seed + new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle)) * offsets[o];
                if (TrySampleSlice(trySeed, out center, out localRadius))
                    return true;
            }
        }

        return false;
    }

    public float GetRadiusAt(float t)
    {
        CollectWaypoints();
        if (waypointRadii == null || waypointRadii.Length == 0 || waypoints == null || waypoints.Length < 2)
            return radius;

        t = Mathf.Clamp01(t);
        float scaled = t * (waypoints.Length - 1);
        int index = Mathf.Clamp(Mathf.FloorToInt(scaled), 0, waypoints.Length - 2);
        float local = scaled - index;
        float a = index < waypointRadii.Length ? waypointRadii[index] : radius;
        float b = index + 1 < waypointRadii.Length ? waypointRadii[index + 1] : radius;
        float blended = Mathf.Lerp(a, b, local);
        return blended > 0.15f ? blended : radius;
    }

    public float GetRadiusNear(Vector3 worldPoint)
    {
        if (!TryGetClosestCenterline(worldPoint, out Vector3 closest, out _))
            return radius;

        CollectWaypoints();
        if (waypoints == null || waypoints.Length < 2)
            return radius;

        float total = 0f;
        float walked = 0f;
        for (int i = 0; i < waypoints.Length - 1; i++)
        {
            if (waypoints[i] == null || waypoints[i + 1] == null)
                continue;
            total += Vector3.Distance(waypoints[i].position, waypoints[i + 1].position);
        }

        if (total < 0.001f)
            return radius;

        for (int i = 0; i < waypoints.Length - 1; i++)
        {
            if (waypoints[i] == null || waypoints[i + 1] == null)
                continue;
            float span = Vector3.Distance(waypoints[i].position, waypoints[i + 1].position);
            Vector3 a = waypoints[i].position;
            Vector3 b = waypoints[i + 1].position;
            Vector3 ab = b - a;
            float lengthSq = ab.sqrMagnitude;
            if (lengthSq < 0.0001f)
                continue;

            float u = Mathf.Clamp01(Vector3.Dot(closest - a, ab) / lengthSq);
            Vector3 point = a + ab * u;
            if ((point - closest).sqrMagnitude < 0.01f)
                return GetRadiusAt((walked + span * u) / total);
            walked += span;
        }

        return radius;
    }

    float GetSegmentRadius(int index)
    {
        if (waypointRadii == null || waypointRadii.Length == 0)
            return radius;

        float a = index < waypointRadii.Length && waypointRadii[index] > 0.15f ? waypointRadii[index] : radius;
        float b = index + 1 < waypointRadii.Length && waypointRadii[index + 1] > 0.15f ? waypointRadii[index + 1] : radius;
        return (a + b) * 0.5f;
    }

    bool TrySampleSlice(Vector3 seed, out Vector3 center, out float localRadius)
    {
        center = seed;
        localRadius = radius;
        if (treeMesh == null)
            return false;

        const int rays = 24;
        const float probe = 5.0f;
        var hits = new System.Collections.Generic.List<Vector3>(rays);
        for (int i = 0; i < rays; i++)
        {
            float angle = i * Mathf.PI * 2f / rays;
            Vector3 dir = new Vector3(Mathf.Cos(angle), 0f, Mathf.Sin(angle));
            if (TryRaycastTree(seed + dir * probe, -dir, probe + 0.25f, out var hit))
                hits.Add(hit.point);
        }

        if (hits.Count < 6)
            return false;

        var distances = new float[hits.Count];
        Vector3 sum = Vector3.zero;
        for (int i = 0; i < hits.Count; i++)
            sum += hits[i];
        Vector3 mean = sum / hits.Count;
        mean.y = seed.y;

        for (int i = 0; i < hits.Count; i++)
        {
            Vector3 flat = hits[i] - mean;
            flat.y = 0f;
            distances[i] = flat.magnitude;
        }

        System.Array.Sort(distances);
        float median = distances[distances.Length / 2];
        sum = Vector3.zero;
        int kept = 0;
        float radiusSum = 0f;
        for (int i = 0; i < hits.Count; i++)
        {
            Vector3 flat = hits[i] - mean;
            flat.y = 0f;
            if (flat.magnitude > median * 1.4f)
                continue;
            sum += hits[i];
            radiusSum += flat.magnitude;
            kept++;
        }

        if (kept < 5)
            return false;

        center = sum / kept;
        center.y = seed.y;
        localRadius = Mathf.Clamp(radiusSum / kept, 0.45f, 2.6f);
        return true;
    }

    /// <summary>
    /// Pushes a world position outside the solid trunk. Used by hop teleport so
    /// blinks cannot land inside the bark (teleports skip physics colliders).
    /// </summary>
    public Vector3 PushPointOutside(Vector3 worldPoint, float bodyRadius)
    {
        if (!TryGetClosestCenterline(worldPoint, out Vector3 closest, out Vector3 outward))
            return worldPoint;

        Vector3 flat = worldPoint - closest;
        flat.y = 0f;
        float distance = flat.magnitude;
        float minDistance = GetRadiusNear(closest) + bodyRadius;
        if (distance >= minDistance)
            return worldPoint;

        Vector3 pushDir = distance > 0.001f ? flat / distance : outward;
        pushDir.y = 0f;
        if (pushDir.sqrMagnitude < 0.001f)
            pushDir = outward;
        pushDir.Normalize();

        Vector3 result = closest + pushDir * minDistance;
        result.y = worldPoint.y;
        return result;
    }

    /// <summary>
    /// Ground-level push using the trunk base radius only. Avoids treating canopy
    /// slices as walkable hop landings.
    /// </summary>
    public Vector3 PushPointOutsideTrunkBase(Vector3 worldPoint, float bodyRadius)
    {
        Vector3 basePos = BasePosition;
        Vector3 closest = new Vector3(basePos.x, worldPoint.y, basePos.z);
        float baseRadius = GetWaypointRadius(0);
        if (baseRadius < 0.15f)
            baseRadius = Mathf.Max(radius, 1.45f);

        Vector3 flat = worldPoint - closest;
        flat.y = 0f;
        float distance = flat.magnitude;
        float minDistance = baseRadius + bodyRadius;
        if (distance >= minDistance)
            return worldPoint;

        Vector3 pushDir = distance > 0.001f ? flat / distance : Vector3.forward;
        pushDir.y = 0f;
        if (pushDir.sqrMagnitude < 0.001f)
            pushDir = Vector3.forward;
        pushDir.Normalize();

        Vector3 result = closest + pushDir * minDistance;
        result.y = worldPoint.y;
        return result;
    }

    public bool IsTreeCollider(Collider col)
    {
        if (col == null)
            return false;
        if (col.name.StartsWith("ClimbSegment"))
            return true;
        if (treeMesh == null)
            return false;
        if (col == treeMesh)
            return true;
        // Only the tree mesh subtree — not transform.root (often shared with ground).
        return col.transform.IsChildOf(treeMesh.transform);
    }

    bool TryRaycastTree(Vector3 origin, Vector3 direction, float distance, out RaycastHit hit)
    {
        hit = default;
        if (treeMesh != null && treeMesh.Raycast(new Ray(origin, direction), out hit, distance))
            return true;

        var hits = Physics.RaycastAll(origin, direction, distance, ~0, QueryTriggerInteraction.Ignore);
        float best = float.MaxValue;
        bool found = false;
        for (int i = 0; i < hits.Length; i++)
        {
            var col = hits[i].collider;
            if (col == null || col.name.StartsWith("ClimbSegment"))
                continue;
            if (treeMesh != null && col != treeMesh)
                continue;
            if (hits[i].distance < best)
            {
                best = hits[i].distance;
                hit = hits[i];
                found = true;
            }
        }

        return found;
    }

    public bool TryKeepOutside(Transform body, float bodyRadius, bool allowInside)
    {
        if (allowInside || body == null)
            return false;
        if (!TryGetClosestCenterline(body.position, out Vector3 closest, out Vector3 outward))
            return false;

        Vector3 flat = body.position - closest;
        flat.y = 0f;
        float distance = flat.magnitude;
        float minDistance = GetRadiusNear(closest) + bodyRadius;
        if (distance >= minDistance)
            return false;

        Vector3 pushDir = distance > 0.001f ? flat / distance : outward;
        pushDir.y = 0f;
        if (pushDir.sqrMagnitude < 0.001f)
            pushDir = outward;
        pushDir.Normalize();

        Vector3 push = pushDir * (minDistance - Mathf.Max(distance, 0.001f));
        var controller = body.GetComponent<CharacterController>();
        var agent = body.GetComponent<UnityEngine.AI.NavMeshAgent>();
        if (controller != null && controller.enabled)
            controller.Move(push);
        else if (agent != null && agent.enabled && agent.isOnNavMesh)
        {
            // Deep inside: Move can fail against a carved hole; Warp to the rim.
            if (distance < minDistance * 0.35f)
                agent.Warp(body.position + push);
            else
                agent.Move(push);
        }
        else
            body.position += push;
        return true;
    }

    public void EnsureDefaultWaypoints(Vector3 bottom, Vector3 top, int count = 8)
    {
        CollectWaypoints();
        if (waypoints.Length >= 2)
            return;

        count = Mathf.Max(2, count);
        for (int i = 0; i < count; i++)
        {
            var go = new GameObject("Waypoint_" + i);
            go.transform.SetParent(transform, true);
            go.transform.position = Vector3.Lerp(bottom, top, count == 1 ? 0f : i / (float)(count - 1));
        }

        CollectWaypoints();
        RebuildSegments();
    }

    public void CollectWaypoints()
    {
        var found = new System.Collections.Generic.List<Transform>();
        for (int i = 0; i < transform.childCount; i++)
        {
            var child = transform.GetChild(i);
            if (child.name.StartsWith("Waypoint"))
                found.Add(child);
        }

        found.Sort((a, b) => string.CompareOrdinal(a.name, b.name));
        waypoints = found.ToArray();
    }

    void ClearSegments()
    {
        for (int i = transform.childCount - 1; i >= 0; i--)
        {
            var child = transform.GetChild(i);
            if (!child.name.StartsWith("ClimbSegment"))
                continue;

            if (Application.isPlaying)
                Destroy(child.gameObject);
            else
                DestroyImmediate(child.gameObject);
        }
    }

    void CreateSegment(int index, Vector3 a, Vector3 b, float segmentRadius, ClimbProvider provider)
    {
        Vector3 delta = b - a;
        float length = delta.magnitude;
        if (length < 0.05f)
            return;

        var go = GameObject.CreatePrimitive(PrimitiveType.Capsule);
        go.name = "ClimbSegment_" + index;
        go.transform.SetParent(transform, true);
        go.transform.position = (a + b) * 0.5f;
        go.transform.rotation = Quaternion.FromToRotation(Vector3.up, delta / length);
        go.transform.localScale = Vector3.one;

        var renderer = go.GetComponent<Renderer>();
        if (renderer != null)
        {
            renderer.enabled = showSegmentVisuals;
            if (showSegmentVisuals)
            {
                var mat = new Material(Shader.Find("Universal Render Pipeline/Lit"));
                mat.color = new Color(0.55f, 0.35f, 0.18f, 0.35f);
                renderer.sharedMaterial = mat;
            }
        }

        var capsule = go.GetComponent<CapsuleCollider>();
        capsule.direction = 1;
        capsule.radius = segmentRadius;
        capsule.height = length + segmentOverlap;
        capsule.center = Vector3.zero;
        capsule.isTrigger = false;

        var rb = go.GetComponent<Rigidbody>();
        if (rb == null)
            rb = go.AddComponent<Rigidbody>();
        rb.isKinematic = true;
        rb.useGravity = false;

        var obstacle = go.GetComponent<UnityEngine.AI.NavMeshObstacle>();
        if (obstacle == null)
            obstacle = go.AddComponent<UnityEngine.AI.NavMeshObstacle>();
        obstacle.shape = UnityEngine.AI.NavMeshObstacleShape.Capsule;
        obstacle.radius = segmentRadius;
        obstacle.height = length + segmentOverlap;
        obstacle.carving = true;
        obstacle.carveOnlyStationary = true;

        var climb = go.GetComponent<ClimbInteractable>();
        if (climb == null)
            climb = go.AddComponent<ClimbInteractable>();
        climb.climbProvider = provider;
        climb.climbTransform = go.transform;
        climb.filterInteractionByDistance = true;
        climb.maxInteractionDistance = maxHandDistance;
        climb.distanceCalculationMode = XRBaseInteractable.DistanceCalculationMode.ColliderVolume;
        climb.selectMode = InteractableSelectMode.Multiple;
    }

    void OnDrawGizmos()
    {
        CollectWaypoints();
        if (waypoints == null || waypoints.Length == 0)
            return;

        Gizmos.color = new Color(1f, 0.7f, 0.2f, 0.9f);
        for (int i = 0; i < waypoints.Length; i++)
        {
            if (waypoints[i] == null)
                continue;
            Gizmos.DrawSphere(waypoints[i].position, 0.12f);
            if (i < waypoints.Length - 1 && waypoints[i + 1] != null)
                Gizmos.DrawLine(waypoints[i].position, waypoints[i + 1].position);
        }

        Gizmos.color = new Color(0.6f, 0.35f, 0.15f, 0.2f);
        for (int i = 0; i < waypoints.Length - 1; i++)
        {
            if (waypoints[i] == null || waypoints[i + 1] == null)
                continue;
            Vector3 mid = (waypoints[i].position + waypoints[i + 1].position) * 0.5f;
            Gizmos.DrawWireSphere(mid, GetSegmentRadius(i));
        }
    }
}
