using UnityEditor;
using UnityEngine;

[CustomEditor(typeof(TrunkClimbPath))]
public class TrunkClimbPathEditor : Editor
{
    public override void OnInspectorGUI()
    {
        DrawDefaultInspector();

        var path = (TrunkClimbPath)target;
        EditorGUILayout.Space();
        EditorGUILayout.HelpBox(
            "Move the orange Waypoint spheres along the bent trunk in the Scene view. " +
            "Capsules are rebuilt between them so the curve stays climbable. " +
            "Increase Radius if hands miss the bark.",
            MessageType.Info);

        if (GUILayout.Button("Rebuild Climb Segments"))
        {
            Undo.RegisterFullObjectHierarchyUndo(path.gameObject, "Rebuild Climb Segments");
            path.RebuildSegments();
            EditorUtility.SetDirty(path);
        }

        if (GUILayout.Button("Add Waypoint At Top"))
        {
            path.CollectWaypoints();
            var points = path.Waypoints;
            Vector3 pos = path.transform.position + Vector3.up * 2f;
            if (points != null && points.Length > 0 && points[points.Length - 1] != null)
            {
                Vector3 dir = Vector3.up;
                if (points.Length >= 2 && points[points.Length - 2] != null)
                    dir = (points[points.Length - 1].position - points[points.Length - 2].position).normalized;
                pos = points[points.Length - 1].position + dir * 1.2f;
            }

            var go = new GameObject("Waypoint_" + (points != null ? points.Length : 0).ToString("00"));
            Undo.RegisterCreatedObjectUndo(go, "Add Climb Waypoint");
            go.transform.SetParent(path.transform, true);
            go.transform.position = pos;
            path.RebuildSegments();
        }
    }

    void OnSceneGUI()
    {
        var path = (TrunkClimbPath)target;
        path.CollectWaypoints();
        var points = path.Waypoints;
        if (points == null)
            return;

        for (int i = 0; i < points.Length; i++)
        {
            if (points[i] == null)
                continue;

            EditorGUI.BeginChangeCheck();
            Vector3 next = Handles.PositionHandle(points[i].position, Quaternion.identity);
            Handles.Label(points[i].position + Vector3.up * 0.2f, points[i].name);
            if (EditorGUI.EndChangeCheck())
            {
                Undo.RecordObject(points[i], "Move Climb Waypoint");
                points[i].position = next;
                path.RebuildSegments();
                EditorUtility.SetDirty(points[i]);
            }
        }
    }
}
