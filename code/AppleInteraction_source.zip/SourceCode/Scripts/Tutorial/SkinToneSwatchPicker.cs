using TMPro;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Grid of hand-color swatches. Reads the shared HandSkinPalette (12 material slots).
/// </summary>
public class SkinToneSwatchPicker : MonoBehaviour
{
    [Header("References")]
    [SerializeField] RectTransform swatchContainer;
    [SerializeField] TextMeshProUGUI selectedLabel;
    [SerializeField] TextMeshProUGUI sectionLabel;

    [Header("Palette")]
    [Tooltip("Shared 12-slot material palette. Edit materials here for UI + hands.")]
    [SerializeField] HandSkinPalette palette;

    [Header("Layout")]
    [SerializeField] float swatchSize = 42f;
    [SerializeField] float spacing = 8f;
    [SerializeField] int columns = 6;
    [SerializeField] Color selectedOutline = new Color(1f, 1f, 1f, 0.95f);
    [SerializeField] Color idleOutline = new Color(1f, 1f, 1f, 0.2f);

    Image[] outlines;
    Image[] fills;
    int selectedIndex = (int)SkinStyle.SoftBeige;
    bool built;

    void Awake()
    {
        BindPalette();
        Rebuild();
    }

    void OnEnable()
    {
        BindPalette();
        Rebuild();
        int start = GameSettings.Instance != null ? (int)GameSettings.Instance.GetSkinStyle() : selectedIndex;
        Select(start, apply: true, notifySettings: false);
    }

#if UNITY_EDITOR
    void OnValidate()
    {
        if (palette != null)
            HandSkinCatalog.SetPalette(palette);
    }
#endif

    void BindPalette()
    {
        if (palette == null)
            palette = Resources.Load<HandSkinPalette>("HandSkinPalette");
        if (palette != null)
        {
            palette.EnsureSlotCount();
            HandSkinCatalog.SetPalette(palette);
        }
    }

    public void Rebuild()
    {
        built = false;
        BindPalette();
        EnsureBuilt();
        RefreshFillColors();
        UpdateSelectedLabel();
        RefreshVisuals();
    }

    void EnsureBuilt()
    {
        if (built && outlines != null && outlines.Length == HandSkinPalette.SlotCount)
            return;

        if (swatchContainer == null)
            swatchContainer = transform as RectTransform;

        for (int i = swatchContainer.childCount - 1; i >= 0; i--)
        {
            var child = swatchContainer.GetChild(i);
            if (!child.name.StartsWith("Swatch_"))
                continue;
            if (Application.isPlaying)
                Destroy(child.gameObject);
            else
                DestroyImmediate(child.gameObject);
        }

        outlines = new Image[HandSkinPalette.SlotCount];
        fills = new Image[HandSkinPalette.SlotCount];

        var layout = swatchContainer.GetComponent<GridLayoutGroup>();
        if (layout == null)
            layout = swatchContainer.gameObject.AddComponent<GridLayoutGroup>();
        layout.cellSize = new Vector2(swatchSize, swatchSize);
        layout.spacing = new Vector2(spacing, spacing);
        layout.constraint = GridLayoutGroup.Constraint.FixedColumnCount;
        layout.constraintCount = columns;
        layout.childAlignment = TextAnchor.UpperCenter;
        layout.padding = new RectOffset(4, 4, 4, 4);

        for (int i = 0; i < HandSkinPalette.SlotCount; i++)
        {
            int index = i;
            var root = new GameObject($"Swatch_{i}", typeof(RectTransform), typeof(Image), typeof(Button));
            root.transform.SetParent(swatchContainer, false);

            var outline = root.GetComponent<Image>();
            outline.color = idleOutline;
            outlines[i] = outline;

            var button = root.GetComponent<Button>();
            button.transition = Selectable.Transition.None;
            button.targetGraphic = outline;
            button.onClick.AddListener(() => Select(index, apply: true, notifySettings: true));

            var fillGo = new GameObject("Fill", typeof(RectTransform), typeof(Image));
            fillGo.transform.SetParent(root.transform, false);
            var fillRt = fillGo.GetComponent<RectTransform>();
            fillRt.anchorMin = new Vector2(0.12f, 0.12f);
            fillRt.anchorMax = new Vector2(0.88f, 0.88f);
            fillRt.offsetMin = Vector2.zero;
            fillRt.offsetMax = Vector2.zero;

            var fill = fillGo.GetComponent<Image>();
            fill.raycastTarget = false;
            fills[i] = fill;
        }

        built = true;
    }

    void RefreshFillColors()
    {
        if (fills == null)
            return;
        for (int i = 0; i < fills.Length; i++)
        {
            if (fills[i] != null)
                fills[i].color = HandSkinCatalog.GetSwatchColor(i);
        }
    }

    void Select(int index, bool apply, bool notifySettings)
    {
        index = HandSkinCatalog.ClampIndex(index);
        selectedIndex = index;
        RefreshVisuals();
        UpdateSelectedLabel();

        if (!apply)
            return;

        if (notifySettings && GameSettings.Instance != null)
            GameSettings.Instance.SetSkinStyle(index);
        else if (HandManager.Instance != null)
            HandManager.Instance.SetSkinStyle(index);
        else
            HandSkinCatalog.ApplyToNamedHands(index);
    }

    void UpdateSelectedLabel()
    {
        if (selectedLabel != null)
            selectedLabel.text = HandSkinCatalog.GetLabel(selectedIndex);
    }

    void RefreshVisuals()
    {
        if (outlines == null)
            return;

        for (int i = 0; i < outlines.Length; i++)
        {
            if (outlines[i] == null)
                continue;
            outlines[i].color = i == selectedIndex ? selectedOutline : idleOutline;
            outlines[i].transform.localScale = i == selectedIndex ? Vector3.one * 1.08f : Vector3.one;
        }
    }
}
