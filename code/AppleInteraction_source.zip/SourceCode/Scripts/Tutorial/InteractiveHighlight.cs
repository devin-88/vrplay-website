using System.Collections;
using UnityEngine;

[RequireComponent(typeof(Renderer))]
public class InteractiveHighlight_Tutorial : MonoBehaviour
{
    [Header("Timing")]
    [SerializeField] private float initialTime = 40f;
    [SerializeField] private float pulseFrequency = 2.5f;

    [Header("Highlight Settings")]
    [SerializeField] private Material highlightMaterialTemplate;
    [SerializeField] private float pulseWidth = 0.022f;
    [SerializeField] private float baseWidth = 0.005f;

    private Renderer rend;
    private Material highlightInstance;
    private Material[] origianlMaterials;

    private Coroutine pulseRoutine;
    private Coroutine delayedActivateRoutine;
    private bool isHighlightActive = false;
    private bool noHighlight = false;

    private void Awake()
    {
        rend = GetComponent<Renderer>();

        // Create instance to avoid modifying shared material
        highlightInstance = new Material(highlightMaterialTemplate);
        highlightInstance.SetFloat("_Width", baseWidth);
    }
    
    private void Start()
    {
        TutorialManager.OnTaskCompleted += HandleTutorialStepEnded;
        TutorialManager.OnTaskStarted += HandleTutorialStepChanged;

        // pulseWidth = pulseWidth / transform.localScale.
    }
    private void OnEnable()
    {
        //ChoiceNotifier.OnChosen += HandleChoice;
        if(noHighlight) return;
        delayedActivateRoutine = StartCoroutine(Reset());
    }

    // private IEnumerator InitialCheckRoutine()
    // {
    //     yield return new WaitForSeconds(initialTime);

    //     // if (!noHighlight)
    //     // {
    //     //     StartHighlighting();
    //     // }
    // }

    private void HandleTutorialStepEnded(TutorialTask task)
    {
        if(!isActiveAndEnabled) return;
        // noHighlight = false;
        // StopHighlighting();
        StopHighlighting();
    }
    private void HandleTutorialStepChanged(TutorialTask task)
    {
        // noHighlight = true;
        // StopHighlighting();
        if(noHighlight) return;
        if(!isActiveAndEnabled) return;

        if (delayedActivateRoutine != null)
            StopCoroutine(delayedActivateRoutine);
        delayedActivateRoutine = StartCoroutine(Reset());
    }

    private IEnumerator Reset()
    {
        StopHighlighting();
        yield return new WaitForSeconds(initialTime);
        StartHighlighting();

    }

    // =========================
    // HIGHLIGHT CONTROL
    // =========================

    private void StartHighlighting()
    {
        if (isHighlightActive) return;

        AddHighlightMaterial();
        pulseRoutine = StartCoroutine(PulseLoop());
        isHighlightActive = true;
    }

    private void StopHighlighting()
    {
        if (!isHighlightActive) return;

        if (pulseRoutine != null)
            StopCoroutine(pulseRoutine);

        RemoveHighlightMaterial();
        isHighlightActive = false;
    }

    private IEnumerator PulseLoop()
    {
        while (true)
        {
            yield return StartCoroutine(PulseOnce());
            //yield return new WaitForSeconds(pulseFrequency);
        }
    }

    private IEnumerator PulseOnce()
    {
        float duration = pulseFrequency; //* 0.5f;
        float time = 0f;

        // Expand
        while (time < duration)
        {
            float t = time / duration;
            float width = Mathf.Lerp(baseWidth, pulseWidth, t);
            highlightInstance.SetFloat("_Width", width);

            time += Time.deltaTime;
            yield return null;
        }

        // Contract
        time = 0f;
        while (time < duration)
        {
            float t = time / duration;
            float width = Mathf.Lerp(pulseWidth, baseWidth, t);
            highlightInstance.SetFloat("_Width", width);

            time += Time.deltaTime;
            yield return null;
        }
    }

    private void AddHighlightMaterial()
    {
        var mats = rend.materials;
        origianlMaterials = mats;
        Material[] newMats = new Material[mats.Length + 1];

        for (int i = 0; i < mats.Length; i++)
            newMats[i] = mats[i];

        newMats[mats.Length] = highlightInstance;

        rend.materials = newMats;
    }

    private void RemoveHighlightMaterial()
    {
        rend.materials = origianlMaterials;
    }

    private void OnDestroy()
    {
        if (pulseRoutine != null)
            StopCoroutine(pulseRoutine);
        
        TutorialManager.OnTaskCompleted -= HandleTutorialStepEnded;
        TutorialManager.OnTaskStarted -= HandleTutorialStepChanged;
    }

    public void Disable()
    {
        noHighlight = true;
        StopHighlighting();
    }
}
