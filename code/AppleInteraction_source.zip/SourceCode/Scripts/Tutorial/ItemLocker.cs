using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR.Interaction.Toolkit.Attachment;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

[RequireComponent(typeof(NearFarInteractor))]
[RequireComponent(typeof(InteractionAttachController))]
public class ItemLocker : MonoBehaviour
{
    [Header("Reference to visible tool model when locked")]
    public GameObject m_item;
    public Transform [] m_toolPositions;

    public Transform m_apHand;
    public Transform m_apTool;

    [Header("Input action to trigger lock/unlock")]
    public InputActionReference m_reference;

    public event Action OnItemLocked;
    public event Action OnItemUnlocked;

    private bool m_hasLocked = false;
    private Transform m_lockedObject;
    private Transform m_oldParent;

    private NearFarInteractor m_nearFarInteractor;
    private InteractionAttachController m_interactionAttachController;

    private void Start()
    {
        m_nearFarInteractor = GetComponent<NearFarInteractor>();
        m_interactionAttachController = GetComponent<InteractionAttachController>();
        m_hasLocked = false;

        if (m_reference != null && m_reference.action != null)
        {
            m_reference.action.performed -= HandleLockAction; // Prevent double-adding
            m_reference.action.performed += HandleLockAction;
            Debug.Log("[ItemLocker] Lock action subscribed.");
        }
        else
        {
            Debug.LogError("[ItemLocker] InputActionReference not assigned.");
        }

        if (m_item != null)
        {
            m_item.SetActive(false);
        }
        else
        {
            Debug.LogWarning("[ItemLocker] m_item (visual tool object) not assigned.");
        }

        if (m_apHand != null)
        {
            m_nearFarInteractor.attachTransform = m_apHand;
            //m_nearFarInteractor.transform.SetPositionAndRotation(m_apHand.position, m_apHand.rotation);
            m_nearFarInteractor.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            //m_interactionAttachController.transformToFollow = m_apHand;
        }
    }

    private void HandleLockAction(InputAction.CallbackContext context)
    {
        if (m_hasLocked)
        {
            Debug.Log("[ItemLocker] Unlock triggered.");
            Unlock();
            m_lockedObject = null;
            return;
        }

        if (!m_nearFarInteractor.hasSelection)
        {
            Debug.Log("[ItemLocker] No item currently held to lock.");
            return;
        }

        var interactable = m_nearFarInteractor.interactablesSelected.FirstOrDefault();
        if (interactable == null)
        {
            Debug.LogWarning("[ItemLocker] interactablesSelected list was empty.");
            return;
        }

        if (interactable.transform.CompareTag("Lockable"))
        {
            Debug.Log($"[ItemLocker] Locking object: {interactable.transform.name}");
            Lock(interactable.transform);
        }
        else
        {
            Debug.Log($"[ItemLocker] Held object '{interactable.transform.name}' is not lockable.");
        }
    }

    private void Lock(Transform trans)
    {
        m_hasLocked = true;
        m_oldParent = trans.parent;
        m_lockedObject = trans;

        trans.gameObject.SetActive(false);
        if (m_item != null)
        {
            m_item.SetActive(true);
            Debug.Log("[ItemLocker] Tool object activated.");
            if (m_apTool != null)
            {
                m_nearFarInteractor.attachTransform = m_apTool;
                //m_interactionAttachController.transformToFollow = m_apTool;
                m_nearFarInteractor.transform.SetPositionAndRotation(m_apTool.position, m_apTool.rotation);
                //m_nearFarInteractor.GetComponent<InteractionAttachController>().transformToFollow = m_apTool.transform;
            }
            OnItemLocked?.Invoke();
        }
    }

    private Transform Unlock()
    {
        if (m_lockedObject == null)
        {
            Debug.LogWarning("[ItemLocker] No locked object to unlock.");
            return null;
        }

        m_lockedObject.SetPositionAndRotation(m_item.transform.position, m_item.transform.rotation);
        m_lockedObject.gameObject.SetActive(true);
        if (m_apHand != null)
        {
            m_nearFarInteractor.attachTransform = m_apHand;
            //m_nearFarInteractor.transform.SetPositionAndRotation(m_apHand.position, m_apHand.rotation);
            m_nearFarInteractor.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
            //m_interactionAttachController.transformToFollow = m_apHand;
        }
        OnItemUnlocked?.Invoke();
        Debug.Log($"[ItemLocker] Unlocked and restored object: {m_lockedObject.name}");

        if (m_item != null)
        {
            m_item.SetActive(false);
        }

        m_hasLocked = false;
        return m_lockedObject;
        //

    }

    private void OnDestroy()
    {
        if (m_reference != null && m_reference.action != null)
        {
            m_reference.action.performed -= HandleLockAction;
        }
    }

    public void ResetLocker()
    {
        if (!m_hasLocked) return;
        Unlock();
        m_lockedObject.gameObject.SetActive(false);
        m_lockedObject = null;
    }

    private void OnEnable()
    {
        foreach (Transform tfx in m_toolPositions)
        {
            if (tfx.gameObject.activeInHierarchy)
            {
                Debug.Log(tfx.name);
                m_item.transform.SetParent(tfx.transform, false);
                m_item.transform.SetLocalPositionAndRotation(Vector3.zero, Quaternion.identity);
                m_item.transform.localScale = Vector3.one;
                m_item.SetActive(false); //TODO: CHECK IF DISABLES AT WEIRD TIMES
            }
        }
    }
}
