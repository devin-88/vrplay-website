using System;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;
using UnityEngine.Windows.Speech;

public class KeyWordRecognizerClass : MonoBehaviour
{
    public Animator animator;
    public GameObject door;

    private KeywordRecognizer keywordRecognizer;
    private Dictionary<string, Action> actions = new Dictionary<string, Action>();

    // 🔔 This event allows external listeners to respond to recognized commands
    public static event Action<string> OnCommandRecognized;

    void Start()
    {
        actions.Add("test", Test);
        //*
        actions.Add("sit", Sit);
        //*
        actions.Add("down", Down);
        actions.Add("done", Down);
        //*
        actions.Add("come", Come);
        actions.Add("calm", Come);
        actions.Add("gum", Come);
        //*
        actions.Add("paw", Paw);
        actions.Add("open", Open);
        actions.Add("stop", Stop);
        actions.Add("End", End);
        actions.Add("next", Next);

        keywordRecognizer = new KeywordRecognizer(actions.Keys.ToArray());
        keywordRecognizer.OnPhraseRecognized += RecognizedSpeech;
        keywordRecognizer.Start();
    }

    private void Next()
    {
        //DO NOTHING HERE
    }

    private void End() => animator.SetTrigger("End");
    private void Stop()
    {
        keywordRecognizer.Stop();
        Debug.Log("Ending Voice Recognition ---");
    }
    private void Open() => Debug.Log("Door opens");
    private void Paw() => Debug.Log("Dog is prompted to Paw");
    private void Come() => Debug.Log("Dog is prompted to Come");
    private void Down()
    {
        if (animator == null)
        {
            Debug.Log("Animator not found.");
        }
        else
        {
            animator.SetTrigger("Down");
        }
    }
    private void Sit()
    {
        if (animator == null)
        {
            Debug.Log("Animator not found.");
        }
        else
        {
            animator.SetTrigger("Sit");
        }
    }
    private void Test() => Debug.Log("Testing Voice Recognition -----");

    private void RecognizedSpeech(PhraseRecognizedEventArgs speech)
    {
        string command = speech.text;
        Debug.Log("Recognized: " + command);

        // 🔔 Call the corresponding action
        if (actions.ContainsKey(command))
            actions[command].Invoke();

        // 🔔 Broadcast to any listeners (like your tutorial task)
        OnCommandRecognized?.Invoke(command);
    }

    private void OnDestroy()
    {
        OnCommandRecognized = null; // avoid memory leaks or lingering listeners
    }
}

// using System;
// using System.Collections;
// using System.Collections.Generic;
// using System.Linq;
// using System.Runtime.CompilerServices;
// using UnityEngine;
// using UnityEngine.Windows.Speech;

// public class KeyWordRecognizerScript : MonoBehaviour
// {
//     public Animator animator;
//     public GameObject door;
//     private KeywordRecognizer keywordRecognizer;
//     private Dictionary<string, Action> actions = new Dictionary<string, Action>();
//     // Start is called before the first frame update
//     void Start()
//     {
//         actions.Add("test", Test);
//         actions.Add("sit", Sit);
//         actions.Add("down", Down);
//         actions.Add("come", Come);
//         actions.Add("paw", Paw);
//         actions.Add("open", Open);
//         actions.Add("stop", Stop);
//         actions.Add("End", End);

//         keywordRecognizer = new KeywordRecognizer(actions.Keys.ToArray());
//         keywordRecognizer.OnPhraseRecognized += RecognizedSpeech;
//         keywordRecognizer.Start();
//     }

//     private void End()
//     {
//         Debug.Log("Animation Ending...");
//         animator.SetTrigger("End");
//     }

//     private void Stop()
//     {
//         keywordRecognizer.Stop();
//         Debug.Log("Ending Voice Recognition ---");
//     }

//     private void Open()
//     {
//         Debug.Log("Door opens");
//     }

//     private void Paw()
//     {
//         Debug.Log("Dog is prompted to Paw");
//     }

//     private void Come()
//     {
//         Debug.Log("Dog is prompted to Come");
//     }

//     private void Down()
//     {
//         Debug.Log("Dog is prompted to lie Down");
//         animator.SetTrigger("Down");
//     }

//     private void Sit()
//     {
//         Debug.Log("Dog is prompted to Sit");
//         animator.SetTrigger("Sit");
//     }

//     private void Test()
//     {
//         Debug.Log("Testing Voice Recognition -----");
//     }

//     private void RecognizedSpeech(PhraseRecognizedEventArgs speech)
//     {
//         Debug.Log(speech.text);
//         actions[speech.text].Invoke();
        
//     }
// }
