using TMPro;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactors;

public enum HandStyle
{
    FemaleHand,
    MaleHand,
    Controller,
    Current
}

public enum SkinStyle
{
    Porcelain = 0,
    FairRose = 1,
    LightPeach = 2,
    WarmIvory = 3,
    SoftBeige = 4,
    GoldenSand = 5,
    HoneyTan = 6,
    WarmOlive = 7,
    Caramel = 8,
    Chestnut = 9,
    RichBrown = 10,
    DeepEspresso = 11
}

[System.Flags]
public enum ControlsUI
{
    None = 0,
    Trigger = 1 << 0,
    Grip = 1 << 1,
    Trackpad = 1 << 2,
    Wheel = 1 << 3,
    Menu = 1 << 4,
}

[System.Flags]
public enum ControlFlags
{
    None = 0,
    Direct = 1 << 0,
    Poke = 1 << 1,
    Ray = 1 << 2,
    Teleport = 1 << 3,
    Snap = 1 << 4,
}

public class HandManager : MonoBehaviour
{
    public static HandManager Instance { get; private set; }

    [Header("Left Hand Models")]
    public GameObject[] leftStyleModels;

    [Header("Right Hand Models")]
    public GameObject[] rightStyleModels;

    [Header("Female Skin Styles")]
    public Material[] femaleSkinStyles;

    [Header("Male Skin Styles")]
    public Material[] maleSkinStyles;

    [Header("Control UI Tooltips")]
    public GameObject[] rightTooltips;
    public GameObject[] leftTooltips;

    public TextMeshProUGUI[] triggerTexts = null;

    [Header("Dominance Dependent Objects")]
    public GameObject[] rightInteractors;
    public GameObject[] leftInteractors;

    [Header("Project Hands Mode")]
    [Tooltip("When true, Female/Male both show the Oculus project hands; Controller hides them.")]
    public bool projectHandsMode;
    public GameObject projectLeftHand;
    public GameObject projectRightHand;

    private HandStyle leftHandStyle;
    private HandStyle rightHandStyle;

    private ControlsUI visibleControls;
    private ControlFlags visibleInteractors;

    private void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Destroy(gameObject);
            return;
        }
        Instance = this;
    }

    void OnEnable()
    {
        GameSettings.OnHandednessChanged += HandleHandednessChanged;
    }

    void OnDisable()
    {
        GameSettings.OnHandednessChanged -= HandleHandednessChanged;
    }

    private void HandleHandednessChanged(bool leftHanded)
    {
        if (leftHanded)
        {
            UpdateUIControls(leftTooltips);
            if (rightTooltips != null)
                foreach (GameObject callout in rightTooltips)
                    if (callout) callout.SetActive(false);

            ClearInteractors(rightInteractors);
            UpdateInteractors(leftInteractors);
        }
        else
        {
            UpdateUIControls(rightTooltips);
            if (leftTooltips != null)
                foreach (GameObject callout in leftTooltips)
                    if (callout) callout.SetActive(false);

            ClearInteractors(leftInteractors);
            UpdateInteractors(rightInteractors);
        }

        HandStyle lhs = leftHandStyle;
        HandStyle rhs = rightHandStyle;
        SetHandStyleRight(lhs);
        SetHandStyleLeft(rhs);
    }

    public void SetHandStyle(HandStyle style)
    {
        if (style == HandStyle.Current)
        {
            if (rightHandStyle == HandStyle.Controller)
            {
                style = leftHandStyle;
                SetHandStyleRight(style);
            }
            if (leftHandStyle == HandStyle.Controller)
            {
                style = rightHandStyle;
                SetHandStyleLeft(style);
            }
        }
        else
        {
            SetHandStyleLeft(style);
            SetHandStyleRight(style);
        }
    }

    public void SetHandStyle(int index)
    {
        HandStyle style = index == 0 ? HandStyle.FemaleHand : HandStyle.MaleHand;
        if (index != 0 && index != 1)
        {
            Debug.Log("Invalid Hand style option chosen.");
            return;
        }

        // Project Oculus hands: both controllers keep visible hand meshes.
        if (projectHandsMode)
        {
            SetHandStyleLeft(style);
            SetHandStyleRight(style);
            return;
        }

        if (GameSettings.Instance.IsLeftHanded())
        {
            SetHandStyleRight(style);
            SetHandStyleLeft(HandStyle.Controller);
        }
        else
        {
            SetHandStyleLeft(style);
            SetHandStyleRight(HandStyle.Controller);
        }
    }

    public void SetHandStyleMove(HandStyle style)
    {
        // Project mode keeps Oculus hands on both controllers (no Vive move hand).
        if (projectHandsMode)
            style = HandStyle.MaleHand;

        if (GameSettings.Instance.IsLeftHanded()) SetHandStyleRight(style);
        else SetHandStyleLeft(style);
    }

    public void SetHandStyleGrab(HandStyle style)
    {
        if (GameSettings.Instance.IsLeftHanded()) SetHandStyleLeft(style);
        else SetHandStyleRight(style);
    }

    public void SetHandStyleLeft(HandStyle style)
    {
        if (projectHandsMode)
        {
            if (projectLeftHand != null)
                projectLeftHand.SetActive(style != HandStyle.Controller);
            leftHandStyle = style == HandStyle.Controller ? HandStyle.MaleHand : style;
            return;
        }

        if (leftStyleModels == null)
            return;

        HandStyle index = 0;
        foreach (GameObject model in leftStyleModels)
        {
            if (model != null)
                model.SetActive(style == index);
            index++;
        }
        leftHandStyle = style;
    }

    public void SetHandStyleRight(HandStyle style)
    {
        if (projectHandsMode)
        {
            if (projectRightHand != null)
                projectRightHand.SetActive(style != HandStyle.Controller);
            rightHandStyle = style == HandStyle.Controller ? HandStyle.MaleHand : style;
            return;
        }

        if (rightStyleModels == null)
            return;

        HandStyle index = 0;
        foreach (GameObject model in rightStyleModels)
        {
            if (model != null)
                model.SetActive(style == index);
            index++;
        }
        rightHandStyle = style;
    }

    public HandStyle GetRightHandStyle() => rightHandStyle;
    public HandStyle GetLeftHandStyle() => leftHandStyle;

    public void SetSkinStyle(SkinStyle skinStyle)
    {
        SetSkinStyle((int)skinStyle);
    }

    public void SetSkinStyle(int index)
    {
        index = HandSkinCatalog.ClampIndex(index);

        // Keep HandManager arrays in sync with the shared palette when available.
        var paletteMats = HandSkinCatalog.GetMaterials();
        if (paletteMats != null && paletteMats.Length > 0 && paletteMats[0] != null)
        {
            femaleSkinStyles = paletteMats;
            maleSkinStyles = paletteMats;
        }

        if (projectHandsMode)
        {
            ApplySkinToHand(projectLeftHand, index);
            ApplySkinToHand(projectRightHand, index);
            return;
        }

        ApplySkinToModelSlot(leftStyleModels, 0, femaleSkinStyles, index);
        ApplySkinToModelSlot(rightStyleModels, 0, femaleSkinStyles, index);
        ApplySkinToModelSlot(leftStyleModels, 1, maleSkinStyles, index);
        ApplySkinToModelSlot(rightStyleModels, 1, maleSkinStyles, index);
    }

    void ApplySkinToHand(GameObject hand, int index)
    {
        if (hand == null)
            return;

        // Palette materials are the source of truth.
        Material mat = HandSkinCatalog.GetMaterial(index);
        if (mat == null && femaleSkinStyles != null && index >= 0 && index < femaleSkinStyles.Length)
            mat = femaleSkinStyles[index];
        if (mat == null && maleSkinStyles != null && index >= 0 && index < maleSkinStyles.Length)
            mat = maleSkinStyles[index];

        if (mat != null)
        {
            foreach (var smr in hand.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                smr.material = mat;
            foreach (var mr in hand.GetComponentsInChildren<MeshRenderer>(true))
                mr.material = mat;
            return;
        }

        HandSkinCatalog.ApplyToHand(hand, index);
    }

    static void ApplySkinToModelSlot(GameObject[] models, int slot, Material[] skins, int index)
    {
        if (models == null || slot < 0 || slot >= models.Length || models[slot] == null)
            return;
        if (skins == null || index < 0 || index >= skins.Length || skins[index] == null)
            return;

        var smr = models[slot].GetComponentInChildren<SkinnedMeshRenderer>(true);
        if (smr != null)
            smr.material = skins[index];
    }

    public void SetTriggerTooltip(string tooltip)
    {
        if (triggerTexts == null)
            return;
        foreach (TextMeshProUGUI tmp in triggerTexts)
        {
            if (tmp != null)
                tmp.text = tooltip;
        }
    }

    public void SetVisibleUI(ControlsUI newControls)
    {
        this.visibleControls = newControls;
        if (GameSettings.Instance == null)
            return;
        if (GameSettings.Instance.IsLeftHanded()) UpdateUIControls(leftTooltips);
        else UpdateUIControls(rightTooltips);
    }

    private void UpdateUIControls(GameObject[] handedList)
    {
        if (handedList == null || handedList.Length < 5)
            return;

        // In project mode, Vive trackpad callouts are misleading — only show trigger.
        if (projectHandsMode)
        {
            for (int i = 0; i < handedList.Length; i++)
            {
                if (handedList[i] == null) continue;
                handedList[i].SetActive(i == 0 && visibleControls.HasFlag(ControlsUI.Trigger));
            }
            return;
        }

        handedList[0].SetActive(this.visibleControls.HasFlag(ControlsUI.Trigger));
        handedList[1].SetActive(this.visibleControls.HasFlag(ControlsUI.Menu));
        handedList[2].SetActive(this.visibleControls.HasFlag(ControlsUI.Trackpad));
        handedList[3].SetActive(this.visibleControls.HasFlag(ControlsUI.Trackpad));
        handedList[4].SetActive(this.visibleControls.HasFlag(ControlsUI.Trackpad));
    }

    public void SetVisibleInteractors(ControlFlags newInteractors)
    {
        this.visibleInteractors = newInteractors;
        if (GameSettings.Instance == null)
            return;
        if (GameSettings.Instance.IsLeftHanded())
            UpdateInteractors(leftInteractors);
        else
            UpdateInteractors(rightInteractors);
    }

    private void UpdateInteractors(GameObject[] handedInteractors)
    {
        if (handedInteractors == null || handedInteractors.Length < 4)
            return;

        if (handedInteractors[1] != null)
            handedInteractors[1].SetActive(this.visibleInteractors.HasFlag(ControlFlags.Poke));
        if (handedInteractors[2] != null)
            handedInteractors[2].SetActive(this.visibleInteractors.HasFlag(ControlFlags.Teleport));

        // Turn provider is not a hand interactor — never gate it on Teleport in project mode.
        if (handedInteractors[3] != null)
        {
            if (projectHandsMode)
                handedInteractors[3].SetActive(true);
            else
                handedInteractors[3].SetActive(this.visibleInteractors.HasFlag(ControlFlags.Teleport));
        }

        if (handedInteractors[0] != null)
        {
            bool showNearFar = this.visibleInteractors.HasFlag(ControlFlags.Ray)
                               || this.visibleInteractors.HasFlag(ControlFlags.Direct);
            handedInteractors[0].SetActive(showNearFar);
            var nearFar = handedInteractors[0].GetComponent<NearFarInteractor>();
            if (nearFar != null)
            {
                // Keep far casting on whenever the interactor is used so grab lines stay visible.
                nearFar.enableFarCasting = showNearFar;
                nearFar.enableNearCasting = this.visibleInteractors.HasFlag(ControlFlags.Direct)
                                            || this.visibleInteractors.HasFlag(ControlFlags.Ray);
            }

            // Ensure curve line visuals stay available.
            foreach (var lr in handedInteractors[0].GetComponentsInChildren<LineRenderer>(true))
            {
                if (lr != null && lr.gameObject.name.Contains("LineVisual"))
                    lr.gameObject.SetActive(showNearFar);
            }
        }
    }

    private void ClearInteractors(GameObject[] handedInteractors)
    {
        if (handedInteractors == null)
            return;
        foreach (GameObject handedInteractor in handedInteractors)
        {
            if (handedInteractor != null)
                handedInteractor.SetActive(false);
        }
    }
}
