using System;
using System.Collections.Generic;
using Unity.VRTemplate;
using UnityEngine;
using UnityEngine.UI;

public class TutorialManager : MonoBehaviour
{

    public static event Action<TutorialTask> OnTaskCompleted;
    public static event Action<TutorialTask> OnTaskStarted;
    public static event Action OnTutorialStarted;
    public static event Action OnTutorialCompleted;

    public AudioClip m_completionSound;
    [SerializeField] private List<TutorialTask> m_tutorialTasks;

    [SerializeField] private StepManager m_stepManager;

    [SerializeField] private Button m_skipButton;
    private int m_currentTaskIndex = 0;
    private float m_tutorialStartTime;
    //private AudioSource m_audioSource;

    private void Awake()
    {
        if(m_tutorialTasks.Count == 0)
        {
            Debug.LogError("No tutorial tasks assigned to TutorialManager.");
        }
        else foreach (var task in m_tutorialTasks) task.gameObject.SetActive(false);

        //m_audioSource = GetComponent<AudioSource>();
    }

    private void OnEnable()
    {
        if (m_skipButton != null)
        {
            m_skipButton.onClick.AddListener(OnTaskComplete);
        }
    }

    private void Start()
    {
        
        m_tutorialStartTime = Time.time;
        OnTutorialStarted?.Invoke(); //Check any subscribers to event + trigger.

        if (m_tutorialTasks.Count > 0)
        {
            StartTask(m_currentTaskIndex);
        }

        GameSettings.Instance.SetHandedness(true); //righthanded - triggers on changed events
        
    }

    private void Update()
    {
        // if (m_tutorialTasks.Count == 0) return;

        // //if(m_tutorialTasks[m_currentTaskIndex].IsTaskComplete())
        // {
        //     CompleteCurrentTask();
        // }

#if UNITY_EDITOR
        CheckTutorialDebug();
#endif
    }

    private void StartTask(int index)
    {
        if (index >= 0 && index < m_tutorialTasks.Count)
        {
            m_tutorialTasks[index].gameObject.SetActive(true);
            m_tutorialTasks[index].StartTask(OnTaskComplete); //NB method - should clear all
            OnTaskStarted?.Invoke(m_tutorialTasks[index]);    //Pass new task to event

            m_stepManager.ToStep(index);
        }
        // else
        // {
        //     Debug.Log("Tutorial complete.");
        // }
    }

    //Callback function for TutorialTask class
    private void OnTaskComplete()
    {
        CompleteCurrentTask();
    }

    private void CompleteCurrentTask()
    {
        Debug.Log($"Manually Completing task: {m_currentTaskIndex}");
        var task = m_tutorialTasks[m_currentTaskIndex];
        OnTaskCompleted?.Invoke(task);
        //if (m_completionSound && m_audioSource) m_audioSource.PlayOneShot(m_completionSound);
        m_tutorialTasks[m_currentTaskIndex].gameObject.SetActive(false); //Clear objects from previous task

        m_currentTaskIndex++;
        if (m_currentTaskIndex < m_tutorialTasks.Count)
        {
            StartTask(m_currentTaskIndex);
        }
        else
        {
            //m_skipButton.onClick.RemoveListener(OnTaskComplete);
            OnTutorialCompleted?.Invoke();
        }
        
    }

    private void RestartCurrentTask()
    {
        //m_tutorialTasks[m_currentTaskIndex] Reset task
        StartTask(m_currentTaskIndex);
    }

    private void PreviousTask()
    {
        if (m_currentTaskIndex == 0) return;
        m_tutorialTasks[m_currentTaskIndex].gameObject.SetActive(false);
        m_currentTaskIndex--;
        StartTask(m_currentTaskIndex); //Does this not imply that StartTask resets tasks? How to clear?
    }

    private void JumpToTask(int index)
    {
        if (index < 0 || index >= m_tutorialTasks.Count) return;
        m_tutorialTasks[m_currentTaskIndex].gameObject.SetActive(false);
        m_currentTaskIndex = index;
        StartTask(m_currentTaskIndex);       //Assumed StartTask Clears
    }

#if UNITY_EDITOR
    private void CheckTutorialDebug()
    {
        for (int i = 0; i < m_tutorialTasks.Count; i++)
        {
            if (Input.GetKeyDown(KeyCode.Alpha1 + i))
            {
                if (Input.GetKeyDown(KeyCode.LeftAlt))
                {
                    JumpToTask(i);    
                }
                else
                {
                    Debug.Log($"Forcefully completing Task {i}");
                    m_tutorialTasks[i].ForceCompleteTask();
                }
            }
        }

        if (Input.GetKeyDown(KeyCode.BackQuote)) // ` key to restart task
        {
            RestartCurrentTask();
        }
        else if (Input.GetKeyDown(KeyCode.Minus)) // - key to go back
        {
            PreviousTask();
        }

    }
#endif
}
