using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.UI;

public class VoiceCommandTask : TutorialTask
{
    // [Tooltip("List of expected voice commands the user must say.")]
    // public List<string> voiceCommands;

    // [Tooltip("Text element showing instructions.")]
    // public Text instructionsText;

    //[Tooltip("One Text element per command, to update visually as they are completed.")]
    //[SerializeField] private List<TextMeshProUGUI> m_labels;
    [SerializeField] private TextMeshProUGUI m_instruction;


    [Serializable]
    class Command
    {
        [SerializeField] public string word;
        public bool status;

        [SerializeField] public TextMeshProUGUI label;

        [SerializeField] public PlayableAsset asset;
    }
    //[SerializeField] private Dictionary<string, bool> voiceCommands;
    [SerializeField] private List<Command> m_commandList = new List<Command>();
    //private KeyWordRecognizerClass m_keywordRecognizer;
    [SerializeField] private Color m_incompleteColor = Color.red;
    [SerializeField] private Color m_completeColor = Color.green;

    [SerializeField] private Color m_confirmColor = Color.blue;

    [SerializeField] private PlayableDirector m_director;

    [TextArea]
    [SerializeField]
    private string m_TASK1 =
        "Speak each <i><color=\"red\">Voice Command</color></i> clearly.\n You may practise each each <color=\"green\">recognised word</color>.";

    [TextArea]
    [SerializeField]
    private string m_TASK2 =
        "Speak <color=#2096F3>\"Next\"</color> aloud to continue.";
    private void Awake()
    {
        //commandCompletionStatus = new Dictionary<string, bool>();
        //m_instruction.text = "Each of these words are voice-commands you are able to use in the environment - speak each aloud now.";
    }

    public override void StartTask(Action onComplete)
    {
        if (isStarted) return;

        Debug.Log("Voice Command Task beginning...");
        onTaskComplete = onComplete;
        m_instruction.text = m_TASK1;

        //m_keywordRecognizer = FindObjectOfType<KeyWordRecognizerClass>();

        // if (m_keywordRecognizer == null)
        // {
        //     Debug.LogError("Voice Recognition system not found in the scene.");
        //     return;
        // }

        //m_keywordRecognizer.OnCommandRecognized += HandleCommandRecognized;
        KeyWordRecognizerClass.OnCommandRecognized += HandleCommandRecognized;
        m_director.playableAsset = null;
        //m_commandList.Clear();
        for (int i = 0; i < m_commandList.Count; i++)
        {
            m_commandList[i].label.text = m_commandList[i].word;
            m_commandList[i].word = m_commandList[i].word.ToLower();
            m_commandList[i].status = false;
            m_commandList[i].label.color = m_incompleteColor;
            m_commandList[i].label.fontStyle = FontStyles.Normal;
        }
        m_commandList[3].label.color = Color.grey; //Confirm

        HandManager.Instance.SetVisibleUI(ControlsUI.None);
        HandManager.Instance.SetVisibleInteractors(ControlFlags.None);
        HandManager.Instance.SetHandStyle(HandStyle.Current);
        //HandManager.Instance.SetHandStyleMove(HandStyle.Controller);

    }

    public override void ResetTask()
    {
        isStarted = false;
        StartTask(onTaskComplete);
    }

    public override void ForceCompleteTask()
    {
        CompleteTask("Forced");
    }

    private void HandleCommandRecognized(string command)
    {
        Debug.Log("Entering handler: " + command);
        for (int i = 0; i < m_commandList.Count - 1; i++) //Dont include confirm
        {
            if (!m_commandList[i].word.Equals(command))
            {
                m_commandList[i].label.fontStyle = FontStyles.Normal;
                continue;
            }
            Debug.Log("Task recognition - success: " + command);
            m_commandList[i].status = true;
            m_commandList[i].label.color = m_completeColor;
            m_commandList[i].label.fontStyle = FontStyles.Bold | FontStyles.Italic;
            if (m_commandList[i].asset != null) m_director.playableAsset = m_commandList[i].asset;
            m_director.Play();

            SFXManager.Instance.PlayCompletionSound();
        }

        if (AllCommandsCompleted())
        {
            m_commandList[3].label.color = m_confirmColor;
            m_instruction.text = m_TASK2;
            if (m_commandList[3].word.Equals(command)) CompleteTask("Manually");
        }
    }

    private bool AllCommandsCompleted()
    {
        // foreach (var command in m_commandList)
        // {
        //     if (!command.status) return false;
        // }
        for (int i = 0; i < m_commandList.Count - 1; i++) //Dont include confirm
        {
            if (!m_commandList[i].status) return false;
        }
        return true;
    }

    private void CompleteTask(string method)
    {
        Debug.Log($"Voice Task Completed - {method}");
        //m_keywordRecognizer.OnCommandRecognized -= HandleCommandRecognized;
        KeyWordRecognizerClass.OnCommandRecognized -= HandleCommandRecognized;
        onTaskComplete?.Invoke();
    }

#if UNITY_EDITOR  
    private void Update()
    {
        //For testing only  
        if (Input.GetKeyDown(KeyCode.P))
        {
            ForceCompleteTask();
        }
    }
#endif

    // private void UpdateCommandUI(int index, bool completed)
    // {
    //     if (index >= 0 && index < commandTexts.Count)
    //     {
    //         commandTexts[index].text = voiceCommands[index] + (completed ? " ✔" : " ✖");
    //         commandTexts[index].color = completed ? Color.green : Color.red;
    //     }
    //     commandTexts[index].tr
    // }
}
