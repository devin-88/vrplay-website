using System;
using UnityEngine;


public class GestureRecognizer : MonoBehaviour
{

    public static GestureRecognizer Instance { get; private set; }
    public static event Action<string> OnGestureRecognized;

    [Tooltip("The AudioClip to play when the whistle gesture is detected.")]
    public AudioClip m_whistleClip;

    public AudioSource m_audioSource;

    public GameObject m_RH;
    public GameObject m_LH;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("Duplicate GestureRecognizer instance detected. Destroying new one.");
            Destroy(gameObject);
            return;
        }

        Instance = this;
    }

    private void Start()
    {
        //audioSource = GetComponent<AudioSource>();
        if (!m_audioSource)
        {
            m_audioSource = gameObject.AddComponent<AudioSource>();
            m_audioSource.playOnAwake = false;
        }
    }

    private void Update()
    {
        //For testing only  
        if (Input.GetKeyDown(KeyCode.P))
        {
            Recognize("Whistle");

        }
    }

    // private void OnTriggerEnter(Collider other)
    // {
    //     // Check if this is a hand (could use a tag or component)
    //     // if (other.CompareTag("PlayerHand") && IsHandEmpty(other))
    //     //Point rhpoint = m_RH.transform;
    //     if ((other.bounds.Contains(m_RH.transform.position) && IsRHandEmpty()) || (other.bounds.Contains(m_LH.transform.position) && IsLHandEmpty()))
    //     {
    //         Recognize    
    //     }
         
    // }

    public void Recognize(string gesture)
    {
        if (gesture.Equals("Whistle", StringComparison.OrdinalIgnoreCase))
        {
            PlayWhistle();
            OnGestureRecognized?.Invoke("Whistle");    
        }
    }

    private void PlayWhistle()
    {
        if (m_whistleClip != null && m_audioSource != null)
        {
            //m_audioSource.PlayOneShot(m_whistleClip);
            m_audioSource.clip = m_whistleClip;
            m_audioSource.time = 1.0f;
            m_audioSource.Play();
        }
    }

    private bool IsRHandEmpty()
    {
        // Check if the hand is not holding anything
        // XRDirectInteractor interactor = handCollider.GetComponentInParent<XRDirectInteractor>();
        UnityEngine.XR.Interaction.Toolkit.Interactors.XRDirectInteractor interactorRH = m_RH.GetComponentInChildren<UnityEngine.XR.Interaction.Toolkit.Interactors.XRDirectInteractor>();
        //XRDirectInteractor interactorLH = m_LH.GetComponentInChildren<XRDirectInteractor>();
        if (interactorRH != null && !interactorRH.hasSelection)
        {
            return true;
        }
        return false;
    }

    private bool IsLHandEmpty()
    {
        // Check if the hand is not holding anything
        // XRDirectInteractor interactor = handCollider.GetComponentInParent<XRDirectInteractor>();
        //XRDirectInteractor interactorRH = m_RH.GetComponentInChildren<XRDirectInteractor>();
        UnityEngine.XR.Interaction.Toolkit.Interactors.XRDirectInteractor interactorLH = m_LH.GetComponentInChildren<UnityEngine.XR.Interaction.Toolkit.Interactors.XRDirectInteractor>();
        if (interactorLH != null && !interactorLH.hasSelection)
        {
            return true;
        }
        return false;
    }

    private void OnDestroy()
    {
        OnGestureRecognized = null; // avoid memory leaks or lingering listeners
    }
}
