using System;
using UnityEngine;
using UnityEngine.UI;
//Maybe wait for a few seconds before interactable.

public class CustomizeTask : TutorialTask
{
    [Tooltip("Assign the Confirm button from the UI.")]
    public Button m_confirmButton;

    private bool m_isComplete = false;

    public override void StartTask(Action onComplete)
    {
        if (isStarted) return;
        isStarted = true;   //Does this break the reset implementation??
        this.onTaskComplete = onComplete;

        if (m_confirmButton != null)
        {
            m_confirmButton.onClick.AddListener(HandleConfirmClicked);
            Debug.Log("CustomizeTask started: Waiting for confirm button press.");
        }
        else
        {
            Debug.LogError("CustomizeTask: Confirm button is not assigned.");
            //ForceCompleteTask(); // optionally force complete to prevent soft-lock
        }
    }

    private void HandleConfirmClicked()
    {
        // if(m_isComplete) return;
        // m_isComplete = true;
        // Debug.Log("CustomizeTask: Confirm button clicked. Task complete.");

        // m_confirmButton.onClick.RemoveListener(HandleConfirmClicked);
        // onTaskComplete?.Invoke();
        CompleteTask("Manual");
    }

    public override void ResetTask()
    {
        isStarted = false;
        m_isComplete = false;

        if (m_confirmButton != null)
        {
            m_confirmButton.onClick.RemoveListener(HandleConfirmClicked);
        }

        Debug.Log("CustomizeTask: Reset called.");
        StartTask(onTaskComplete);
    }

    public override void ForceCompleteTask()
    {
        if(m_isComplete) return;
        m_isComplete = true;

        

        // Debug.LogWarning("CustomizeTask: ForceCompleteTask called.");
        // onTaskComplete?.Invoke();
        CompleteTask("Force");
    }

    private void CompleteTask(string method)
    {
        if(m_isComplete) return;
        m_isComplete = true;
        
        if (m_confirmButton != null)
        {
            m_confirmButton.onClick.RemoveListener(HandleConfirmClicked);
        }

        Debug.LogWarning($"CustomizeTask: Task completed - {method}.");
        onTaskComplete?.Invoke();    
    }
}
