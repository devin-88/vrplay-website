using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit;

public class ButtonPressTask : TutorialTask
{
    [Header("UI Elements")]
    [SerializeField] private Button m_targetButton;
    [TextArea]
    [SerializeField] private string instructionText;
    //[SerializeField] private XRRayInteractor m_rayInteractor;

    [Header("Optional")]
    [SerializeField] private TextMeshProUGUI m_instructionDisplay; // Optional reference to a UI text element

    [Tooltip("Task name for logging.")]
    [SerializeField] private string m_taskName = "ButtonPressTask";

    private bool m_taskCompleted = false;

    public override void StartTask(Action onComplete)
    {
        if (isStarted || m_targetButton == null) return;

        isStarted = true;
        this.onTaskComplete = onComplete;
        m_taskCompleted = false;

        if (m_instructionDisplay != null)
        {
            m_instructionDisplay.text = instructionText;
        }

        if (m_targetButton != null)
        {
            m_targetButton.onClick.AddListener(HandleButtonPressed);
            m_targetButton.gameObject.SetActive(true);
            Debug.Log($"{m_taskName} started: Waiting for button press.");
        }
        else
        {
            Debug.LogError($"{m_taskName}: Button is not assigned.");
        }

        // if (m_rayInteractor != null)
        // {
        //     m_rayInteractor.gameObject.SetActive(true);
        // }

        HandManager.Instance.SetVisibleUI(ControlsUI.Trigger);
        HandManager.Instance.SetTriggerTooltip("Select");
        HandManager.Instance.SetVisibleInteractors(ControlFlags.Ray | ControlFlags.Direct | ControlFlags.Poke);
        if (m_taskName == "Customize Task")
        {
            HandManager.Instance.SetHandStyle(HandStyle.MaleHand);
        }
        else HandManager.Instance.SetHandStyle(HandStyle.Current);
        
    }

    private void HandleButtonPressed()
    {
        if (m_taskCompleted) return;

        m_taskCompleted = true;
        CompleteTask("Manual");
    }

    public override void ResetTask()
    {
        if (m_targetButton != null)
            m_targetButton.onClick.RemoveListener(HandleButtonPressed);

        isStarted = false;
        m_taskCompleted = false;

        if (m_instructionDisplay != null)
        {
            m_instructionDisplay.text = "";
        }

        // if (m_rayInteractor != null)
        // {
        //     m_rayInteractor.gameObject.SetActive(false);
        // }

        Debug.Log($"{m_taskName}: Reset called.");
        StartTask(onTaskComplete);
    }

    public override void ForceCompleteTask()
    {
        if (m_taskCompleted) return;

        m_taskCompleted = true;
        CompleteTask("Forced");
    }

    private void CompleteTask(string method)
    {
        if (m_targetButton != null)
        {
            m_targetButton.onClick.RemoveListener(HandleButtonPressed);
            m_targetButton.gameObject.SetActive(false);
        }

        // if (m_rayInteractor != null)
        // {
        //     m_rayInteractor.gameObject.SetActive(false);
        // }

        Debug.Log($"{m_taskName}: Task completed - {method}.");
        GameSettings.Instance.ExportJSONSettings();
        
        onTaskComplete?.Invoke();
    }
}

