using UnityEngine;
using System.Collections;

[RequireComponent(typeof(Renderer))]
public class FOVHighlighter : MonoBehaviour
{
    [Header("Highlight Behavior")]
    [Tooltip("Total time user will spend in the scene (optional, for advanced logic or disabling).")]
    public float m_totalSceneTime = 300f;

    [Tooltip("Delay before first pulse starts (in seconds).")]
    public float m_initialDelay = 5f;

    [Tooltip("Time between repeated pulses if object stays in view.")]
    public float m_repeatInterval = 10f;

    [Tooltip("Angle threshold for triggering pulse from center of view.")]
    public float m_triggerAngle = 60f;

    [Tooltip("How long each pulse lasts.")]
    public float m_pulseDuration = 1f;

    [Tooltip("Highlight color for emission pulsing.")]
    public Color m_highlightColor = Color.red;

    [Tooltip("Multiplier for how bright the pulse should be.")]
    public float m_pulseIntensity = 1.5f;

    private Renderer m_renderer;
    private Material m_materialInstance;
    private Color m_baseEmission;

    private bool m_isInView = false;
    private bool m_canPulse = true;
    //private float m_ = 0f;

    void Start()
    {
        m_renderer = GetComponent<Renderer>();
        m_materialInstance = m_renderer.material;
        m_baseEmission = m_materialInstance.GetColor("_EmissionColor");
    }

    void Update()
    {
        m_initialDelay -= Time.deltaTime;
        if (m_initialDelay > 0f) return;

        if (IsInPlayerFOV())
        {
            if (!m_isInView) Debug.Log("Interactable item is in view.");
            m_isInView = true;

            if (m_canPulse) //&& m_timeInView >= m_initialDelay
            {

                StartCoroutine(PulseAndCooldown());
            }
        }
        else
        {
            m_isInView = false;
            //m_timeInView = 0f; // Reset time if user looks away
        }
    }

    bool IsInPlayerFOV()
    {
        Vector3 toObject = transform.position - Camera.main.transform.position;
        float angle = Vector3.Angle(Camera.main.transform.forward, toObject);
        return angle < m_triggerAngle;
    }

    IEnumerator PulseAndCooldown()
    {
        m_canPulse = false;
        yield return PulseEmission();

        // Cooldown period before pulsing again if still in view
        yield return new WaitForSeconds(m_repeatInterval);
        m_canPulse = true;
        Debug.Log("Has Pulsed.");
    }

    IEnumerator PulseEmission()
    {
        Debug.Log("Pulse routine...");
        float timer = 0f;
        float pulseStart = Time.time;

        while (timer < m_pulseDuration)
        {
            float t = Mathf.PingPong(Time.time - pulseStart, 1f);
            //Debug.Log(t);
            Color emissive = Color.Lerp(m_baseEmission, m_highlightColor * m_pulseIntensity, t);
            m_materialInstance.SetColor("_EmissionColor", emissive);
            timer += Time.deltaTime;
            yield return null;
        }

        m_materialInstance.SetColor("_EmissionColor", m_baseEmission);
    }
}
