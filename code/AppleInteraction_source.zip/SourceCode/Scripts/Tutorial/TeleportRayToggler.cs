using System;
using UnityEngine;
using UnityEngine.InputSystem;


public class TeleportRayToggler : MonoBehaviour
{
    [SerializeField] private GameObject teleportRay;
    [SerializeField] private InputActionReference teleportActivate;
    //[SerializeField] private InputActionReference teleportSelect;

    [SerializeField] private InputActionReference teleportCancel;

    private bool shouldDisableTeleport = false;

    private void OnEnable()
    {
        //teleportActivate.action.Enable();
       // teleportSelect.action.Enable();
        //teleportCancel.action.Enable();

        teleportActivate.action.performed += OnTeleportActivate;
        teleportActivate.action.canceled += OnTeleportCancel;
        teleportCancel.action.performed += OnTeleportCancel;

        teleportRay.GetComponent<UnityEngine.XR.Interaction.Toolkit.Interactors.XRRayInteractor>().enabled = false;
    }

    // private void OnTeleportSelect(InputAction.CallbackContext context)
    // {
    //     shouldDisableTeleport = true;
    // }

    private void OnDisable()
    {
        teleportActivate.action.performed -= OnTeleportActivate;
        teleportCancel.action.performed -= OnTeleportCancel;

        //teleportRay.SetActive(false);
    }

    private void Update()
    {
        if (shouldDisableTeleport)
        {
            //teleportRay.gameObject.SetActive(false);
            teleportRay.GetComponent<UnityEngine.XR.Interaction.Toolkit.Interactors.XRRayInteractor>().enabled = false;
            shouldDisableTeleport = false;
        }
    }

    private void OnTeleportActivate(InputAction.CallbackContext ctx)
    {
        //Debug.LogWarning("Line Showing>>??");
        teleportRay.GetComponent<UnityEngine.XR.Interaction.Toolkit.Interactors.XRRayInteractor>().enabled = true;
    }

    private void OnTeleportCancel(InputAction.CallbackContext ctx)
    {
        shouldDisableTeleport = true; // Delayed one frame to allow teleport to complete
    }
}
