using System;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit;

public class InteractTask : TutorialTask
{
    [Header("Interactable Objects")]
    [SerializeField] private UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable[] m_targetInteractables;

    [SerializeField] private TextMeshProUGUI m_instruction;

    [Header("Image Prompts")]
    [SerializeField] private Sprite[] m_Sprites;
    [SerializeField] private Image m_Image;
    private int m_currentImage = 0;

    [Header("Triggers")]
    [SerializeField] private ThrowDetector m_throwDetector;
    [SerializeField] private ItemLocker m_rightLocker;
    [SerializeField] private ItemLocker m_leftLocker;

    public void BindLockers(ItemLocker left, ItemLocker right)
    {
        if (left != null)
            m_leftLocker = left;
        if (right != null)
            m_rightLocker = right;
    }

    private bool m_pickUp = false;
    private bool m_throw = false;
    private bool m_lefthanded = false;
    private int m_currentIndex = 0;

    private string m_TASK1, m_TASK2;

    public override void StartTask(Action onComplete)
    {
        if (isStarted) return;

        isStarted = true;
        onTaskComplete = onComplete;
        m_pickUp = m_throw = false;
        m_currentIndex = 0;
        m_lefthanded = GameSettings.Instance.IsLeftHanded();

        m_TASK1 = $"Move your <b>{(m_lefthanded ? "Left" : "Right")} Hand</b> over the <i>interactable cube</i>. \n Press <color=\"red\">Trigger</color> to grab it.";
        m_TASK2 = "Throw the cube at the <color=\"yellow\">Target</color>. Release <color=\"red\">Trigger</color> to let go.";

        TaskSetup(m_currentIndex);

        HandManager.Instance.SetVisibleUI(ControlsUI.None);
        HandManager.Instance.SetVisibleInteractors(ControlFlags.Direct | ControlFlags.Ray | ControlFlags.Poke);
        HandManager.Instance.SetHandStyle(HandStyle.Current);
    }

    private void HandleObjectPickedUp(SelectEnterEventArgs args)
    {
        if (m_pickUp) return;

        m_pickUp = true;
        SFXManager.Instance.PlayCompletionSound();
        TaskSetup(++m_currentIndex);
    }

    private void HandleObjectThrown()
    {
        if (!m_pickUp || m_throw) return;

        m_throw = true;
        CompleteTask("Manual");
    }

    public override void ResetTask()
    {
        m_pickUp = false;
        m_throw = false;
        isStarted = false;

        foreach (var interactable in m_targetInteractables)
        {
            if (interactable != null)
                interactable.selectEntered.RemoveListener(HandleObjectPickedUp);
        }

        if (m_throwDetector != null)
            m_throwDetector.OnThrowDetected -= HandleObjectThrown;

        StartTask(onTaskComplete);
    }

    public override void ForceCompleteTask()
    {
        m_pickUp = true;
        m_throw = true;
        CompleteTask("Forced");
    }

    private void CompleteTask(string method)
    {
        foreach (var interactable in m_targetInteractables)
        {
            if (interactable != null)
                interactable.selectEntered.RemoveListener(HandleObjectPickedUp);
        }

        if (TutorialInteractableManager.Instance != null)
            TutorialInteractableManager.Instance.DestroyInteractables();

        if (m_throwDetector != null)
        {
            m_throwDetector.OnThrowDetected -= HandleObjectThrown;
            m_throwDetector.gameObject.SetActive(false);
        }

        if (m_lefthanded)
        {
            if (m_leftLocker != null) m_leftLocker.ResetLocker();
        }
        else if (m_rightLocker != null)
        {
            m_rightLocker.ResetLocker();
        }

        Debug.Log($"InteractTask: Completed - {method}");
        onTaskComplete?.Invoke();
    }

    private void TaskSetup(int task)
    {
        switch (task)
        {
            case 0:
                m_instruction.text = m_TASK1;
                NextImage();
                if (m_throwDetector != null)
                    m_throwDetector.gameObject.SetActive(false);
                if (m_targetInteractables != null && m_targetInteractables.Length > 0)
                    TargetInteractable(m_targetInteractables[0], true);
                break;
            case 1:
                m_instruction.text = m_TASK2;
                NextImage();
                if (m_throwDetector != null)
                {
                    m_throwDetector.OnThrowDetected += HandleObjectThrown;
                    m_throwDetector.gameObject.SetActive(true);
                }
                break;
            default:
                Debug.LogWarning("InteractTask: Invalid Task Attempted");
                break;
        }
    }

    private void TargetInteractable(UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable interactable, bool addition)
    {
        if (interactable == null) return;
        if (addition)
            interactable.selectEntered.AddListener(HandleObjectPickedUp);
        else
            interactable.selectEntered.RemoveListener(HandleObjectPickedUp);
    }

    private void NextImage()
    {
        if (m_Sprites == null || m_Image == null) return;
        if (m_currentImage >= m_Sprites.Length) return;
        m_Image.sprite = m_Sprites[m_currentImage++];
    }
}
