using System;
using TMPro;
using Unity.XR.CoreUtils;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.UI;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation;
using CommonUsages = UnityEngine.XR.CommonUsages;
using XRInputDevice = UnityEngine.XR.InputDevice;

/// <summary>
/// Movement tutorial adapted to this project's comfort hop (stick forward).
/// Physical turning is done by looking — joystick snap turn is disabled.
/// </summary>
public class TeleportTask : TutorialTask
{
    [Header("Interactors & GameObjects")]
    public XRRayInteractor m_teleportRayInteractor;
    public XRRayInteractor m_rayInteractor;
    public TeleportationArea m_teleportationArea;
    public TeleportationAnchor m_teleportationAnchor;

    [Header("Hop Target")]
    [Tooltip("Optional marker the player must hop near to finish. Falls back to the teleport anchor.")]
    public Transform m_hopTarget;
    public float m_hopTargetRadius = 1.75f;

    [Header("Input Actions")]
    public InputActionReference m_leftSnapTurnAction;
    public InputActionReference m_rightSnapTurnAction;

    [Header("Image Prompts")]
    [SerializeField] private Sprite[] m_Sprites;
    [SerializeField] private Image m_Image;
    private int m_currentImage = 0;

    [SerializeField]
    private TextMeshProUGUI m_instruction;

    private bool m_hasHopped = false;
    private bool m_hasAnchored = false;
    private bool m_leftHanded = false;
    private bool m_hopArmed = true;

    private string m_TASK1;
    private string m_TASK2;

    private XROrigin m_xrOrigin;
    private Vector3 m_startFeet;

    public override void StartTask(Action onComplete)
    {
        if (isStarted) return;

        this.onTaskComplete = onComplete;
        isStarted = true;
        m_hasHopped = false;
        m_hasAnchored = false;
        m_hopArmed = true;

        if (m_teleportationAnchor != null)
            m_teleportationAnchor.gameObject.SetActive(false);

        // Hide legacy teleport area visuals; hop does not use aim rays.
        if (m_teleportationArea != null)
            m_teleportationArea.enabled = false;

        m_xrOrigin = FindFirstObjectByType<XROrigin>();
        m_startFeet = GetFeetPosition();

        m_leftHanded = GameSettings.Instance.IsLeftHanded();
        string moveHand = m_leftHanded ? "Right" : "Left";

        m_TASK1 = $"You can move by <i>hopping</i> — push the <color=\"red\">thumbstick forward</color> on your <b>{moveHand} Controller</b>. Turn by looking with your head.";
        m_TASK2 = $"Hop back near the marked spot to finish this step.";
        m_instruction.text = m_TASK1;
        NextImage();

        PlayComfortLocomotion.OnHop += HandleHop;

        HandManager.Instance.SetVisibleUI(ControlsUI.None);
        HandManager.Instance.SetVisibleInteractors(ControlFlags.Direct | ControlFlags.Ray | ControlFlags.Poke);
        HandManager.Instance.SetHandStyle(HandStyle.Current);
        HandManager.Instance.SetHandStyleMove(HandStyle.MaleHand);

        Debug.Log("TeleportTask started: Awaiting comfort hop...");
    }

    void Update()
    {
        if (!isStarted)
            return;

        Vector2 stick = ReadMoveStick();

        if (!m_hasHopped)
        {
            // Backup detection if hop event is missed (e.g. locomotion not yet ready).
            bool wantsHop = stick.y >= 0.65f && Mathf.Abs(stick.x) <= 0.45f;
            if (wantsHop)
            {
                if (m_hopArmed)
                    m_hopArmed = false;
            }
            else
            {
                m_hopArmed = true;
            }

            if (Vector3.Distance(GetFeetPosition(), m_startFeet) > 0.6f)
                RegisterHop();
        }
    }

    private void HandleHop()
    {
        RegisterHop();
    }

    private void RegisterHop()
    {
        if (m_hasHopped) return;

        m_hasHopped = true;
        Debug.Log("TeleportTask: Detected a comfort hop.");

        Transform target = m_hopTarget != null
            ? m_hopTarget
            : (m_teleportationAnchor != null ? m_teleportationAnchor.transform : null);

        if (target != null)
            target.gameObject.SetActive(true);

        m_instruction.text = m_TASK2;
        NextImage();
        SFXManager.Instance.PlayCompletionSound();
    }

    void LateUpdate()
    {
        if (!isStarted || !m_hasHopped || m_hasAnchored)
            return;

        Transform target = m_hopTarget != null
            ? m_hopTarget
            : (m_teleportationAnchor != null ? m_teleportationAnchor.transform : null);

        if (target == null)
        {
            m_hasAnchored = true;
            CompleteTask("Manual");
            return;
        }

        Vector3 feet = GetFeetPosition();
        Vector3 goal = target.position;
        goal.y = feet.y;
        if (Vector3.Distance(feet, goal) <= m_hopTargetRadius)
        {
            m_hasAnchored = true;
            CompleteTask("Manual");
        }
    }

    private void CompleteTask(string method)
    {
        PlayComfortLocomotion.OnHop -= HandleHop;

        if (m_teleportationAnchor != null)
            m_teleportationAnchor.gameObject.SetActive(false);

        Debug.Log($"TeleportTask: Completed - {method}");
        onTaskComplete?.Invoke();
    }

    public override void ResetTask()
    {
        PlayComfortLocomotion.OnHop -= HandleHop;

        isStarted = false;
        m_hasHopped = false;
        m_hasAnchored = false;
        m_hopArmed = true;
        m_currentImage = 0;

        if (m_teleportationAnchor != null)
            m_teleportationAnchor.gameObject.SetActive(false);

        if (onTaskComplete != null)
            StartTask(onTaskComplete);
    }

    public override void ForceCompleteTask()
    {
        m_hasHopped = true;
        m_hasAnchored = true;
        CompleteTask("Forced");
    }

    private void NextImage()
    {
        if (m_Sprites == null || m_Image == null) return;
        if (m_currentImage >= m_Sprites.Length) return;
        m_Image.sprite = m_Sprites[m_currentImage++];
    }

    Vector3 GetFeetPosition()
    {
        if (m_xrOrigin != null)
            return m_xrOrigin.transform.position;
        if (Camera.main != null)
        {
            Vector3 p = Camera.main.transform.position;
            p.y = 0f;
            return p;
        }
        return Vector3.zero;
    }

    static Vector2 ReadMoveStick()
    {
        Vector2 stick = Vector2.zero;
        AccumulateStick(XRNode.LeftHand, ref stick);
        AccumulateStick(XRNode.RightHand, ref stick);
        return stick;
    }

    static void AccumulateStick(XRNode node, ref Vector2 stick)
    {
        XRInputDevice device = InputDevices.GetDeviceAtXRNode(node);
        if (device.isValid && device.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 axis))
            stick += axis;
    }
}
