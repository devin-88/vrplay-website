using System;
using UnityEngine;

public abstract class TutorialTask : MonoBehaviour
{
    protected bool isStarted = false;
    protected Action onTaskComplete;
    public abstract void StartTask(Action onComplete);
    public abstract void ResetTask();
    public abstract void ForceCompleteTask();
    // public abstract bool IsTaskComplete();
}

