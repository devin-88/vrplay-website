using System;
using System.IO;
using UnityEngine;

public class TutorialLogger : MonoBehaviour
{

    private string m_logPath;
    private DateTime m_sessionStartTime;

    void OnEnable()
    {
        TutorialManager.OnTutorialStarted += HandleTutorialStarted;
        TutorialManager.OnTutorialCompleted += HandleTutorialCompleted;
        TutorialManager.OnTaskStarted += HandleTaskStarted;
        TutorialManager.OnTaskCompleted += HandleTaskCompleted;
    }

    void OnDisable() {
        TutorialManager.OnTutorialStarted -= HandleTutorialStarted;
        TutorialManager.OnTutorialCompleted -= HandleTutorialCompleted;
        TutorialManager.OnTaskStarted -= HandleTaskStarted;
        TutorialManager.OnTaskCompleted -= HandleTaskCompleted;
    }

    void HandleTutorialStarted()
    {
        m_sessionStartTime = DateTime.Now;
        string sessionId = Guid.NewGuid().ToString();
        m_logPath = Path.Combine(Application.persistentDataPath, $"TutorialLog_{m_sessionStartTime:yyyy-MM-dd_HH-mm-ss}_{sessionId}.txt");
        Debug.Log(m_logPath);

        using (StreamWriter sw = File.CreateText(m_logPath))
        {
            sw.WriteLine("# Tutorial Session Log");
            sw.WriteLine($"# Date: {m_sessionStartTime:yyyy-MM-dd}");
            sw.WriteLine($"# Start Time: {m_sessionStartTime:HH:mm:ss}");
            sw.WriteLine($"# Session ID: {sessionId}\n");
            sw.WriteLine("[Tutorial Started]");
            sw.WriteLine($"- TimeSinceStart: 00:00:00");
            sw.WriteLine($"- RealWorldTime: {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n");
        }
    }

    void LogLine(string content)
    {
        using (StreamWriter sw = File.AppendText(m_logPath))
        {
            sw.WriteLine(content);
        }
    }

    void HandleTaskStarted(TutorialTask task)
    {
        TimeSpan timeSinceStart = DateTime.Now - m_sessionStartTime;
        LogLine($"[Task Started: {task.GetType().Name}]");
        LogLine($"- TimeSinceStart: {timeSinceStart:hh\\:mm\\:ss}");
        LogLine($"- RealWorldTime: {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n");
    }

    void HandleTaskCompleted(TutorialTask task)
    {
        TimeSpan timeSinceStart = DateTime.Now - m_sessionStartTime;
        LogLine($"[Task Completed: {task.GetType().Name}]");
        LogLine($"- TimeSinceStart: {timeSinceStart:hh\\:mm\\:ss}");
        LogLine($"- RealWorldTime: {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n");
    }

    void HandleTutorialCompleted()
    {
        TimeSpan timeSinceStart = DateTime.Now - m_sessionStartTime;
        LogLine("[Tutorial Completed]");
        LogLine($"- TimeSinceStart: {timeSinceStart:hh\\:mm\\:ss}");
        LogLine($"- RealWorldTime: {DateTime.Now:yyyy-MM-dd HH:mm:ss}\n");
    }

    
}
