using UnityEngine;

public class MouthWhistleDetector : MonoBehaviour
{
    [Tooltip("Minimum delay between whistle triggers (seconds)")]
    public float whistleCooldown = 3f; 

    private float lastWhistleTime = -Mathf.Infinity;

    private void OnTriggerEnter(Collider other)
    {
        if (other.CompareTag("PlayerHand"))
        {
            // Check if enough time has passed
            if (Time.time >= lastWhistleTime + whistleCooldown)
            {
                lastWhistleTime = Time.time;

                // Trigger whistle
                GestureRecognizer.Instance.Recognize("Whistle");
                Debug.Log("Whistle gesture detected!");
            }
            else
            {
                Debug.Log("Whistle on cooldown.");
            }
        }
    }
}
