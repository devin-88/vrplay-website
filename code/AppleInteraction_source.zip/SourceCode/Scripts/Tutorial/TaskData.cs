using UnityEngine;

[CreateAssetMenu(menuName = "Tutorial/TaskData")]
public class TaskData : ScriptableObject
{
    public string instructionText;
    public AudioClip instructionAudio;

    public void Display()
    {
        // Show UI text
        Debug.Log("Display text: " + instructionText);

        // Play audio
        if (instructionAudio != null)
            AudioSource.PlayClipAtPoint(instructionAudio, Vector3.zero); // Customize as needed
    }
}
