using System;
using UnityEngine;


[RequireComponent(typeof(Collider))]
public class ThrowDetector : MonoBehaviour
{
    //public string requiredTag = "Throwable"; // Optional: tag your interactables
    public event Action OnThrowDetected;
    private void OnTriggerEnter(Collider other)
    {
        UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable grabInteractable = other.GetComponent<UnityEngine.XR.Interaction.Toolkit.Interactables.XRGrabInteractable>();
        if (grabInteractable != null && !grabInteractable.isSelected)
        {
            Rigidbody rb = other.attachedRigidbody;
            if (rb != null && rb.linearVelocity.magnitude > 0.1f) // Example threshold
            {
                Debug.Log($"Thrown object '{other.name}' entered collider: velocity = {rb.linearVelocity.magnitude}");
                OnThrowDetected?.Invoke();
            }
        }
    }
}
