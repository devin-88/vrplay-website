using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation;
using UnityEngine.XR.Interaction.Toolkit.Samples.StarterAssets;

/// <summary>
/// Keeps VE_Tutorial on this project's XR Origin (XR Rig): Oculus hands,
/// comfort hop locomotion, HandManager wiring, then loads Final on complete.
/// </summary>
[DefaultExecutionOrder(-100)]
public class TutorialProjectBridge : MonoBehaviour
{
    [SerializeField] string nextSceneName = "Final";
    [SerializeField] Material[] oculusSkinVariants;

    HandManager handManager;
    GameObject projectRig;
    GameObject leftHand;
    GameObject rightHand;

    public ItemLocker LeftLocker { get; private set; }
    public ItemLocker RightLocker { get; private set; }

    void Awake()
    {
        handManager = FindFirstObjectByType<HandManager>();
        ActivateProjectRig();
        CacheHands();
        EnsureComfortLocomotion();
        EnsureTeleportationProvider();
        WireGrabAnimators();
        WireHandManager();
        EnsureItemLockers();
        WireGestureHands();
        DisableLegacyTeleportAim();
    }

    void OnEnable()
    {
        TutorialManager.OnTutorialCompleted += HandleTutorialCompleted;
    }

    void OnDisable()
    {
        TutorialManager.OnTutorialCompleted -= HandleTutorialCompleted;
    }

    void HandleTutorialCompleted()
    {
        if (string.IsNullOrEmpty(nextSceneName))
            return;

        if (GameSettings.Instance != null)
            GameSettings.Instance.ExportJSONSettings();

        // Apply once more before leaving so Final can read the same in-memory choice.
        if (GameSettings.Instance != null)
            HandSkinCatalog.ApplyToNamedHands((int)GameSettings.Instance.GetSkinStyle());

        SceneManager.LoadScene(nextSceneName);
    }

    void ActivateProjectRig()
    {
        projectRig = FindNamedRoot("XR Origin (XR Rig)");
        var u6 = FindNamedRoot("XR Origin (U6 Rig)");

        if (projectRig == null)
        {
            Debug.LogError("[TutorialProjectBridge] XR Origin (XR Rig) not found in scene.");
            return;
        }

        if (u6 != null)
        {
            // Prefer the tutorial's original spawn if the copied rig was left at an offset.
            if (u6.transform.position.sqrMagnitude < 0.01f &&
                (projectRig.transform.position - u6.transform.position).sqrMagnitude > 0.01f)
            {
                projectRig.transform.SetPositionAndRotation(u6.transform.position, u6.transform.rotation);
            }

            u6.SetActive(false);
        }

        projectRig.SetActive(true);
    }

    static GameObject FindNamedRoot(string name)
    {
        foreach (var t in FindObjectsByType<Transform>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            if (t.parent == null && t.name == name)
                return t.gameObject;
        }
        return null;
    }

    void CacheHands()
    {
        if (projectRig == null)
            return;

        foreach (var t in projectRig.GetComponentsInChildren<Transform>(true))
        {
            if (t.name == "Left Hand Model")
                leftHand = t.gameObject;
            else if (t.name == "Right Hand Model")
                rightHand = t.gameObject;
        }

        if (leftHand == null || rightHand == null)
            Debug.LogWarning("[TutorialProjectBridge] Left/Right Hand Model missing under XR Origin (XR Rig).");
    }

    void EnsureComfortLocomotion()
    {
        if (projectRig == null)
            return;

        if (projectRig.GetComponent<PlayComfortLocomotion>() == null)
            projectRig.AddComponent<PlayComfortLocomotion>();
    }

    void EnsureTeleportationProvider()
    {
        if (projectRig == null)
            return;

        foreach (var tp in projectRig.GetComponentsInChildren<TeleportationProvider>(true))
        {
            tp.gameObject.SetActive(true);
            tp.enabled = true;
            tp.delayTime = 0f;
        }
    }

    void WireGrabAnimators()
    {
        WireGrabAnimator(leftHand, XRNode.LeftHand);
        WireGrabAnimator(rightHand, XRNode.RightHand);
    }

    static void WireGrabAnimator(GameObject hand, XRNode node)
    {
        if (hand == null)
            return;

        var animator = hand.GetComponent<Animator>();
        if (animator != null)
            animator.enabled = true;

        var misplaced = hand.GetComponent<ControllerAnimator>();
        if (misplaced != null)
            Destroy(misplaced);

        var driver = hand.GetComponent<PlayHandGrabAnimator>();
        if (driver == null)
            driver = hand.AddComponent<PlayHandGrabAnimator>();
        driver.handAnimator = animator;
        driver.handNode = node;

        if (driver.interactor == null && hand.transform.parent != null)
        {
            driver.interactor = hand.transform.parent.GetComponentInChildren<NearFarInteractor>(true);
            if (driver.interactor == null)
                driver.interactor = hand.transform.parent.GetComponentInChildren<XRBaseInputInteractor>(true);
        }
    }

    void WireHandManager()
    {
        if (handManager == null || projectRig == null)
            return;

        handManager.projectHandsMode = true;
        handManager.projectLeftHand = leftHand;
        handManager.projectRightHand = rightHand;

        if (leftHand != null)
            handManager.leftStyleModels = new[] { leftHand, leftHand, leftHand };
        if (rightHand != null)
            handManager.rightStyleModels = new[] { rightHand, rightHand, rightHand };

        // Palette is the source of truth for the 12 hand materials.
        var paletteMats = HandSkinCatalog.GetMaterials();
        bool hasPaletteMats = false;
        for (int i = 0; i < paletteMats.Length; i++)
        {
            if (paletteMats[i] != null)
            {
                hasPaletteMats = true;
                break;
            }
        }

        if (hasPaletteMats)
        {
            handManager.femaleSkinStyles = paletteMats;
            handManager.maleSkinStyles = paletteMats;
            oculusSkinVariants = paletteMats;
        }
        else if (oculusSkinVariants != null && oculusSkinVariants.Length > 0)
        {
            handManager.femaleSkinStyles = oculusSkinVariants;
            handManager.maleSkinStyles = oculusSkinVariants;
        }

        Transform leftController = FindChildNamed(projectRig.transform, "Left Controller");
        Transform rightController = FindChildNamed(projectRig.transform, "Right Controller");
        Transform turn = FindChildNamed(projectRig.transform, "Turn");

        handManager.leftInteractors = BuildInteractorSet(leftController, turn);
        handManager.rightInteractors = BuildInteractorSet(rightController, turn);

        handManager.SetHandStyleLeft(HandStyle.MaleHand);
        handManager.SetHandStyleRight(HandStyle.MaleHand);
        SkinStyle skin = GameSettings.Instance != null
            ? GameSettings.Instance.GetSkinStyle()
            : SkinStyle.SoftBeige;
        handManager.SetSkinStyle(skin);
        handManager.SetVisibleInteractors(ControlFlags.Direct | ControlFlags.Poke | ControlFlags.Ray);
        handManager.SetVisibleUI(ControlsUI.None);
    }

    static GameObject[] BuildInteractorSet(Transform controller, Transform turn)
    {
        GameObject nearFar = null;
        GameObject poke = null;
        GameObject teleport = null;

        if (controller != null)
        {
            foreach (Transform t in controller.GetComponentsInChildren<Transform>(true))
            {
                if (t.parent != controller)
                    continue;

                if (t.name.StartsWith("Near-Far Interactor"))
                    nearFar = t.gameObject;
                else if (t.name.StartsWith("Poke Interactor"))
                    poke = t.gameObject;
                else if (t.name.StartsWith("Teleport Interactor"))
                    teleport = t.gameObject;
            }
        }

        return new[]
        {
            nearFar,
            poke,
            teleport,
            turn != null ? turn.gameObject : null
        };
    }

    void EnsureItemLockers()
    {
        if (projectRig == null)
            return;

        ItemLocker templateLeft = null;
        ItemLocker templateRight = null;
        foreach (var locker in FindObjectsByType<ItemLocker>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            string path = GetPath(locker.transform);
            if (!path.Contains("U6"))
                continue;
            if (path.Contains("Left"))
                templateLeft = locker;
            else if (path.Contains("Right"))
                templateRight = locker;
        }

        Transform leftNearFar = FindChildUnderController(projectRig.transform, "Left Controller", "Near-Far Interactor");
        Transform rightNearFar = FindChildUnderController(projectRig.transform, "Right Controller", "Near-Far Interactor");

        LeftLocker = EnsureLockerOn(leftNearFar != null ? leftNearFar.gameObject : null, templateLeft, leftHand);
        RightLocker = EnsureLockerOn(rightNearFar != null ? rightNearFar.gameObject : null, templateRight, rightHand);

        var interactTask = FindFirstObjectByType<InteractTask>(FindObjectsInactive.Include);
        if (interactTask != null)
            interactTask.BindLockers(LeftLocker, RightLocker);
    }

    ItemLocker EnsureLockerOn(GameObject nearFar, ItemLocker template, GameObject hand)
    {
        if (nearFar == null)
            return null;

        var locker = nearFar.GetComponent<ItemLocker>();
        if (locker == null)
            locker = nearFar.AddComponent<ItemLocker>();

        if (template != null)
        {
            locker.m_item = template.m_item;
            locker.m_reference = template.m_reference;
            locker.m_toolPositions = template.m_toolPositions;
        }

        if (hand != null)
        {
            Transform apHand = hand.transform.Find("APHand");
            if (apHand == null)
            {
                var go = new GameObject("APHand");
                go.transform.SetParent(hand.transform, false);
                go.transform.localPosition = new Vector3(0f, -0.02f, 0.06f);
                apHand = go.transform;
            }

            Transform apTool = hand.transform.Find("APTool");
            if (apTool == null)
            {
                var go = new GameObject("APTool");
                go.transform.SetParent(hand.transform, false);
                go.transform.localPosition = new Vector3(0f, -0.01f, 0.1f);
                apTool = go.transform;
            }

            locker.m_apHand = apHand;
            locker.m_apTool = apTool;
        }

        return locker;
    }

    void DisableLegacyTeleportAim()
    {
        if (projectRig == null)
            return;

        foreach (var t in projectRig.GetComponentsInChildren<Transform>(true))
        {
            if (t.name.Contains("Teleport Interactor"))
                t.gameObject.SetActive(false);
        }
    }

    void WireGestureHands()
    {
        var recognizer = FindFirstObjectByType<GestureRecognizer>(FindObjectsInactive.Include);
        if (recognizer == null)
            return;
        if (rightHand != null)
            recognizer.m_RH = rightHand;
        if (leftHand != null)
            recognizer.m_LH = leftHand;
    }

    static Transform FindChildNamed(Transform root, string name)
    {
        foreach (var t in root.GetComponentsInChildren<Transform>(true))
        {
            if (t.name == name)
                return t;
        }
        return null;
    }

    static Transform FindChildUnderController(Transform root, string controllerName, string childPrefix)
    {
        Transform controller = FindChildNamed(root, controllerName);
        if (controller == null)
            return null;

        foreach (Transform t in controller)
        {
            if (t.name.StartsWith(childPrefix))
                return t;
        }
        return null;
    }

    static string GetPath(Transform t)
    {
        string p = t.name;
        while (t.parent != null)
        {
            t = t.parent;
            p = t.name + "/" + p;
        }
        return p;
    }
}
