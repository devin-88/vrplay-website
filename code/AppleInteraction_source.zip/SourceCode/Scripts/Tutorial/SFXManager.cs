using System;
using UnityEngine;

public class SFXManager : MonoBehaviour
{
    [SerializeField] private AudioClip[] audioClips;
    private AudioSource audioSource;

    public static SFXManager Instance { get; private set; }
    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("Duplicate SFXManager instance detected. Destroying new one.");
            Destroy(gameObject);
            return;
        }
        Instance = this;

        if(TryGetComponent<AudioSource>(out var source))
        {
            audioSource = source;
        }
        else
        {
            Debug.LogWarning("[SFXManager] No AudioSource found on the GameObject. Adding one.");
            audioSource = gameObject.AddComponent<AudioSource>();
        }

        audioSource.playOnAwake = false;
        //audioSource.clip = audioClips[0]; // Set default clip to the first one in the array
        
        TutorialManager.OnTaskCompleted += HandleTutorialTaskCompleted;
    }

    private void HandleTutorialTaskCompleted(TutorialTask task)
    {
        PlaySound(0);
    }

    private void PlaySound(int index)
    {
        if (index < 0 || index >= audioClips.Length)
        {
            Debug.LogWarning($"[SFXManager] Invalid audio clip index: {index}");
            return;
        }

        audioSource.clip = audioClips[index];
        audioSource.Play();
    }

    void OnDisable()
    {
        TutorialManager.OnTaskCompleted -= HandleTutorialTaskCompleted;
    }

    public void PlayCompletionSound()
    {
        PlaySound(0);
    }
}
