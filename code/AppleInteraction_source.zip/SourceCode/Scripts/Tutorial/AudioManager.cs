using System.Collections;
using System.Collections.Generic;
using UnityEngine;

class AudioVolume {
    public AudioSource source;
    public float baseVolume;
}

public class AudioManager : MonoBehaviour
{
    public AudioSource[] m_allAudioSources;

    private List<AudioVolume> m_volumes = new List<AudioVolume>();
    // Start is called before the first frame update
    void Start()
    {
        for (int i = 0; i < m_allAudioSources.Length; i++)
        {
            m_volumes.Add(new AudioVolume() { source = m_allAudioSources[i], baseVolume = m_allAudioSources[i].volume });  
        }
        //GameSettings.Instance.onVolumeChanged += HandleVolumeChanged;
    }

    // Update is called once per frame
    public void HandleVolumeChanged(float volume)
    {
        foreach (AudioVolume v in m_volumes)
        {
            //Debug.Log($"{v.source.gameObject.name} ({v.baseVolume} x {volume}) = {v.baseVolume * volume}");
            v.source.volume = v.baseVolume * volume;
        }
    }

    void OnDestroy()
    {
        //GameSettings.Instance.onVolumeChanged -= HandleVolumeChanged; 
    }
}
