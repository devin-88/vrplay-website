using System;
using UnityEngine;
using System.IO;

public enum ChoiceType
{
    None,
    Collie,
    Retriever,
    Beagle,
    Nuts,
    Seeds,
    Maize

}

[Serializable]
public class SettingsData
{
    public float masterVolume;
    public bool isLeftHanded;
    public ChoiceType choice;
    public string sessionID;
    public HandStyle handStyle;
    public SkinStyle skinStyle;
}

public static class SavePaths
{
    public static string RootFolder => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "AppleInteractionVE");
    public static string SessionFolder(string sessionID) => Path.Combine(RootFolder, $"{sessionID}");
    public static string CurrentSessionFile => Path.Combine(RootFolder, "CurrentSession.txt");
    public static string SettingsFile(string sessionID) => Path.Combine(SessionFolder(sessionID), "SettingsData.json");

    public static string LogFile(string sessionID) => Path.Combine(SessionFolder(sessionID), "LogData.json");
}

public class GameSettings : MonoBehaviour
{
    public static GameSettings Instance { get; private set; }
    public static event Action<bool> OnHandednessChanged;

    private static string sessionID;
    public string GetSessionID() => sessionID;

    [SerializeField] private bool consumeExistingSession = false;

    [Header("Audio")]
    public float masterVolume = 1.0f;

    [Header("Tutorial Customization")]
    [Tooltip("Set to LeftHanded to prompt an initial CHANGE trigger")]
    [SerializeField] private bool isLeftHanded = false;

    [SerializeField] private HandStyle handStyle = HandStyle.MaleHand;
    [SerializeField] private SkinStyle skinStyle = SkinStyle.SoftBeige;

    [Header("Scene 1 Choice")]
    public ChoiceType choice = ChoiceType.None;

    [Header("Scene 2 Active Item")]
    private GameObject activeObject;

    void Awake()
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("Duplicate GameSettings instance detected. Destroying new one.");
            Destroy(gameObject);
            return;
        }

        Instance = this;
        DontDestroyOnLoad(transform.parent ? transform.parent.gameObject : gameObject);
        Debug.Log("GameSettings instance initialized and marked as DontDestroyOnLoad.");
    }

    void Start()
    {
        Directory.CreateDirectory(SavePaths.RootFolder);

        if (File.Exists(SavePaths.CurrentSessionFile))
        {
            sessionID = File.ReadAllText(SavePaths.CurrentSessionFile);
            Debug.Log($"Existing session found: {sessionID}");
    
        }
        else
        {
            Debug.LogWarning("No session file found. Creating one.");
            //sessionID = Guid.NewGuid().ToString()[..8];
            sessionID = $"P_{DateTime.Now:yyyyMMdd_HHmmss}";
            File.WriteAllText(SavePaths.CurrentSessionFile, sessionID);
        }

        Directory.CreateDirectory(SavePaths.SessionFolder(sessionID));

        if (File.Exists(SavePaths.SettingsFile(sessionID)))
        {
            Debug.Log("Settings file found. Importing settings.");
            ImportJSONSettings();
        }
        else
        {
            Debug.LogWarning("No settings file found. Using Tutorial settings.");
        }    
    }

    public void SetVolume(float volume)
    {
        Debug.Log($"Volume set to {volume}");
        this.masterVolume = volume;
        //onVolumeChanged?.Invoke(this.masterVolume);
    }

    public void SetHandedness(bool rightHanded)
    {
        //Why stupid and RightHanded? Because of the UI toggle starting ON and to the right...
        //if (this.isLeftHanded != rightHanded) return; //Forces the changed value to be NEW
        Debug.Log($"Handedness set to {(rightHanded ? "Right" : "Left")}");
        this.isLeftHanded = !rightHanded;
        OnHandednessChanged?.Invoke(this.isLeftHanded);
    }

    public void SetChoice(ChoiceType choice, bool save = true)
    {
        Debug.Log($"Choice set to {choice}");
        this.choice = choice;
        if(choice != ChoiceType.None && save) ExportJSONSettings(); //Autosave
    }

    public void SetChoice(int choiceIndex)
    {
        ChoiceType choice = (ChoiceType)choiceIndex;
        SetChoice(choice);
    }

    public ChoiceType GetChoice()
    {
        Debug.Log($"Getting choice: {this.choice}");
        return this.choice;
    }

    public float GetVolume()
    {
        Debug.Log($"Getting volume: {this.masterVolume}");
        return this.masterVolume;
    }

    public bool IsLeftHanded()
    {
        Debug.Log($"Getting handedness: {(this.isLeftHanded ? "Left" : "Right")}");
        return this.isLeftHanded;
    }

    public HandStyle GetHandStyle()
    {
        Debug.Log($"Getting hand style: {handStyle}");
        return handStyle;
    }

    public SkinStyle GetSkinStyle()
    {
        Debug.Log($"Getting skin style: {skinStyle}");
        return skinStyle;
    }

    public void SetHandStyle(HandStyle style)
    {
        Debug.Log($"Setting hand style to: {style}");
        handStyle = style;
        if (HandManager.Instance != null)
            HandManager.Instance.SetHandStyle(style);
    }

    public void SetHandStyle(int styleIndex)
    {
        HandStyle style = (HandStyle)styleIndex;
        SetHandStyle(style);
    }

    public void SetSkinStyle(SkinStyle style)
    {
        Debug.Log($"Setting skin style to: {style}");
        skinStyle = style;
        if (HandManager.Instance != null)
            HandManager.Instance.SetSkinStyle(style);
        else
            HandSkinCatalog.ApplyToNamedHands((int)style);
    }

    public void SetSkinStyle(int styleIndex)
    {
        SkinStyle style = (SkinStyle)HandSkinCatalog.ClampIndex(styleIndex);
        SetSkinStyle(style);
    }

    public GameObject GetActiveObject()
    {
        
        Debug.Log($"Getting Scene 2 active object: {(activeObject ? activeObject.name : "None")}");
        return activeObject;
    }

    public void SetActiveObject(GameObject obj)
    {
        Debug.Log($"Setting Scene 2 active object to: {(obj ? obj.name : "None")}");
        activeObject = obj;
    }

    private SettingsData CreateSaveData()
    {
        return new SettingsData
        {
            masterVolume = GetVolume(),
            isLeftHanded = IsLeftHanded(),
            choice = GetChoice(),
            sessionID = GetSessionID(),
            handStyle = GetHandStyle(),
            skinStyle = GetSkinStyle()
        };

        //TODO active object
    }

    private void ApplySaveData(SettingsData data, bool save = true)
    {
        SetVolume(data.masterVolume);
        SetHandedness(!data.isLeftHanded);
        SetChoice(data.choice, save);
        SetHandStyle(data.handStyle);
        SetSkinStyle(data.skinStyle);

        if(sessionID != data.sessionID) Debug.LogWarning($"Session ID mismatch between GameSettings and loaded data. Using GameSettings session ID: {sessionID}");
    }

    public void ImportJSONSettings()
    {
        try
        {
            if (!File.Exists(SavePaths.SettingsFile(sessionID)))
            {
                Debug.LogWarning("No settings file found.");
                return;
            }

            string json = File.ReadAllText(SavePaths.SettingsFile(sessionID)).Trim();

            SettingsData data = JsonUtility.FromJson<SettingsData>(json);

            ApplySaveData(data, save: false);

            Debug.Log($"Settings imported from:\n{SavePaths.SettingsFile(sessionID)}");
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to import settings:\n{e}");
        }
    }

    public void ExportJSONSettings()
    {
        try
        {
            Directory.CreateDirectory(SavePaths.RootFolder);
            Directory.CreateDirectory(SavePaths.SessionFolder(sessionID));

            SettingsData data = CreateSaveData();

            string json = JsonUtility.ToJson(data, true);

            File.WriteAllText(SavePaths.SettingsFile(sessionID), json);

            Debug.Log($"Settings exported to:\n{SavePaths.SettingsFile(sessionID)}");
        }
        catch (Exception e)
        {
            Debug.LogError($"Failed to export settings:\n{e}");
        }
    }

    public void ConsumeSession()
    {
        if (consumeExistingSession)
        {
            Debug.Log("Consuming existing session and deleting session file.");
            if (File.Exists(SavePaths.CurrentSessionFile))
            {
                File.Delete(SavePaths.CurrentSessionFile);
                Debug.Log("Session file deleted.");
            }
            else
            {
                Debug.LogWarning("No session file found to delete.");
            }
        }
        else
        {
            Debug.Log("Not consuming existing session. Keeping session file intact.");
        }
    }
}

// using System;
// using UnityEngine;

// public enum DogChoice
// {
//     Random,
//     Collie,
//     Retriever,
//     Beagle
// }

// public enum FoodChoice
// {
//     Random,
//     Bread,
//     Nuts,
//     Seeds
// }

// public class GameSettings : MonoBehaviour
// {
//     public static GameSettings Instance { get; private set; }
//     public event Action<bool> OnHandednessChanged;

//     //public event Action<float> onVolumeChanged;

//     [Header("Audio")]
//     public float masterVolume = 1.0f;

//     [Header("User")]
//     [Tooltip("Set to LeftHanded to prompt an initial CHANGE trigger")]
//     [SerializeField]
//     private bool isLeftHanded = false;

//     [Header("GRIEF")]
//     public DogChoice dogChosen = DogChoice.Random;

//     [Header("SEEKING")]
//     public FoodChoice foodChosen = FoodChoice.Random;

//     void Awake()
//     {
//         if (Instance != null && Instance != this)
//         {
//             Debug.LogWarning("Duplicate GameSettings instance detected. Destroying new one.");
//             Destroy(gameObject);
//             return;
//         }

//         Instance = this;
//         DontDestroyOnLoad(gameObject);
//         Debug.Log("GameSettings instance initialized and marked as DontDestroyOnLoad.");
//     }

//     public void SetVolume(float volume)
//     {
//         Debug.Log($"Volume set to {volume}");
//         this.masterVolume = volume;
//         //onVolumeChanged?.Invoke(this.masterVolume);
//     }

//     public void SetHandedness(bool rightHanded)
//     {
//         //Why stupid and RightHanded? Because of the UI toggle starting ON and to the right...
//         //if (this.isLeftHanded != rightHanded) return; //Forces the changed value to be NEW
//         Debug.Log($"Handedness set to {(rightHanded ? "Right" : "Left")}");
//         this.isLeftHanded = !rightHanded;
//         OnHandednessChanged?.Invoke(this.isLeftHanded);
//     }

//     public void SetFoodChoice(FoodChoice foodChoice)
//     {
//         Debug.Log($"Food choice set to {foodChoice}");
//         this.foodChosen = foodChoice;
//     }

//     public void SetDogChoice(DogChoice dogChoice)
//     {
//         Debug.Log($"Dog choice set to {dogChoice}");
//         this.dogChosen = dogChoice;
//     }

//     public DogChoice GetDogChoice()
//     {
//         Debug.Log($"Getting dog choice: {this.dogChosen}");
//         return this.dogChosen;
//     }

//     public FoodChoice GetFoodChoice()
//     {
//         Debug.Log($"Getting food choice: {this.foodChosen}");
//         return this.foodChosen;
//     }

//     public float GetVolume()
//     {
//         Debug.Log($"Getting volume: {this.masterVolume}");
//         return this.masterVolume;
//     }

//     public bool IsLeftHanded()
//     {
//         Debug.Log($"Getting handedness: {(this.isLeftHanded ? "Left" : "Right")}");
//         return this.isLeftHanded;
//     }
// }
