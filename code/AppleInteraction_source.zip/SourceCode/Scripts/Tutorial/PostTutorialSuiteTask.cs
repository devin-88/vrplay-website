using System;
using System.Collections;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.XR.Interaction.Toolkit.UI;

/// <summary>
/// Final tutorial step: confirm the post-tutorial questionnaire was filled in,
/// then wait before Continue is available to enter the VE.
/// </summary>
public class PostTutorialSuiteTask : TutorialTask
{
    [SerializeField] float requiredWaitSeconds = 30f;
    [SerializeField] Toggle suiteCompletedToggle;
    [SerializeField] Button continueButton;
    [SerializeField] TextMeshProUGUI timerLabel;
    [SerializeField] TextMeshProUGUI instructionLabel;
    [SerializeField] GameObject panelRoot;

    [TextArea]
    [SerializeField] string instructionText =
        "Please complete the <b>post-tutorial questionnaire</b> now.\n\n" +
        "When you have finished it, check the box below. Continue unlocks after a short wait.";

    [SerializeField] string checkboxLabel =
        "I have completed the post-tutorial questionnaire";

    float elapsed;
    bool waitComplete;
    bool taskFinished;
    Coroutine waitRoutine;

    public override void StartTask(Action onComplete)
    {
        if (isStarted) return;

        isStarted = true;
        onTaskComplete = onComplete;
        taskFinished = false;
        waitComplete = false;
        elapsed = 0f;

        EnsurePanel();

        if (panelRoot != null)
            panelRoot.SetActive(true);

        if (instructionLabel != null)
            instructionLabel.text = instructionText;

        if (suiteCompletedToggle != null)
        {
            suiteCompletedToggle.isOn = false;
            suiteCompletedToggle.onValueChanged.RemoveListener(HandleToggleChanged);
            suiteCompletedToggle.onValueChanged.AddListener(HandleToggleChanged);
        }

        if (continueButton != null)
        {
            continueButton.onClick.RemoveListener(HandleContinueClicked);
            continueButton.onClick.AddListener(HandleContinueClicked);
            continueButton.interactable = false;
        }

        UpdateTimerLabel();
        RefreshContinueState();

        if (HandManager.Instance != null)
        {
            HandManager.Instance.SetVisibleUI(ControlsUI.Trigger);
            HandManager.Instance.SetTriggerTooltip("Select");
            HandManager.Instance.SetVisibleInteractors(ControlFlags.Ray | ControlFlags.Direct | ControlFlags.Poke);
            HandManager.Instance.SetHandStyle(HandStyle.Current);
        }

        if (waitRoutine != null)
            StopCoroutine(waitRoutine);
        waitRoutine = StartCoroutine(WaitForContinueUnlock());

        PlaceInFrontOfPlayer();
    }

    void PlaceInFrontOfPlayer()
    {
        if (panelRoot == null)
            return;

        var cam = Camera.main;
        if (cam == null)
        {
            var xr = FindFirstObjectByType<Unity.XR.CoreUtils.XROrigin>();
            if (xr != null && xr.Camera != null)
                cam = xr.Camera;
        }
        if (cam == null)
            return;

        Vector3 forward = cam.transform.forward;
        forward.y = 0f;
        if (forward.sqrMagnitude < 0.001f)
            forward = Vector3.forward;
        forward.Normalize();

        panelRoot.transform.position = cam.transform.position + forward * 1.55f + Vector3.down * 0.15f;
        panelRoot.transform.rotation = Quaternion.LookRotation(forward, Vector3.up);
    }

    IEnumerator WaitForContinueUnlock()
    {
        while (elapsed < requiredWaitSeconds)
        {
            elapsed += Time.unscaledDeltaTime;
            UpdateTimerLabel();
            yield return null;
        }

        waitComplete = true;
        UpdateTimerLabel();
        RefreshContinueState();
        waitRoutine = null;
    }

    void HandleToggleChanged(bool _)
    {
        UpdateTimerLabel();
        RefreshContinueState();
    }

    void RefreshContinueState()
    {
        if (continueButton == null)
            return;

        bool checkedBox = suiteCompletedToggle != null && suiteCompletedToggle.isOn;
        continueButton.interactable = waitComplete && checkedBox;
    }

    void UpdateTimerLabel()
    {
        if (timerLabel == null)
            return;

        if (waitComplete)
        {
            timerLabel.text = suiteCompletedToggle != null && suiteCompletedToggle.isOn
                ? "Ready — press Continue to enter the experience."
                : "Wait complete — check the box to continue.";
            return;
        }

        int remaining = Mathf.CeilToInt(Mathf.Max(0f, requiredWaitSeconds - elapsed));
        timerLabel.text = $"Continue available in <b>{remaining}</b> seconds…";
    }

    void HandleContinueClicked()
    {
        if (taskFinished) return;
        if (!waitComplete) return;
        if (suiteCompletedToggle == null || !suiteCompletedToggle.isOn) return;

        taskFinished = true;
        CompleteTask();
    }

    void CompleteTask()
    {
        if (waitRoutine != null)
        {
            StopCoroutine(waitRoutine);
            waitRoutine = null;
        }

        if (suiteCompletedToggle != null)
            suiteCompletedToggle.onValueChanged.RemoveListener(HandleToggleChanged);

        if (continueButton != null)
            continueButton.onClick.RemoveListener(HandleContinueClicked);

        if (panelRoot != null)
            panelRoot.SetActive(false);

        if (GameSettings.Instance != null)
            GameSettings.Instance.ExportJSONSettings();

        Debug.Log("PostTutorialSuiteTask: Continue accepted — loading VE.");
        onTaskComplete?.Invoke();
    }

    public override void ResetTask()
    {
        if (waitRoutine != null)
        {
            StopCoroutine(waitRoutine);
            waitRoutine = null;
        }

        if (suiteCompletedToggle != null)
            suiteCompletedToggle.onValueChanged.RemoveListener(HandleToggleChanged);
        if (continueButton != null)
            continueButton.onClick.RemoveListener(HandleContinueClicked);

        isStarted = false;
        taskFinished = false;
        StartTask(onTaskComplete);
    }

    public override void ForceCompleteTask()
    {
        waitComplete = true;
        if (suiteCompletedToggle != null)
            suiteCompletedToggle.isOn = true;
        RefreshContinueState();
        if (!taskFinished)
        {
            taskFinished = true;
            CompleteTask();
        }
    }

    void EnsurePanel()
    {
        if (panelRoot != null && continueButton != null && suiteCompletedToggle != null)
            return;

        // Runtime fallback if scene wiring is missing.
        panelRoot = BuildPanel();
    }

    GameObject BuildPanel()
    {
        var root = new GameObject("PostTutorialSuitePanel");
        root.transform.SetParent(transform, false);
        root.transform.localPosition = new Vector3(0f, 1.2f, 1.4f);
        root.transform.localRotation = Quaternion.identity;
        root.transform.localScale = Vector3.one * 0.0015f;

        var canvas = root.AddComponent<Canvas>();
        canvas.renderMode = RenderMode.WorldSpace;
        canvas.worldCamera = Camera.main;
        root.AddComponent<CanvasScaler>().dynamicPixelsPerUnit = 10f;
        root.AddComponent<GraphicRaycaster>();
        root.AddComponent<TrackedDeviceGraphicRaycaster>();

        var rt = root.GetComponent<RectTransform>();
        rt.sizeDelta = new Vector2(900f, 620f);

        var bg = CreateUiObject("Background", root.transform);
        var bgImg = bg.AddComponent<Image>();
        bgImg.color = new Color(0.08f, 0.09f, 0.11f, 0.94f);
        Stretch(bg.GetComponent<RectTransform>());

        instructionLabel = CreateText("Instruction", root.transform, instructionText, 36f, TextAlignmentOptions.Top);
        var instrRt = instructionLabel.rectTransform;
        instrRt.anchorMin = new Vector2(0.06f, 0.55f);
        instrRt.anchorMax = new Vector2(0.94f, 0.94f);
        instrRt.offsetMin = Vector2.zero;
        instrRt.offsetMax = Vector2.zero;

        timerLabel = CreateText("Timer", root.transform, "", 32f, TextAlignmentOptions.Center);
        var timerRt = timerLabel.rectTransform;
        timerRt.anchorMin = new Vector2(0.08f, 0.42f);
        timerRt.anchorMax = new Vector2(0.92f, 0.54f);
        timerRt.offsetMin = Vector2.zero;
        timerRt.offsetMax = Vector2.zero;

        var toggleGo = CreateUiObject("SuiteToggle", root.transform);
        var toggleRt = toggleGo.GetComponent<RectTransform>();
        toggleRt.anchorMin = new Vector2(0.08f, 0.26f);
        toggleRt.anchorMax = new Vector2(0.92f, 0.40f);
        toggleRt.offsetMin = Vector2.zero;
        toggleRt.offsetMax = Vector2.zero;

        suiteCompletedToggle = toggleGo.AddComponent<Toggle>();
        var toggleBg = CreateUiObject("Background", toggleGo.transform);
        var toggleBgImg = toggleBg.AddComponent<Image>();
        toggleBgImg.color = new Color(0.18f, 0.2f, 0.24f, 1f);
        var toggleBgRt = toggleBg.GetComponent<RectTransform>();
        toggleBgRt.anchorMin = new Vector2(0f, 0.5f);
        toggleBgRt.anchorMax = new Vector2(0f, 0.5f);
        toggleBgRt.pivot = new Vector2(0f, 0.5f);
        toggleBgRt.sizeDelta = new Vector2(56f, 56f);
        toggleBgRt.anchoredPosition = new Vector2(8f, 0f);

        var check = CreateUiObject("Checkmark", toggleBg.transform);
        var checkImg = check.AddComponent<Image>();
        checkImg.color = new Color(0.25f, 0.75f, 0.45f, 1f);
        Stretch(check.GetComponent<RectTransform>(), 8f);
        suiteCompletedToggle.targetGraphic = toggleBgImg;
        suiteCompletedToggle.graphic = checkImg;

        var toggleLabel = CreateText("Label", toggleGo.transform, checkboxLabel, 30f, TextAlignmentOptions.Left);
        var toggleLabelRt = toggleLabel.rectTransform;
        toggleLabelRt.anchorMin = new Vector2(0f, 0f);
        toggleLabelRt.anchorMax = new Vector2(1f, 1f);
        toggleLabelRt.offsetMin = new Vector2(80f, 0f);
        toggleLabelRt.offsetMax = new Vector2(-8f, 0f);

        var buttonGo = CreateUiObject("ContinueButton", root.transform);
        var buttonRt = buttonGo.GetComponent<RectTransform>();
        buttonRt.anchorMin = new Vector2(0.25f, 0.07f);
        buttonRt.anchorMax = new Vector2(0.75f, 0.20f);
        buttonRt.offsetMin = Vector2.zero;
        buttonRt.offsetMax = Vector2.zero;
        var buttonImg = buttonGo.AddComponent<Image>();
        buttonImg.color = new Color(0.15f, 0.45f, 0.85f, 1f);
        continueButton = buttonGo.AddComponent<Button>();
        continueButton.targetGraphic = buttonImg;
        var buttonText = CreateText("Label", buttonGo.transform, "Continue", 34f, TextAlignmentOptions.Center);
        Stretch(buttonText.rectTransform);

        return root;
    }

    static GameObject CreateUiObject(string name, Transform parent)
    {
        var go = new GameObject(name, typeof(RectTransform));
        go.transform.SetParent(parent, false);
        return go;
    }

    static TextMeshProUGUI CreateText(string name, Transform parent, string text, float size, TextAlignmentOptions align)
    {
        var go = CreateUiObject(name, parent);
        var tmp = go.AddComponent<TextMeshProUGUI>();
        tmp.text = text;
        tmp.fontSize = size;
        tmp.alignment = align;
        tmp.color = Color.white;
        tmp.enableWordWrapping = true;
        return tmp;
    }

    static void Stretch(RectTransform rt, float inset = 0f)
    {
        rt.anchorMin = Vector2.zero;
        rt.anchorMax = Vector2.one;
        rt.offsetMin = new Vector2(inset, inset);
        rt.offsetMax = new Vector2(-inset, -inset);
    }
}
