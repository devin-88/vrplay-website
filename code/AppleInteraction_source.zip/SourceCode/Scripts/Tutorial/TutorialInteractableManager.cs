using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;


class TutorialItem
{
    public XRGrabInteractable item;
    public Vector3 basePosition;
    public Quaternion baseRotation;

}


public class TutorialInteractableManager : MonoBehaviour
{
    public XRGrabInteractable[] grabInteractables;
    private List<TutorialItem> tutorialItems = new List<TutorialItem>();

     public static TutorialInteractableManager Instance { get; private set; }

    void Start()
    {
        if (Instance != null && Instance != this)
        {
            Debug.LogWarning("Duplicate TutorialInteractableManager instance detected. Destroying new one.");
            Destroy(gameObject);
            return;
        }
        Instance = this;

        foreach (XRGrabInteractable g in this.grabInteractables)
        {
            tutorialItems.Add(new TutorialItem { item = g, basePosition = g.transform.position, baseRotation = g.transform.rotation });
        }
    }

    void Update()
    {
        foreach (TutorialItem ti in this.tutorialItems)
        {
            if (!CheckHeight(ti.item) && !ti.item.isSelected)
            {
                Debug.LogWarning($"Caught object: {ti.item.name}");
                ti.item.GetComponent<Rigidbody>().linearVelocity = Vector3.zero;
                ti.item.GetComponent<Rigidbody>().angularVelocity = Vector3.zero;
                ti.item.transform.SetPositionAndRotation(ti.basePosition, ti.baseRotation);
                //Debug.LogWarning($"Old Pos: {ti.item.transform.position}, New Pos: {ti.basePosition}");
                ti.item.GetComponent<Rigidbody>().Sleep();
            }
        }    
    }

    private bool CheckHeight(XRGrabInteractable item)
    {
        if (item.transform.position.y <= 1.0f)
        {
            return false;
        }
        return true;
    }

    public void DisableHighlight(XRGrabInteractable item)
    {
        item.GetComponentInChildren<InteractiveHighlight_Tutorial>().Disable();
    }

    public void DestroyInteractables()
    {
        foreach (TutorialItem ti in this.tutorialItems)
        {
            ti.item.GetComponent<Rigidbody>().isKinematic = true;
            ti.item.gameObject.SetActive(false);
        }
    }
}
