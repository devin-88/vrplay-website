using System;
using System.Collections.Generic;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.Playables;
using UnityEngine.UI;

public class GestureTask : TutorialTask
{

    [Header("UI")]
    [SerializeField] private TextMeshProUGUI m_instruction;
    [SerializeField] private Button m_confirmButton;
    [SerializeField] private GameObject[] m_gestureColliders;
    [SerializeField] private PlayableDirector m_director;




    [Serializable]
    class Gesture
    {
        public string name;
        public bool status;

        public TextMeshProUGUI label;

        public PlayableAsset asset;
    }

    [Tooltip("List of gestures to be recognized.")]
    [SerializeField] private List<Gesture> m_gestureList = new List<Gesture>();
    //private bool m_gesturesComplete = false;

    // [TextArea]
    // [SerializeField]
    [TextArea]
    [SerializeField] private string m_TASK1 = "Raise an <b>empty hand</b> towards your mouth to trigger a <color=\"green\">calling whistle</color>.";
    [TextArea]
    [SerializeField] private string m_TASK2 = "Repeat the gesture once more.";

    [TextArea]
    [SerializeField] private string m_TASK3 = "You may practise this gesture.\nSelect <color=#2096F3>Confirm</color> to continue.";


    public override void StartTask(Action onComplete)
    {

        if (isStarted) return;
        isStarted = true;

        this.onTaskComplete = onComplete;
        //m_gesturesComplete = false;
        if (m_instruction != null) m_instruction.text = m_TASK1;

        foreach (var gesture in m_gestureList)
        {
            gesture.status = false;
            if (gesture.label != null)
            {
                //Not entered until multiple gestures with labels
                gesture.label.color = Color.red;
                gesture.label.fontStyle = FontStyles.Normal;
            }
        }

        GestureRecognizer.OnGestureRecognized += HandleGestureRecognized;

        if (m_confirmButton != null)
        {
            m_confirmButton.gameObject.SetActive(false); // Initially hidden
            m_confirmButton.onClick.AddListener(HandleConfirmClicked);
        }

        if (m_gestureColliders.Length > 0)
        {
            foreach (var gesture in m_gestureColliders) gesture.SetActive(true);
        }

        HandManager.Instance.SetVisibleUI(ControlsUI.None);
        HandManager.Instance.SetVisibleInteractors(ControlFlags.Direct); //TODO: CHECK FOR JAMES
        HandManager.Instance.SetHandStyle(HandStyle.Current);

        Debug.Log("GestureTask: Waiting for gesture.");
    }

    private void HandleGestureRecognized(string gestureName)
    {
        //if (!isStarted || m_gesturesComplete) return;
        if (!isStarted) return;

        foreach (var gesture in m_gestureList)
        {
            //&&!gesture.status
            if (gesture.name.Equals(gestureName, StringComparison.OrdinalIgnoreCase) && !gesture.status)
            {
                gesture.status = true;
                //gesture.label.color = Color.green;
                //gesture.label.fontStyle = FontStyles.Bold | FontStyles.Italic;
                if (gesture.asset != null) m_director.playableAsset = gesture.asset;
                m_director.Play();

                m_instruction.text = m_TASK2;
                Debug.Log($"GestureTask: Gesture recognized - {gestureName}");
                break;
            }
            else
            {
                //gesture.label.fontStyle = FontStyles.Normal;
            }
        }

        if (AllGesturesCompleted() && m_confirmButton != null)
        {
            //CompleteTask("Manually");
            m_confirmButton.gameObject.SetActive(true);
            m_confirmButton.interactable = true;
            HandManager.Instance.SetVisibleInteractors(ControlFlags.Ray);
            m_instruction.text = m_TASK3;

        }
    }

    public override void ResetTask()
    {
        Debug.Log("GestureTask: Resetting.");

        isStarted = false;
        GestureRecognizer.OnGestureRecognized -= HandleGestureRecognized;

        if (m_confirmButton != null)
        {
            m_confirmButton.onClick.RemoveListener(HandleConfirmClicked);
            m_confirmButton.gameObject.SetActive(false);
        }

        StartTask(onTaskComplete);
    }

    public override void ForceCompleteTask()
    {
        isStarted = false;
        //m_isGestureDone = true;

        CompleteTask("Forced");
    }

    private bool AllGesturesCompleted()
    {
        foreach (var gesture in m_gestureList)
        {
            if (!gesture.status) return false;
        }
        //m_gesturesComplete = true;
        return true;
    }

    private void CompleteTask(string method)
    {
        Debug.LogWarning($"GestureTask: Completed - {method}");
        GestureRecognizer.OnGestureRecognized -= HandleGestureRecognized;

        if (m_confirmButton != null)
        {
            m_confirmButton.onClick.RemoveListener(HandleConfirmClicked);
            m_confirmButton.gameObject.SetActive(false);
        }

        onTaskComplete?.Invoke();
    }

    private void HandleConfirmClicked()
    {
        if (!isStarted) return;

        Debug.Log("GestureTask: Confirm button clicked by user.");
        CompleteTask("Manual");
    }

    private void OnDisable()
    {
        if (m_gestureColliders.Length > 0)
        {
            foreach (var gesture in m_gestureColliders) gesture.SetActive(false);
        }
    }
}
