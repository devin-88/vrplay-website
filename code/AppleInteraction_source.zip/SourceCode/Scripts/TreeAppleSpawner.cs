using UnityEngine;
using System.Collections.Generic;


public class TreeAppleSpawner : MonoBehaviour
{
    public GameObject hangingApplePrefab;

    public Transform[] spawnPoints;

    public Material[] appleMaterials;


    // Adjust this until apples face upright
    public Vector3 spawnRotation =
        new Vector3(90f, 0f, 0f);



    private List<Material> colourQueue =
        new List<Material>();

    private int colourIndex = 0;



    void Start()
    {
        CreateColourQueue();


        foreach (Transform point in spawnPoints)
        {
            SpawnHangingApple(point);
        }
    }



    void SpawnHangingApple(Transform point)
    {
        GameObject apple =
            Instantiate(
                hangingApplePrefab,
                point.position,
                Quaternion.Euler(spawnRotation)
            );


        HangingApple script =
            apple.GetComponent<HangingApple>();


        script.SetColour(
            GetNextColour()
        );
    }



    Material GetNextColour()
    {
        Material mat =
            colourQueue[colourIndex];


        colourIndex++;


        if (colourIndex >= colourQueue.Count)
        {
            CreateColourQueue();
            colourIndex = 0;
        }


        return mat;
    }



    void CreateColourQueue()
    {
        colourQueue.Clear();


        foreach (Material mat in appleMaterials)
        {
            colourQueue.Add(mat);
        }


        // Shuffle
        for (int i = 0; i < colourQueue.Count; i++)
        {
            int randomIndex =
                Random.Range(
                    i,
                    colourQueue.Count
                );


            Material temp =
                colourQueue[i];


            colourQueue[i] =
                colourQueue[randomIndex];


            colourQueue[randomIndex] =
                temp;
        }
    }
}