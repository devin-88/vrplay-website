using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

/// <summary>
/// Shared apple identity used by ground and hanging apples: hold state, glow, basket membership, fade.
/// </summary>
[RequireComponent(typeof(XRGrabInteractable))]
public class AppleItem : MonoBehaviour
{
    public float inactiveTime = 60f;
    public float glowIntensity = 1.4f;

    XRGrabInteractable grab;
    Rigidbody body;
    Renderer appleRenderer;
    ParticleSystem sparkles;
    Color[] baseEmissionColors;
    bool[] hadEmission;
    MaterialPropertyBlock propertyBlock;
    float lastInteractionTime;
    bool hasBeenInteractedWith;
    bool isHeldByPlayer;
    bool isHeldByNpc;
    PlayBasket containingBasket;

    static readonly int EmissionColorId = Shader.PropertyToID("_EmissionColor");

    public bool IsHeldByPlayer => isHeldByPlayer;
    public bool IsHeldByNpc => isHeldByNpc;
    public bool IsInBasket => containingBasket != null;
    public bool IsLoose => !isHeldByPlayer && !isHeldByNpc && containingBasket == null;
    public XRGrabInteractable Grab => grab;
    public Rigidbody Body => body;

    bool storedThrowOnDetach = true;

    public float WorldRadius
    {
        get
        {
            var sphere = GetComponent<SphereCollider>();
            if (sphere != null)
            {
                Vector3 scale = transform.lossyScale;
                return sphere.radius * Mathf.Max(scale.x, Mathf.Max(scale.y, scale.z));
            }

            var col = GetComponent<Collider>();
            if (col != null)
                return Mathf.Max(0.08f, col.bounds.extents.y);
            return 0.2f;
        }
    }

    void Awake()
    {
        grab = GetComponent<XRGrabInteractable>();
        body = GetComponent<Rigidbody>();
        appleRenderer = GetComponent<Renderer>();
        sparkles = GetComponentInChildren<ParticleSystem>(true);
        propertyBlock = new MaterialPropertyBlock();

        CacheEmission();

        grab.selectEntered.AddListener(OnGrab);
        grab.selectExited.AddListener(OnRelease);
    }

    void OnEnable()
    {
        AppleManager.Register(this);
        lastInteractionTime = Time.time;
    }

    void OnDisable()
    {
        AppleManager.Unregister(this);
    }

    void OnDestroy()
    {
        if (grab != null)
        {
            grab.selectEntered.RemoveListener(OnGrab);
            grab.selectExited.RemoveListener(OnRelease);
        }
    }

    void Update()
    {
        if (!hasBeenInteractedWith || isHeldByPlayer || isHeldByNpc || IsInBasket)
            return;

        if (transform.position.y < -20f)
        {
            AppleManager.NotifyFaded(this);
            Destroy(gameObject);
            return;
        }

        if (Time.time - lastInteractionTime > inactiveTime)
        {
            AppleManager.NotifyFaded(this);
            Destroy(gameObject);
        }
    }

    void OnGrab(SelectEnterEventArgs args)
    {
        hasBeenInteractedWith = true;
        isHeldByPlayer = true;
        SetNpcHeld(false);
        LeaveBasket();
        ResetInteractionTimer();
        SetHeldGlow(true);
        PlayAudio.Play(PlayAudio.Cue.ApplePop, transform.position);
        PlaySession.Instance?.NotifyFirstPickup();
        PlayWorld.Instance?.PulseHaptics(0.35f, 0.06f);
        PlayLog.Logger?.NotifyParticipantPickup();
    }

    void OnRelease(SelectExitEventArgs args)
    {
        isHeldByPlayer = false;
        SetHeldGlow(false);
        ResetInteractionTimer();
    }

    public void ResetInteractionTimer()
    {
        lastInteractionTime = Time.time;
    }

    public void MarkInteracted()
    {
        hasBeenInteractedWith = true;
        ResetInteractionTimer();
    }

    public void SetNpcHeld(bool held)
    {
        isHeldByNpc = held;
        if (held)
        {
            isHeldByPlayer = false;
            LeaveBasket();
            SetHeldGlow(true);
        }
        else
        {
            SetHeldGlow(isHeldByPlayer);
        }
    }

    public void SetContainingBasket(PlayBasket basket)
    {
        containingBasket = basket;
        if (basket != null)
            ResetInteractionTimer();
    }

    public void LeaveBasket()
    {
        if (containingBasket == null)
            return;

        var previous = containingBasket;
        containingBasket = null;
        previous.ReleaseApple(this);
    }

    public void PrepareForNpcCarry()
    {
        MarkInteracted();
        SetNpcHeld(true);
        ForceDropFromPlayer();

        if (body != null)
        {
            body.detectCollisions = false;
            body.linearVelocity = Vector3.zero;
            body.angularVelocity = Vector3.zero;
            body.useGravity = false;
            body.isKinematic = true;
        }

        if (grab != null)
        {
            storedThrowOnDetach = grab.throwOnDetach;
            grab.throwOnDetach = false;
            grab.enabled = false;
        }
    }

    public void RestoreAsLoose(bool enableGrab = true)
    {
        SetNpcHeld(false);

        if (body != null)
        {
            body.detectCollisions = true;
            body.isKinematic = false;
            body.useGravity = true;
            body.collisionDetectionMode = CollisionDetectionMode.ContinuousDynamic;
        }

        if (grab != null)
        {
            grab.throwOnDetach = storedThrowOnDetach;
            grab.enabled = enableGrab;
        }

        ResetInteractionTimer();
    }

    public void ForceDropFromPlayer()
    {
        if (grab == null || !grab.isSelected || grab.interactionManager == null)
            return;

        var selecting = grab.interactorsSelecting;
        for (int i = selecting.Count - 1; i >= 0; i--)
            grab.interactionManager.SelectExit(selecting[i], grab);
    }

    void SetHeldGlow(bool glowing)
    {
        if (sparkles != null)
        {
            var emission = sparkles.emission;
            emission.rateOverTimeMultiplier = glowing ? 12f : 3f;
        }

        if (appleRenderer == null || hadEmission == null)
            return;

        appleRenderer.GetPropertyBlock(propertyBlock);
        for (int i = 0; i < appleRenderer.sharedMaterials.Length; i++)
        {
            Color color = hadEmission[i] ? baseEmissionColors[i] : Color.black;
            if (glowing)
                color = Color.Lerp(color, Color.white, 0.35f) * glowIntensity;
            propertyBlock.SetColor(EmissionColorId, color);
        }
        appleRenderer.SetPropertyBlock(propertyBlock);
    }

    void CacheEmission()
    {
        if (appleRenderer == null)
            return;

        var mats = appleRenderer.sharedMaterials;
        baseEmissionColors = new Color[mats.Length];
        hadEmission = new bool[mats.Length];
        for (int i = 0; i < mats.Length; i++)
        {
            if (mats[i] != null && mats[i].HasProperty(EmissionColorId))
            {
                hadEmission[i] = true;
                baseEmissionColors[i] = mats[i].GetColor(EmissionColorId);
            }
        }
    }
}
