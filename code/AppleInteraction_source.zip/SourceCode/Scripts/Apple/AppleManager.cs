using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Keeps at most five apples in play and respawns at meadow patches when fewer than three remain.
/// </summary>
public class AppleManager : MonoBehaviour
{
    public static AppleManager Instance { get; private set; }

    public GameObject applePrefab;
    public Transform[] spawnPoints;
    public Material[] appleMaterials;
    public int maxApples = 5;
    public int refillBelow = 3;
    public float physicsDelay = 0.5f;

    readonly List<AppleItem> apples = new List<AppleItem>();
    readonly List<Material> colourQueue = new List<Material>();
    int colourIndex;

    public int ActiveCount
    {
        get
        {
            Prune();
            return apples.Count;
        }
    }

    void Awake()
    {
        Instance = this;
        CreateColourQueue();
    }

    void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    void Update()
    {
        if (ActiveCount < refillBelow)
            SpawnApple();
    }

    public static void Register(AppleItem apple)
    {
        if (Instance == null || apple == null)
            return;
        if (!Instance.apples.Contains(apple))
            Instance.apples.Add(apple);
    }

    public static void Unregister(AppleItem apple)
    {
        if (Instance == null || apple == null)
            return;
        Instance.apples.Remove(apple);
    }

    public static void NotifyFaded(AppleItem apple)
    {
        Unregister(apple);
    }

    public AppleItem SpawnApple(Vector3? position = null)
    {
        if (applePrefab == null || ActiveCount >= maxApples)
            return null;

        Vector3 spawnPos;
        if (position.HasValue)
        {
            spawnPos = position.Value;
        }
        else if (spawnPoints != null && spawnPoints.Length > 0)
        {
            var point = spawnPoints[Random.Range(0, spawnPoints.Length)];
            spawnPos = point != null ? point.position : Vector3.zero;
        }
        else if (PlayWorld.Instance != null)
        {
            spawnPos = PlayWorld.Instance.RandomPointAroundTree(5f, Mathf.Max(8f, PlayWorld.Instance.meadowOuterRadius * 0.45f));
        }
        else
        {
            return null;
        }

        GameObject go = Instantiate(applePrefab, spawnPos, Quaternion.identity);
        var apple = go.GetComponent<AppleItem>();
        if (apple == null)
            apple = go.AddComponent<AppleItem>();

        var coloured = go.GetComponent<Apple>();
        if (coloured != null)
            coloured.SetColour(GetNextColour());

        var rb = go.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.isKinematic = true;
            StartCoroutine(EnablePhysics(rb));
        }

        PlayAudio.Play(PlayAudio.Cue.AppleShimmer, spawnPos);
        Register(apple);
        return apple;
    }

    public AppleItem FindNearestLooseApple(Vector3 from, float maxDistance = 40f)
    {
        Prune();
        AppleItem best = null;
        float bestDist = maxDistance;
        for (int i = 0; i < apples.Count; i++)
        {
            var apple = apples[i];
            if (apple == null || !apple.IsLoose)
                continue;

            float dist = Vector3.Distance(from, apple.transform.position);
            if (dist < bestDist)
            {
                bestDist = dist;
                best = apple;
            }
        }

        return best;
    }

    public List<AppleItem> AllApples()
    {
        Prune();
        return apples;
    }

    void Prune()
    {
        apples.RemoveAll(a => a == null);
    }

    System.Collections.IEnumerator EnablePhysics(Rigidbody rb)
    {
        yield return new WaitForSeconds(physicsDelay);
        if (rb != null)
            rb.isKinematic = false;
    }

    Material GetNextColour()
    {
        if (appleMaterials == null || appleMaterials.Length == 0)
            return null;

        if (colourQueue.Count == 0)
            CreateColourQueue();

        Material mat = colourQueue[colourIndex];
        colourIndex++;
        if (colourIndex >= colourQueue.Count)
        {
            CreateColourQueue();
            colourIndex = 0;
        }

        return mat;
    }

    void CreateColourQueue()
    {
        colourQueue.Clear();
        if (appleMaterials == null)
            return;

        colourQueue.AddRange(appleMaterials);
        for (int i = 0; i < colourQueue.Count; i++)
        {
            int randomIndex = Random.Range(i, colourQueue.Count);
            (colourQueue[i], colourQueue[randomIndex]) = (colourQueue[randomIndex], colourQueue[i]);
        }
    }
}
