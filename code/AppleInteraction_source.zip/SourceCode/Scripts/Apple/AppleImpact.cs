using UnityEngine;

public class AppleImpact : MonoBehaviour
{
    public float minImpactSpeed = 0.8f;
    public float cooldown = 0.25f;

    float lastImpactTime;

    void OnCollisionEnter(Collision collision)
    {
        if (Time.time - lastImpactTime < cooldown)
            return;
        if (collision.relativeVelocity.magnitude < minImpactSpeed)
            return;

        lastImpactTime = Time.time;
        bool wood = collision.collider.CompareTag("Tree") ||
                    collision.collider.GetComponentInParent<PlayBasket>() != null ||
                    collision.collider.name.ToLower().Contains("tree") ||
                    collision.collider.name.ToLower().Contains("basket");

        PlayAudio.Play(wood ? PlayAudio.Cue.AppleBonk : PlayAudio.Cue.AppleThud, transform.position);
    }
}
