using System.Collections;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

public class Throwable : MonoBehaviour
{
    Rigidbody rb;
    XRGrabInteractable grab;
    AppleItem item;

    [Header("Throw Settings")]
    public float throwVelocityThreshold = 0.5f;

    public bool WasThrown { get; private set; }
    public Vector3 ThrowVelocity { get; private set; }

    SquirrelSensors squirrel;

    void Awake()
    {
        rb = GetComponent<Rigidbody>();
        grab = GetComponent<XRGrabInteractable>();
        item = GetComponent<AppleItem>();
        if (grab != null)
            grab.selectExited.AddListener(OnRelease);
    }

    void Start()
    {
        squirrel = FindFirstObjectByType<SquirrelSensors>();
    }

    void OnDestroy()
    {
        if (grab != null)
            grab.selectExited.RemoveListener(OnRelease);
    }

    void OnRelease(SelectExitEventArgs args)
    {
        if (item != null && item.IsHeldByNpc)
            return;

        StopAllCoroutines();
        StartCoroutine(NotifyAfterDetach());
    }

    IEnumerator NotifyAfterDetach()
    {
        // XR Grab applies throwOnDetach in LateUpdate after selectExited.
        yield return new WaitForEndOfFrame();
        if (rb == null || (item != null && item.IsHeldByNpc))
            yield break;

        Vector3 best = rb.linearVelocity;
        for (int i = 0; i < 3; i++)
        {
            yield return new WaitForFixedUpdate();
            if (rb == null || (item != null && (item.IsHeldByNpc || item.IsHeldByPlayer)))
                yield break;
            if (rb.linearVelocity.magnitude > best.magnitude)
                best = rb.linearVelocity;
        }

        ThrowVelocity = best;
        if (ThrowVelocity.magnitude <= throwVelocityThreshold)
        {
            WasThrown = false;
            PlayLog.Logger?.NotifyParticipantDrop(transform.position);
            yield break;
        }

        WasThrown = true;
        PlayAudio.Play(PlayAudio.Cue.AppleWhoosh, transform.position);
        PlayWorld.Instance?.PulseHaptics(0.25f, 0.04f);

        if (PlaySession.Instance != null && !PlaySession.Instance.FirstThrowDone)
            PlaySession.Instance.NotifyFirstThrow();

        PlayLog.Logger?.NotifyParticipantThrow(transform.position, ThrowVelocity);

        if (squirrel == null)
            squirrel = FindFirstObjectByType<SquirrelSensors>();
        if (squirrel != null)
            squirrel.NotifyThrownApple(transform, ThrowVelocity);
    }
}
