using UnityEngine;

public class HandFollow : MonoBehaviour
{
    public Transform hand;

    void LateUpdate()
    {
        transform.position = hand.position;
        transform.rotation = hand.rotation;
    }
}