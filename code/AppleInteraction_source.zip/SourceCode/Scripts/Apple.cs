using UnityEngine;

public class Apple : MonoBehaviour
{
    public Material[] appleMaterials;
    Renderer appleRenderer;

    void Awake()
    {
        appleRenderer = GetComponent<Renderer>();
        if (GetComponent<AppleItem>() == null)
            gameObject.AddComponent<AppleItem>();
        if (GetComponent<AppleImpact>() == null)
            gameObject.AddComponent<AppleImpact>();
    }

    public void SetColour(Material mat)
    {
        if (appleRenderer == null)
            appleRenderer = GetComponent<Renderer>();
        if (appleRenderer != null && mat != null)
            appleRenderer.material = mat;
    }

    public void SetRandomColour()
    {
        if (appleMaterials == null || appleMaterials.Length == 0)
            return;
        SetColour(appleMaterials[Random.Range(0, appleMaterials.Length)]);
    }
}
