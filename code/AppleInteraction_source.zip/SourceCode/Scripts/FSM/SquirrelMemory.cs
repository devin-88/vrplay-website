using UnityEngine;

public class SquirrelMemory : MonoBehaviour
{
    public float playfulness = 0.6f;
    public float tiredness = 0f;

    public AppleAction lastAppleAction = AppleAction.Offer;
    public float lastChainTime = -999f;
    public float lastCatchTime = -999f;
    public float holdStartedAt;

    public bool JustCaughtApple => Time.time - lastCatchTime < 4f;

    void Update()
    {
        tiredness += Time.deltaTime * (0.02f / 60f);
        tiredness = Mathf.Clamp01(tiredness);
    }

    public void IncreasePlay()
    {
        playfulness = Mathf.Clamp01(playfulness + 0.05f);
        lastChainTime = Time.time;
    }

    public void Ignored()
    {
        playfulness = Mathf.Clamp01(playfulness - 0.1f);
    }

    public void RecordAppleAction(AppleAction action)
    {
        lastAppleAction = action;
    }

    public void RecordCatch()
    {
        lastCatchTime = Time.time;
    }

    public void BeginHold()
    {
        holdStartedAt = Time.time;
    }

    public float HoldDuration => Time.time - holdStartedAt;

    public bool ChainCompletedInLast(float seconds)
    {
        return Time.time - lastChainTime <= seconds;
    }
}
