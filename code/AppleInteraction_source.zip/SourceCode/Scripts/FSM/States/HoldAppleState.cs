using UnityEngine;

public class HoldAppleState : State
{
    float decideAt;
    bool decided;

    public HoldAppleState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.HoldingApple;

    public override void Enter()
    {
        decided = false;
        squirrel.memory.BeginHold();
        squirrel.SetAnimBool("HoldingApple", true);
        squirrel.StopMoving();
        decideAt = Time.time + Random.Range(0.6f, 1.6f);
    }

    public override void UpdateState()
    {
        if (PlayWorld.Instance != null && PlayWorld.Instance.PlayerIsHoldingApple)
        {
            squirrel.ChangeState(new WatchingState(squirrel));
            return;
        }

        if (squirrel.sensors.AppleThrown() && squirrel.sensors.currentApple != squirrel.heldApple)
        {
            squirrel.ChangeState(new ChaseAppleState(squirrel));
            return;
        }

        if (squirrel.sensors.player != null)
            squirrel.Face(squirrel.sensors.player.position);

        if (decided || Time.time < decideAt)
            return;

        decided = true;
        AppleAction action = SquirrelDecisions.ChooseAppleAction(
            squirrel.memory,
            squirrel.sensors,
            squirrel.memory.HoldDuration);
        squirrel.memory.RecordAppleAction(action);

        switch (action)
        {
            case AppleAction.Offer:
                squirrel.ChangeState(new OfferAppleState(squirrel));
                break;
            case AppleAction.Evade:
                squirrel.ChangeState(new EvadeState(squirrel));
                break;
            case AppleAction.Drop:
                squirrel.ChangeState(new DropAppleState(squirrel));
                break;
            default:
                squirrel.ChangeState(new ThrowAppleState(squirrel));
                break;
        }
    }

    public override void Exit()
    {
        if (!squirrel.HoldingApple)
            squirrel.SetAnimBool("HoldingApple", false);
    }
}
