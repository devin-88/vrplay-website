using UnityEngine;

public class ThrownAtReactState : State
{
    readonly ThrownAtReaction reaction;
    float timer;
    float duration;
    Vector3 dodgeTarget;
    bool catchPlayed;
    bool celebrated;

    public ThrownAtReaction Reaction => reaction;

    public ThrownAtReactState(SquirrelFSM squirrel, ThrownAtReaction reaction) : base(squirrel)
    {
        this.reaction = reaction;
    }

    public override SquirrelState Id
    {
        get
        {
            switch (reaction)
            {
                case ThrownAtReaction.Catch:
                    return SquirrelState.Retrieving;
                case ThrownAtReaction.Shocked:
                case ThrownAtReaction.PlayfulTrip:
                    return SquirrelState.Surprise;
                default:
                    return SquirrelState.Idle;
            }
        }
    }

    public override void Enter()
    {
        timer = 0f;
        catchPlayed = false;
        celebrated = false;
        PlayLog.Logger?.NotifyNpcReaction(reaction);
        squirrel.sensors.ConsumeIncomingApple();
        duration = 1.1f;

        switch (reaction)
        {
            case ThrownAtReaction.Dodge:
                PlayAudio.Play(PlayAudio.Cue.DodgeWhoop, squirrel.transform.position);
                dodgeTarget = squirrel.transform.position + squirrel.transform.right * (Random.value < 0.5f ? -1.4f : 1.4f);
                if (UnityEngine.AI.NavMesh.SamplePosition(dodgeTarget, out var hit, 2f, UnityEngine.AI.NavMesh.AllAreas))
                    dodgeTarget = hit.position;
                squirrel.MoveTo(dodgeTarget, true);
                squirrel.PlayAction("Jump");
                duration = 0.9f;
                break;
            case ThrownAtReaction.Catch:
                duration = 1.6f;
                PlayAudio.Play(PlayAudio.Cue.ExcitedChitter, squirrel.transform.position);
                break;
            case ThrownAtReaction.Shocked:
                PlayAudio.Play(PlayAudio.Cue.Doh, squirrel.transform.position);
                squirrel.PlayHitStyle(IncomingPoint());
                duration = 1.2f;
                break;
            case ThrownAtReaction.PlayfulTrip:
                PlayAudio.Play(PlayAudio.Cue.Doh, squirrel.transform.position);
                squirrel.PlayHitStyle(IncomingPoint());
                duration = 1.4f;
                break;
            case ThrownAtReaction.Taunt:
                PlayAudio.Play(PlayAudio.Cue.Taunt, squirrel.transform.position);
                squirrel.PlayAction("Offer");
                duration = 1.1f;
                break;
        }
    }

    public override void UpdateState()
    {
        timer += Time.deltaTime;

        if (reaction == ThrownAtReaction.Catch)
        {
            UpdateCatch();
            return;
        }

        if (timer < duration)
            return;

        if (squirrel.sensors.currentApple != null && !squirrel.HoldingApple)
            squirrel.ChangeState(new ChaseAppleState(squirrel));
        else
            squirrel.ChangeState(new IdleState(squirrel));
    }

    void UpdateCatch()
    {
        Transform apple = squirrel.sensors.currentApple;
        if (apple == null && squirrel.sensors.incomingApple != null)
            apple = squirrel.sensors.incomingApple.transform;

        if (apple == null)
        {
            if (timer > 0.35f)
                squirrel.ChangeState(new IdleState(squirrel));
            return;
        }

        squirrel.Face(apple.position);
        Vector3 intercept = squirrel.sensors.interceptPoint;
        if (intercept.sqrMagnitude > 0.01f)
            squirrel.MoveTo(intercept, true);
        else
            squirrel.MoveTo(apple.position, true);

        float distance = Vector3.Distance(squirrel.transform.position, apple.position);
        bool closeEnough = distance < 1.15f || (timer > 0.2f && distance < 1.45f);
        if (!squirrel.HoldingApple && closeEnough)
        {
            if (!catchPlayed)
            {
                squirrel.PlayCatchStyle(apple);
                catchPlayed = true;
            }

            squirrel.PickUpApple(apple, false);
        }

        if (squirrel.HoldingApple)
        {
            squirrel.StopMoving();
            squirrel.memory.RecordCatch();
            if (!celebrated)
            {
                celebrated = true;
                squirrel.PlayCelebration();
                PlayAudio.Play(PlayAudio.Cue.HappyChirp, squirrel.transform.position);
                duration = timer + 1.05f;
            }

            if (timer < duration)
                return;

            if (PlaySession.Instance != null && PlaySession.Instance.ConsumeFirstThrowReturn())
            {
                squirrel.memory.IncreasePlay();
                squirrel.ChangeState(new OfferAppleState(squirrel));
                return;
            }

            squirrel.ChangeState(new HoldAppleState(squirrel));
            return;
        }

        if (timer > duration)
            squirrel.ChangeState(new ChaseAppleState(squirrel));
    }

    public override void Exit()
    {
        squirrel.SetRunning(false);
        if (reaction != ThrownAtReaction.Catch)
            squirrel.sensors.IgnoreIncomingFor(1.25f);
    }

    Vector3 IncomingPoint()
    {
        if (squirrel.sensors.currentApple != null)
            return squirrel.sensors.currentApple.position;
        return squirrel.transform.position + squirrel.transform.forward;
    }
}
