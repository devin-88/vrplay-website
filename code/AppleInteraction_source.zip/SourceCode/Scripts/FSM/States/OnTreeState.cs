using UnityEngine;

public class OnTreeState : State
{
    enum Phase
    {
        WalkToTree,
        ClimbUp,
        Play,
        ClimbDown
    }

    Phase phase;
    float phaseStarted;
    float playStarted;
    float nextTossAt;
    float pendingThrowReleaseAt = -1f;
    Vector3 pendingThrowVelocity;
    Vector3 groundPosition;
    Vector3 perchPosition;

    public OnTreeState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.Watching;

    public override void Enter()
    {
        phase = Phase.WalkToTree;
        phaseStarted = Time.time;
        squirrel.IsOnTree = false;
        squirrel.SetRunning(false);
        squirrel.SetPhysicsDriven(false);

        Vector3 target = GetApproachPoint();
        squirrel.MoveTo(target, false);
    }

    public override void UpdateState()
    {
        switch (phase)
        {
            case Phase.WalkToTree:
                if (squirrel.ReachedDestination(1.1f) || Time.time - phaseStarted > 8f)
                    BeginClimb();
                break;
            case Phase.ClimbUp:
                StepClimb(perchPosition);
                if (Vector3.Distance(squirrel.transform.position, perchPosition) < 0.12f ||
                    Time.time - phaseStarted > 5f)
                    BeginPlay();
                break;
            case Phase.Play:
                UpdatePlay();
                break;
            case Phase.ClimbDown:
                StepClimb(groundPosition);
                if (Vector3.Distance(squirrel.transform.position, groundPosition) < 0.15f ||
                    Time.time - phaseStarted > 5f)
                    FinishDown();
                break;
        }
    }

    public override void Exit()
    {
        squirrel.IsOnTree = false;
        squirrel.IsClimbingTree = false;
        squirrel.SetAgentEnabled(true);
        squirrel.SetPhysicsDriven(false);
        squirrel.SetRunning(false);
    }

    void BeginClimb()
    {
        phase = Phase.ClimbUp;
        phaseStarted = Time.time;
        groundPosition = GetApproachPoint();
        perchPosition = GetPerchPoint();

        squirrel.StopMoving();
        squirrel.SetAgentEnabled(false);
        squirrel.SetPhysicsDriven(false);
        squirrel.PlayClimbAnimation(true);
        squirrel.IsOnTree = true;
        squirrel.IsClimbingTree = true;
        PlayAudio.Play(PlayAudio.Cue.ClimbStart, squirrel.transform.position);
        FaceTrunk(true);
    }

    void BeginPlay()
    {
        phase = Phase.Play;
        playStarted = Time.time;
        nextTossAt = Time.time + Random.Range(1.2f, 2.4f);
        squirrel.transform.position = perchPosition;
        squirrel.IsClimbingTree = false;
        squirrel.PlayClimbAnimation(false);
        squirrel.PlayCelebration();
        TryTakeNearbyApple();
    }

    void UpdatePlay()
    {
        if (squirrel.sensors.player != null)
            squirrel.Face(squirrel.sensors.player.position);

        if (pendingThrowReleaseAt > 0f)
        {
            if (Time.time >= pendingThrowReleaseAt)
            {
                pendingThrowReleaseAt = -1f;
                if (squirrel.HoldingApple)
                    squirrel.ThrowApple(pendingThrowVelocity);
            }
            return;
        }

        bool noReaction = Time.time - playStarted > 10f &&
                          (PlayWorld.Instance == null || PlayWorld.Instance.PlayerIsIdle);
        if (noReaction || squirrel.sensors.PlayerIsClimbing())
        {
            BeginDown();
            return;
        }

        if (Time.time < nextTossAt)
            return;

        nextTossAt = Time.time + Random.Range(1.4f, 2.8f);
        if (!squirrel.HoldingApple)
            TryTakeNearbyApple();

        if (!squirrel.HoldingApple)
            return;

        if (SquirrelDecisions.ChooseThrowWhileOnTree())
        {
            squirrel.PlayThrowStyle(true);
            pendingThrowVelocity = squirrel.ComputeOfferThrowVelocity() * 1.15f;
            pendingThrowReleaseAt = Time.time + squirrel.GetThrowReleaseDelay(true);
            nextTossAt = pendingThrowReleaseAt + 1.2f;
        }
        else
        {
            squirrel.DropApple();
        }
    }

    void BeginDown()
    {
        phase = Phase.ClimbDown;
        phaseStarted = Time.time;
        squirrel.IsClimbingTree = true;
        squirrel.PlayClimbAnimation(true);
        FaceTrunk(true);
    }

    void FinishDown()
    {
        squirrel.IsOnTree = false;
        squirrel.IsClimbingTree = false;
        squirrel.SetAgentEnabled(true);
        squirrel.SetPhysicsDriven(false);
        squirrel.WarpTo(groundPosition);
        squirrel.ChangeState(new IdleState(squirrel));
    }

    void StepClimb(Vector3 target)
    {
        Vector3 next = target;
        Vector3 outward = squirrel.transform.position - (TreeClimbRig.Instance != null
            ? TreeClimbRig.Instance.TrunkBase
            : squirrel.transform.position);
        outward.y = 0f;
        if (outward.sqrMagnitude < 0.01f)
            outward = squirrel.transform.forward;

        if (TreeClimbRig.Instance != null)
        {
            float t = Mathf.Clamp01((Time.time - phaseStarted) / 2.6f);
            if (phase == Phase.ClimbDown)
                t = 1f - t;
            next = TreeClimbRig.Instance.GetClimbSurfacePoint(Mathf.Lerp(0.04f, 0.42f, t), outward);
            if (phase == Phase.ClimbDown && t < 0.15f)
                next = target;
            else if (phase == Phase.ClimbUp && Vector3.Distance(next, target) < 0.45f)
                next = target;
        }

        squirrel.transform.position = Vector3.MoveTowards(
            squirrel.transform.position,
            next,
            1.2f * Time.deltaTime);
        FaceTrunk(false);
    }

    void FaceTrunk(bool immediate)
    {
        // Climb clip rewrites Armature rotation (undoing the +90° walk offset), so
        // aiming the transform at the centerline makes the visible nose face outward.
        // Face along the outward normal so the animated mesh looks into the bark.
        Vector3 outward;
        if (TreeClimbRig.Instance != null &&
            TreeClimbRig.Instance.trunkPath != null &&
            TreeClimbRig.Instance.trunkPath.TryGetClosestCenterline(
                squirrel.transform.position, out _, out outward))
        {
            outward.y = 0f;
            if (outward.sqrMagnitude < 0.001f)
                outward = squirrel.transform.forward;
        }
        else if (TreeClimbRig.Instance != null)
        {
            outward = squirrel.transform.position - TreeClimbRig.Instance.TrunkBase;
            outward.y = 0f;
            if (outward.sqrMagnitude < 0.001f)
                outward = squirrel.transform.forward;
        }
        else
        {
            return;
        }

        Vector3 lookAt = squirrel.transform.position + outward.normalized;
        if (immediate)
            squirrel.FaceImmediate(lookAt);
        else
            squirrel.Face(lookAt);
    }

    void TryTakeNearbyApple()
    {
        if (AppleManager.Instance == null)
            return;

        var apple = AppleManager.Instance.FindNearestLooseApple(squirrel.transform.position, 2.4f);
        if (apple != null)
            squirrel.PickUpApple(apple.transform, false);
    }

    static Vector3 GetApproachPoint()
    {
        if (TreeClimbRig.Instance != null)
            return TreeClimbRig.Instance.GetApproachPoint();
        if (PlayWorld.Instance != null)
            return PlayWorld.Instance.RandomPointAroundTree(0.8f, 1.4f);
        return Vector3.zero;
    }

    static Vector3 GetPerchPoint()
    {
        if (TreeClimbRig.Instance != null)
            return TreeClimbRig.Instance.GetPerchPoint(0);
        return GetApproachPoint() + Vector3.up * 1.5f;
    }
}
