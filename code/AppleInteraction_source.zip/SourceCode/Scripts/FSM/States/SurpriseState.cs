using UnityEngine;

public class SurpriseState : State
{
    float timer;

    public SurpriseState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.Surprise;

    public override void Enter()
    {
        timer = 0f;
        squirrel.StopMoving();
        if (squirrel.sensors != null && squirrel.sensors.player != null)
            squirrel.PlayHitStyle(squirrel.sensors.player.position);
        else
            squirrel.PlayAction("Hit");
        PlayAudio.Play(PlayAudio.Cue.SurpriseEep, squirrel.transform.position);
        PlayLog.Logger?.NotifyNpcSurprise();
    }

    public override void UpdateState()
    {
        timer += Time.deltaTime;
        if (timer > 0.7f)
            PlayAudio.Play(PlayAudio.Cue.PlayfulGiggle, squirrel.transform.position);
        if (timer > 1.3f)
            squirrel.ChangeState(new IdleState(squirrel));
    }
}
