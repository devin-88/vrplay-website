using UnityEngine;

public class EndState : State
{
    public EndState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.End;

    public override void Enter()
    {
        squirrel.StopMoving();
        squirrel.PlayClimbAnimation(false);
        if (squirrel.HoldingApple)
            squirrel.DropApple();
        squirrel.PlayCelebration();
    }
}
