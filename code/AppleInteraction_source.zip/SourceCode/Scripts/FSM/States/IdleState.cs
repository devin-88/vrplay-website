using UnityEngine;

public class IdleState : State
{
    float thinkAt;
    float idleEnteredAt;
    float nextIdleSoundAt;
    Vector3 wanderTarget;
    bool hasWanderTarget;

    public IdleState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.Idle;

    public override void Enter()
    {
        idleEnteredAt = Time.time;
        thinkAt = Time.time + Random.Range(1f, 5f);
        ScheduleNextIdleSound();
        squirrel.PlayClimbAnimation(false);
        squirrel.SetRunning(false);
        PickWanderTarget();
    }

    public override void UpdateState()
    {
        if (squirrel.sensors.PlayerIsClimbing())
        {
            squirrel.ChangeState(new WatchingState(this.squirrel));
            return;
        }

        if (squirrel.sensors.AppleThrown())
        {
            squirrel.ChangeState(new ChaseAppleState(this.squirrel));
            return;
        }

        MaybePlayIdleSound();

        if (hasWanderTarget)
        {
            squirrel.MoveTo(wanderTarget, false);
            squirrel.Face(wanderTarget);
            if (squirrel.ReachedDestination(1.4f))
                hasWanderTarget = false;
        }
        else if (Time.time > thinkAt - 0.5f)
        {
            PickWanderTarget();
        }

        bool tutorialOffer = PlaySession.Instance != null &&
                             !PlaySession.Instance.TutorialOfferDone &&
                             Time.time - idleEnteredAt > 5f;

        if (tutorialOffer || Time.time >= thinkAt)
            DecideNext();
    }

    void MaybePlayIdleSound()
    {
        if (Time.time < nextIdleSoundAt)
            return;

        // Soft chance so it doesn't chatter constantly.
        if (Random.value < 0.55f)
        {
            PlayAudio.PlayRandom(
                squirrel.transform.position,
                PlayAudio.Cue.AmbientIdleChitter,
                PlayAudio.Cue.Mumble);
        }

        ScheduleNextIdleSound();
    }

    void ScheduleNextIdleSound()
    {
        nextIdleSoundAt = Time.time + Random.Range(4.5f, 10f);
    }

    void DecideNext()
    {
        thinkAt = Time.time + Random.Range(1f, 5f);

        if (squirrel.HoldingApple)
        {
            if (PlayWorld.Instance != null && PlayWorld.Instance.PlayerIsHoldingApple)
                squirrel.ChangeState(new WatchingState(squirrel));
            else
                squirrel.ChangeState(new HoldAppleState(squirrel));
            return;
        }

        bool wantsOffer = PlaySession.Instance != null && !PlaySession.Instance.TutorialOfferDone;
        if (wantsOffer || squirrel.sensors.PlayerNearbyFor(5f))
        {
            squirrel.ChangeState(new OfferAppleState(squirrel));
            return;
        }

        bool idleLong = Time.time - idleEnteredAt > 5f;
        bool climbRoll = Random.value < squirrel.memory.playfulness * 0.25f &&
                         squirrel.sensors.player != null &&
                         !squirrel.sensors.PlayerIsClimbing();

        if ((idleLong || climbRoll) && Random.value < 0.35f)
        {
            squirrel.ChangeState(new OnTreeState(squirrel));
            return;
        }

        if (squirrel.sensors.ObjectWithin(2f))
        {
            var apple = squirrel.sensors.NearestLooseApple(2f);
            if (apple != null)
            {
                squirrel.sensors.DetectApple(apple.transform);
                squirrel.ChangeState(new RetrieveAppleState(squirrel));
                return;
            }
        }

        if (Random.value < 0.22f)
            squirrel.PlayCelebration();

        PickWanderTarget();
    }

    void PickWanderTarget()
    {
        if (PlayWorld.Instance == null)
            return;
        wanderTarget = PlayWorld.Instance.RandomPointAroundTree(1.2f, Mathf.Min(8f, PlayWorld.Instance.meadowOuterRadius - 1f));
        hasWanderTarget = true;
    }
}
