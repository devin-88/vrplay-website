using UnityEngine;

public class WatchingState : State
{
    public WatchingState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.Watching;

    public override void Enter()
    {
        squirrel.StopMoving();
        squirrel.PlayClimbAnimation(false);
        squirrel.SetAnimBool("Waiting", true);
    }

    public override void UpdateState()
    {
        if (squirrel.sensors.player != null)
            squirrel.Face(squirrel.sensors.player.position + Vector3.up * (squirrel.sensors.PlayerIsClimbing() ? 2f : 0f));

        if (squirrel.sensors.AppleThrown())
        {
            squirrel.ChangeState(new ChaseAppleState(squirrel));
            return;
        }

        if (!squirrel.sensors.PlayerIsClimbing() &&
            (PlayWorld.Instance == null || !PlayWorld.Instance.PlayerIsHoldingApple))
        {
            if (squirrel.HoldingApple)
                squirrel.ChangeState(new HoldAppleState(squirrel));
            else
                squirrel.ChangeState(new IdleState(squirrel));
        }
    }
}
