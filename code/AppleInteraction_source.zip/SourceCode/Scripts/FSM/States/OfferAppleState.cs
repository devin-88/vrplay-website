using UnityEngine;

public class OfferAppleState : State
{
    float enteredAt;
    float waitStartedAt = -1f;
    bool placed;
    Vector3 standPoint;

    public OfferAppleState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.OfferingApple;

    public override void Enter()
    {
        placed = false;
        enteredAt = Time.time;
        waitStartedAt = -1f;
        squirrel.PlayAction("Offer");
        squirrel.SetRunning(false);

        if (PlaySession.Instance != null)
            PlaySession.Instance.TutorialOfferDone = true;

        if (!squirrel.HoldingApple)
            AcquireApple();

        if (PlayWorld.Instance != null && squirrel.sensors.player != null)
        {
            Vector3 away = squirrel.transform.position - squirrel.sensors.player.position;
            away.y = 0f;
            if (away.sqrMagnitude < 0.01f)
                away = -squirrel.sensors.player.forward;
            standPoint = squirrel.sensors.player.position + away.normalized * Random.Range(1.5f, 2f);
            if (UnityEngine.AI.NavMesh.SamplePosition(standPoint, out var hit, 3f, UnityEngine.AI.NavMesh.AllAreas))
                standPoint = hit.position;
            squirrel.MoveTo(standPoint, false);
        }
    }

    public override void UpdateState()
    {
        if (squirrel.sensors.AppleThrown())
        {
            squirrel.ChangeState(new ChaseAppleState(squirrel));
            return;
        }

        if (squirrel.sensors.PlayerIsClimbing())
        {
            squirrel.ChangeState(new WatchingState(squirrel));
            return;
        }

        if (!placed)
        {
            if (squirrel.sensors.player != null)
                squirrel.Face(squirrel.sensors.player.position);

            if (squirrel.ReachedDestination(1.3f) || Time.time - enteredAt > 6f)
            {
                if (squirrel.HoldingApple)
                    squirrel.PlaceAppleNearPlayer();
                placed = true;
                waitStartedAt = Time.time;
                squirrel.StopMoving();
                squirrel.SetAnimBool("Waiting", true);
                squirrel.PlayAction("Offer");
                PlayLog.Logger?.NotifyNpcOfferPlaced();
            }

            return;
        }

        if (squirrel.sensors.player != null)
            squirrel.Face(squirrel.sensors.player.position);

        if (PlayWorld.Instance != null && PlayWorld.Instance.PlayerIsHoldingApple)
        {
            squirrel.memory.IncreasePlay();
            squirrel.ChangeState(new WatchingState(squirrel));
            return;
        }

        if (Time.time - waitStartedAt > 10f)
        {
            squirrel.memory.Ignored();
            PlayAudio.Play(PlayAudio.Cue.DisappointedMurmur, squirrel.transform.position);
            squirrel.ChangeState(new IdleState(squirrel));
        }
    }

    void AcquireApple()
    {
        var nearby = squirrel.sensors.NearestLooseApple(12f);
        if (nearby != null)
        {
            squirrel.PickUpApple(nearby.transform, false);
            return;
        }

        if (AppleManager.Instance != null)
        {
            Vector3 spawnAt = squirrel.transform.position + squirrel.transform.forward * 0.6f + Vector3.up * 0.2f;
            var spawned = AppleManager.Instance.SpawnApple(spawnAt);
            if (spawned != null)
                squirrel.PickUpApple(spawned.transform, false);
        }
    }
}
