using UnityEngine;

public class ThrowAppleState : State
{
    float timer;
    float releaseAt;
    float exitAt;
    bool released;
    bool strong;
    Vector3 throwVelocity;

    public ThrowAppleState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.ThrowingApple;

    public override void Enter()
    {
        timer = 0f;
        released = false;
        squirrel.StopMoving();

        strong = squirrel.memory != null &&
                 (squirrel.memory.playfulness > 0.7f || squirrel.sensors.PlayerDistance > 4.2f);
        releaseAt = squirrel.GetThrowReleaseDelay(strong);
        exitAt = squirrel.GetThrowStateDuration(strong);

        squirrel.PlayThrowStyle(strong);
        throwVelocity = squirrel.ComputeOfferThrowVelocity();
        if (strong)
            throwVelocity *= 1.25f;

        if (squirrel.sensors.player != null)
            squirrel.Face(squirrel.sensors.player.position);
    }

    public override void UpdateState()
    {
        timer += Time.deltaTime;

        if (squirrel.sensors.player != null)
            squirrel.Face(squirrel.sensors.player.position);

        if (!released && timer >= releaseAt)
        {
            released = true;
            if (squirrel.HoldingApple)
                squirrel.ThrowApple(throwVelocity);
            squirrel.memory.IncreasePlay();
        }

        if (timer >= exitAt)
            squirrel.ChangeState(new IdleState(squirrel));
    }
}
