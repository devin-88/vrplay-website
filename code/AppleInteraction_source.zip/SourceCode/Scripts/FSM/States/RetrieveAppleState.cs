using UnityEngine;

public class RetrieveAppleState : State
{
    float timer;
    bool started;

    public RetrieveAppleState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.Retrieving;

    public override void Enter()
    {
        timer = 0f;
        started = false;
        squirrel.StopMoving();
    }

    public override void UpdateState()
    {
        timer += Time.deltaTime;

        Transform apple = squirrel.sensors != null ? squirrel.sensors.currentApple : null;
        if (apple != null)
        {
            float distance = Vector3.Distance(squirrel.transform.position, apple.position);
            if (distance > 1.8f)
            {
                squirrel.ChangeState(new ChaseAppleState(squirrel));
                return;
            }

            squirrel.Face(apple.position);
        }

        if (!started)
        {
            started = true;
            if (apple != null && squirrel.sensors.IsAppleAirborne(apple))
                squirrel.PlayCatchStyle(apple);
            else
                squirrel.PlayGroundPickup();
        }

        if (timer <= 0.55f)
            return;

        Transform pick = apple;
        if (pick == null && AppleManager.Instance != null)
        {
            var nearest = AppleManager.Instance.FindNearestLooseApple(squirrel.transform.position, 2.5f);
            if (nearest != null)
                pick = nearest.transform;
        }

        squirrel.PickUpApple(pick, false);
        squirrel.sensors.ClearApple();
        squirrel.memory.RecordCatch();

        if (squirrel.HoldingApple && Random.value < 0.45f)
            squirrel.PlayCelebration();

        if (PlaySession.Instance != null && PlaySession.Instance.ConsumeFirstThrowReturn())
        {
            squirrel.memory.IncreasePlay();
            squirrel.ChangeState(new OfferAppleState(squirrel));
            return;
        }

        squirrel.ChangeState(new HoldAppleState(squirrel));
    }
}
