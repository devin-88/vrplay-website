public enum SquirrelState
{
    Idle,
    OfferingApple,
    Watching,
    ChasingApple,
    Retrieving,
    HoldingApple,
    Evading,
    ThrowingApple,
    DroppingApple,
    Surprise,
    End
}