using UnityEngine;

public class DropAppleState : State
{
    float timer;

    public DropAppleState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.DroppingApple;

    public override void Enter()
    {
        timer = 0f;
        squirrel.StopMoving();
        squirrel.DropApple();
    }

    public override void UpdateState()
    {
        timer += Time.deltaTime;
        if (timer > 0.4f)
            squirrel.ChangeState(new IdleState(squirrel));
    }
}
