using UnityEngine;

public class EvadeState : State
{
    float endAt;
    Vector3 runTarget;

    public EvadeState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.Evading;

    public override void Enter()
    {
        endAt = Time.time + Random.Range(4f, 7f);
        squirrel.SetRunning(true);
        PlayAudio.PlayRandom(
            squirrel.transform.position,
            PlayAudio.Cue.PlayfulGiggle,
            PlayAudio.Cue.Laugh,
            PlayAudio.Cue.Laugh2);
        PickRunPoint();
    }

    public override void UpdateState()
    {
        if (squirrel.ReachedDestination(1.3f))
            PickRunPoint();

        if (Time.time >= endAt)
        {
            squirrel.ChangeState(new IdleState(squirrel));
        }
    }

    public override void Exit()
    {
        squirrel.SetRunning(false);
    }

    void PickRunPoint()
    {
        if (PlayWorld.Instance == null)
            return;

        Vector3 fromPlayer = squirrel.transform.position;
        if (squirrel.sensors.player != null)
        {
            Vector3 away = squirrel.transform.position - squirrel.sensors.player.position;
            away.y = 0f;
            if (away.sqrMagnitude < 0.01f)
                away = squirrel.transform.right;
            fromPlayer = squirrel.transform.position + away.normalized * 4f;
        }

        float outer = PlayWorld.Instance.meadowOuterRadius;
        Vector3 aroundTree = PlayWorld.Instance.RandomPointAroundTree(3f, Mathf.Min(12f, outer - 1f));
        runTarget = Vector3.Lerp(aroundTree, fromPlayer, 0.35f);
        if (UnityEngine.AI.NavMesh.SamplePosition(runTarget, out var hit, 4f, UnityEngine.AI.NavMesh.AllAreas))
            runTarget = hit.position;
        squirrel.MoveTo(runTarget, true);
    }
}
