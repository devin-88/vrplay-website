using UnityEngine;

public class ChaseAppleState : State
{
    Transform apple;

    public ChaseAppleState(SquirrelFSM squirrel) : base(squirrel)
    {
    }

    public override SquirrelState Id => SquirrelState.ChasingApple;

    public override void Enter()
    {
        apple = squirrel.sensors.currentApple;
        squirrel.SetRunning(true);
        PlayAudio.Play(PlayAudio.Cue.ExcitedChitter, squirrel.transform.position);
    }

    public override void UpdateState()
    {
        if (apple == null && squirrel.sensors != null)
            apple = squirrel.sensors.currentApple;

        if (apple == null)
        {
            squirrel.ChangeState(new IdleState(squirrel));
            return;
        }

        var item = apple.GetComponent<AppleItem>();
        if (item != null && (item.IsHeldByNpc || item.IsHeldByPlayer))
        {
            squirrel.sensors.ClearApple();
            squirrel.ChangeState(new IdleState(squirrel));
            return;
        }

        squirrel.MoveTo(apple.position, true);

        float distance = Vector3.Distance(squirrel.transform.position, apple.position);
        if (distance < 1.6f)
            squirrel.ChangeState(new RetrieveAppleState(squirrel));
    }

    public override void Exit()
    {
        squirrel.SetRunning(false);
        if (squirrel.agent != null && squirrel.agent.enabled && squirrel.agent.isOnNavMesh)
            squirrel.agent.ResetPath();
    }
}
