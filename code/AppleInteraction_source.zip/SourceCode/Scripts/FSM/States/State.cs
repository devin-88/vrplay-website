public abstract class State
{
    protected SquirrelFSM squirrel;

    protected State(SquirrelFSM squirrel)
    {
        this.squirrel = squirrel;
    }

    public virtual SquirrelState Id => SquirrelState.Idle;

    public virtual void Enter()
    {
    }

    public virtual void UpdateState()
    {
    }

    public virtual void Exit()
    {
    }
}
