using UnityEngine;
using UnityEngine.AI;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

[DefaultExecutionOrder(10)]
public class SquirrelFSM : MonoBehaviour
{
    public State currentState;
    public SquirrelState currentStateId = SquirrelState.Idle;

    public SquirrelMemory memory;
    public SquirrelSensors sensors;
    public Animator animator;
    public NavMeshAgent agent;

    public Transform appleHoldPoint;
    public Transform heldApple;

    public Transform treeBase;
    public float walkSpeed = 1.6f;
    public float runSpeed = 3.2f;
    public float appleHoldPadding = 0.04f;

    public bool HoldingApple => heldApple != null;
    public bool IsOnTree { get; set; }
    public bool IsClimbingTree { get; set; }

    State previousState;
    float chitterTimer;
    Transform chestHoldAnchor;
    Renderer bodyRenderer;
    float lastMovingAt;
    float prevAnimSpeed;
    float nextFidgetAt;

    void Start()
    {
        if (memory == null)
            memory = GetComponent<SquirrelMemory>();
        if (sensors == null)
            sensors = GetComponent<SquirrelSensors>();
        if (animator == null)
            animator = GetComponent<Animator>();
        if (animator != null)
        {
            animator.applyRootMotion = false;
            animator.cullingMode = AnimatorCullingMode.AlwaysAnimate;
        }
        if (agent == null)
            agent = GetComponent<NavMeshAgent>();
        if (treeBase == null && PlayWorld.Instance != null)
            treeBase = PlayWorld.Instance.clearingCenter;

        ApplyMovementSpeed(false);
        EnsureHitTrigger();
        EnsureAppleHoldInFront();
        if (GetComponent<SquirrelExpression>() == null)
            gameObject.AddComponent<SquirrelExpression>();
        MakeAgentAuthoritative();
        if (agent != null)
        {
            agent.radius = Mathf.Max(agent.radius, 0.35f);
            agent.obstacleAvoidanceType = ObstacleAvoidanceType.HighQualityObstacleAvoidance;
        }
        EnsureOnNavMesh();
        EnsureModelFacingOffset();
        FaceTreeIfNearby();
        ChangeState(new IdleState(this));
    }

    /// <summary>
    /// Bind pose faces -X while the GameObject forward is +Z. Rotate the armature
    /// so walking/LookRotation match the visible face.
    /// </summary>
    void EnsureModelFacingOffset()
    {
        var armature = transform.Find("Armature");
        if (armature == null)
            return;

        Vector3 euler = armature.localEulerAngles;
        // Already corrected in the Final scene (≈90). Don't fight custom authoring.
        float y = euler.y;
        if (y > 180f)
            y -= 360f;
        if (Mathf.Abs(y) < 5f || Mathf.Abs(Mathf.Abs(y) - 180f) < 5f)
            armature.localEulerAngles = new Vector3(euler.x, 90f, euler.z);
    }

    void FaceTreeIfNearby()
    {
        Vector3 treePos;
        if (treeBase != null)
            treePos = treeBase.position;
        else if (PlayWorld.Instance != null && PlayWorld.Instance.clearingCenter != null)
            treePos = PlayWorld.Instance.clearingCenter.position;
        else
        {
            var tree = GameObject.Find("Tree");
            if (tree == null)
                return;
            treePos = tree.transform.position;
        }

        Vector3 flat = treePos - transform.position;
        flat.y = 0f;
        if (flat.sqrMagnitude < 0.25f || flat.sqrMagnitude > 400f)
            return;
        // Snap at spawn when facing away from the tree.
        if (Vector3.Dot(transform.forward, flat.normalized) > 0.15f)
            return;
        FaceImmediate(treePos);
    }

    void Update()
    {
        UpdateAnimatorSpeed();

        TickAmbientAudio();

        if (TryHandleInterrupts())
            return;

        TryProximityTransfer();
        currentState?.UpdateState();
        KeepOutsideTrunk();
        KeepInsideClearing();
    }

    void LateUpdate()
    {
        KeepAppleInFront();
        KeepOutsideTrunk();
        KeepInsideClearing();
        // After the climb clip writes Armature, reassert facing into the bark.
        if (IsClimbingTree)
            FaceClimbIntoBark();
    }

    void FaceClimbIntoBark()
    {
        if (TrunkClimbPath.Instance == null)
            return;
        if (!TrunkClimbPath.Instance.TryGetClosestCenterline(transform.position, out _, out Vector3 outward))
            return;

        outward.y = 0f;
        if (outward.sqrMagnitude < 0.001f)
            return;
        // Outward transform facing + climb armature = visible nose into the trunk.
        transform.rotation = Quaternion.LookRotation(outward.normalized);
    }

    void KeepInsideClearing()
    {
        if (IsOnTree || IsClimbingTree || PlayWorld.Instance == null)
            return;

        Vector3 clamped = ClampToClearing(transform.position);
        Vector3 delta = clamped - transform.position;
        delta.y = 0f;
        if (delta.sqrMagnitude < 0.0001f)
            return;

        if (agent != null && agent.enabled && agent.isOnNavMesh)
            agent.Warp(clamped);
        else
            transform.position = clamped;
    }

    void KeepOutsideTrunk()
    {
        if (IsOnTree || TrunkClimbPath.Instance == null)
            return;

        float bodyRadius = agent != null ? agent.radius : 0.35f;
        TrunkClimbPath.Instance.TryKeepOutside(transform, bodyRadius, false);
    }

    void OnCollisionEnter(Collision collision)
    {
        TryRegisterIncomingApple(collision.collider);
    }

    void OnTriggerEnter(Collider other)
    {
        TryRegisterIncomingApple(other);
    }

    void TryRegisterIncomingApple(Collider other)
    {
        var apple = other.GetComponentInParent<AppleItem>();
        if (apple == null || apple.IsHeldByNpc || apple.IsHeldByPlayer)
            return;

        if (apple.Body != null && apple.Body.linearVelocity.magnitude > 0.5f)
            sensors.NotifyAppleCollision(apple);
    }

    void EnsureHitTrigger()
    {
        Transform existing = transform.Find("AppleHitTrigger");
        GameObject go = existing != null ? existing.gameObject : new GameObject("AppleHitTrigger");
        if (existing == null)
            go.transform.SetParent(transform, false);

        var sphere = go.GetComponent<SphereCollider>();
        if (sphere == null)
            sphere = go.AddComponent<SphereCollider>();
        sphere.isTrigger = true;
        sphere.radius = 1.3f;
        sphere.center = Vector3.up * 0.6f;

        var volume = go.GetComponent<SquirrelHitVolume>();
        if (volume == null)
            volume = go.AddComponent<SquirrelHitVolume>();
        volume.squirrel = this;
    }

    bool CanReactToIncoming()
    {
        if (currentState is ThrownAtReactState || currentState is EndState)
            return false;
        if (IsClimbingTree)
            return false;
        return true;
    }

    bool TryHandleInterrupts()
    {
        if (currentState is EndState)
            return false;

        if (PlaySession.Instance != null && PlaySession.Instance.HasEnded)
        {
            ChangeState(new EndState(this));
            return true;
        }

        if (sensors != null && sensors.appleThrownAtNpc && CanReactToIncoming())
        {
            var reaction = SquirrelDecisions.ChooseThrownAtReaction(memory, sensors, HoldingApple);
            ChangeState(new ThrownAtReactState(this, reaction));
            return true;
        }

        if (currentState is IdleState || currentState is OfferAppleState || currentState is WatchingState)
        {
            if (sensors != null && sensors.PlayerDisengaged(10f) && !(currentState is IdleState))
            {
                memory.Ignored();
                ChangeState(new IdleState(this));
                return true;
            }

            if (sensors != null && sensors.PlayerIdleFor(15f) && !(currentState is IdleState) && !(currentState is OfferAppleState))
            {
                ChangeState(new IdleState(this));
                return true;
            }
        }

        return false;
    }

    void TryProximityTransfer()
    {
        if (HoldingApple)
            return;
        if (!(currentState is IdleState) && !(currentState is OfferAppleState))
            return;
        if (PlayWorld.Instance == null || !PlayWorld.Instance.TryGetHeldApple(out var apple))
            return;
        if (Vector3.Distance(transform.position, apple.transform.position) > 0.3f)
            return;

        var grab = apple.Grab;
        if (grab != null && grab.isSelected && grab.interactorsSelecting.Count > 0)
            grab.interactionManager.SelectExit(grab.interactorsSelecting[0], grab);

        sensors.currentApple = apple.transform;
        PickUpApple(apple.transform);
        PlayAudio.Play(PlayAudio.Cue.AppleTransfer, transform.position);
        PlayAudio.Play(PlayAudio.Cue.HappyChirp, transform.position);
        PlayWorld.Instance.PulseHaptics(0.55f, 0.1f);
        memory.IncreasePlay();
        PlayLog.Logger?.NotifyTransferToNpc();
        ChangeState(new HoldAppleState(this));
    }

    public void ChangeState(State newState)
    {
        if (currentState != null)
            currentState.Exit();

        string fromLabel = PlayLog.StateLabel(this);
        previousState = currentState;
        currentState = newState;

        if (currentState != null)
        {
            currentStateId = currentState.Id;
            currentState.Enter();
            string toLabel = PlayLog.StateLabel(this);
            PlayLog.Logger?.NotifyNpcStateEnter(fromLabel, toLabel);
            Debug.Log("Squirrel State: " + currentState.GetType().Name);
        }
    }

    public void RestorePreviousOrIdle()
    {
        if (previousState is ThrownAtReactState || previousState == null)
        {
            ChangeState(new IdleState(this));
            return;
        }

        ChangeState(previousState);
    }

    public void ReactToSurprise()
    {
        if (currentState is EndState || currentState is SurpriseState)
            return;
        ChangeState(new SurpriseState(this));
    }

    public void ApplyMovementSpeed(bool running)
    {
        if (agent == null || memory == null)
            return;

        float tiredFactor = 1f - memory.tiredness * 0.35f;
        float playfulFactor = 0.85f + memory.playfulness * 0.3f;
        agent.speed = (running ? runSpeed : walkSpeed) * tiredFactor * playfulFactor;
    }

    public void SetRunning(bool running)
    {
        ApplyMovementSpeed(running);
    }

    public void PlayAction(string trigger)
    {
        if (animator == null)
            return;

        ResetActionTriggers();
        if (!HasAnimatorParameter(trigger))
            return;
        animator.SetTrigger(trigger);
    }

    public void TriggerAnim(string parameter)
    {
        PlayAction(parameter);
    }

    void ResetActionTriggers()
    {
        if (animator == null)
            return;
        string[] triggers =
        {
            "Catch", "SideCatch", "FarCatch", "Header", "Pickup",
            "Throw", "Throwing", "StrongThrow", "StopCarry",
            "Offer", "Cheer", "Jump", "Hit", "HitSide"
        };
        for (int i = 0; i < triggers.Length; i++)
        {
            if (HasAnimatorParameter(triggers[i]))
                animator.ResetTrigger(triggers[i]);
        }
    }

    public void PlayCatchStyle(Transform apple)
    {
        if (apple == null)
        {
            PlayAction("Catch");
            return;
        }

        Vector3 local = transform.InverseTransformPoint(apple.position);
        if (local.y > 1.1f)
            PlayAction("Header");
        else if (local.magnitude > 1.7f || local.z > 1.35f)
            PlayAction("FarCatch");
        else if (Mathf.Abs(local.x) > 0.5f)
            PlayAction("SideCatch");
        else
            PlayAction("Catch");
    }

    [Header("Throw Timing")]
    [Tooltip("Seconds after a normal Throw anim starts before the apple leaves the hand.")]
    public float throwReleaseDelay = 0.55f;
    [Tooltip("Seconds after a Strong Throw anim starts before the apple leaves the hand.")]
    public float strongThrowReleaseDelay = 1.15f;
    [Tooltip("How long the squirrel stays in the throw state (anim + recovery).")]
    public float throwStateDuration = 1.2f;
    public float strongThrowStateDuration = 2.0f;

    public void PlayThrowStyle(bool strong)
    {
        if (strong)
            PlayAction("StrongThrow");
        else
            PlayAction("Throw");
    }

    /// <summary>Seconds after throw anim starts before the apple leaves the hand.</summary>
    public float GetThrowReleaseDelay(bool strong)
    {
        return strong ? strongThrowReleaseDelay : throwReleaseDelay;
    }

    /// <summary>Total time to stay in throw pose after starting the anim.</summary>
    public float GetThrowStateDuration(bool strong)
    {
        return strong ? strongThrowStateDuration : throwStateDuration;
    }

    public void PlayHitStyle(Vector3 fromPoint)
    {
        Vector3 local = transform.InverseTransformPoint(fromPoint);
        PlayAction(Mathf.Abs(local.x) > Mathf.Abs(local.z) ? "HitSide" : "Hit");
    }

    public void PlayCelebration()
    {
        PlayAction(Random.value < 0.5f ? "Cheer" : "Jump");
    }

    public void PlayGroundPickup()
    {
        PlayAction("Pickup");
    }

    void UpdateAnimatorSpeed()
    {
        if (animator == null)
            return;

        float speed = 0f;
        if (!IsClimbingTree && agent != null && agent.enabled && agent.isOnNavMesh)
            speed = agent.velocity.magnitude;
        animator.SetFloat("Speed", speed, 0.12f, Time.deltaTime);

        if (speed > 0.22f)
            lastMovingAt = Time.time;

        if (HoldingApple && prevAnimSpeed > 1.35f && speed < 0.28f && HasAnimatorParameter("StopCarry"))
            animator.SetTrigger("StopCarry");
        prevAnimSpeed = speed;

        SetAnimBool("Tired", memory != null && memory.tiredness > 0.5f);

        bool canWait = !IsClimbingTree && speed < 0.18f && Time.time - lastMovingAt > 1.15f &&
                       (currentState is IdleState || currentState is OfferAppleState ||
                        currentState is WatchingState || currentState is HoldAppleState);
        SetAnimBool("Waiting", canWait);

        if (Time.time >= nextFidgetAt)
        {
            nextFidgetAt = Time.time + Random.Range(2.5f, 5.5f);
            if (HasAnimatorParameter("Fidget"))
                animator.SetFloat("Fidget", Random.value);
        }
    }

    public void SetAnimBool(string parameter, bool value)
    {
        if (animator == null || !HasAnimatorParameter(parameter))
            return;
        animator.SetBool(parameter, value);
    }

    bool HasAnimatorParameter(string parameter)
    {
        if (animator == null)
            return false;
        foreach (var p in animator.parameters)
        {
            if (p.name == parameter)
                return true;
        }
        return false;
    }

    public void Face(Vector3 worldPoint)
    {
        Vector3 flat = worldPoint - transform.position;
        flat.y = 0f;
        if (flat.sqrMagnitude < 0.001f)
            return;
        float turnSpeed = IsClimbingTree ? 14f : 6f;
        transform.rotation = Quaternion.Slerp(
            transform.rotation,
            Quaternion.LookRotation(flat),
            Time.deltaTime * turnSpeed);
    }

    public void FaceImmediate(Vector3 worldPoint)
    {
        Vector3 flat = worldPoint - transform.position;
        flat.y = 0f;
        if (flat.sqrMagnitude < 0.001f)
            return;
        transform.rotation = Quaternion.LookRotation(flat);
    }

    public void MoveTo(Vector3 destination, bool running = false)
    {
        if (!EnsureOnNavMesh())
            return;
        destination = ClampToClearing(destination);
        SetRunning(running);
        agent.isStopped = false;
        if (UnityEngine.AI.NavMesh.SamplePosition(destination, out var hit, 4f, UnityEngine.AI.NavMesh.AllAreas))
            destination = hit.position;
        agent.SetDestination(destination);
    }

    public Vector3 ClampToClearing(Vector3 worldPoint)
    {
        if (PlayWorld.Instance == null)
            return worldPoint;

        Vector3 center = PlayWorld.Instance.Center;
        float max = PlayWorld.Instance.meadowOuterRadius;
        Vector3 flat = worldPoint - center;
        flat.y = 0f;
        if (flat.magnitude <= max)
            return worldPoint;

        Vector3 clamped = center + flat.normalized * max;
        clamped.y = worldPoint.y;
        return clamped;
    }

    public bool EnsureOnNavMesh()
    {
        if (agent == null || !agent.enabled)
            return false;
        if (agent.isOnNavMesh)
            return true;
        if (UnityEngine.AI.NavMesh.SamplePosition(transform.position, out var hit, 5f, UnityEngine.AI.NavMesh.AllAreas))
        {
            agent.Warp(hit.position);
            return agent.isOnNavMesh;
        }
        return false;
    }

    public void StopMoving()
    {
        if (agent != null && agent.isOnNavMesh)
        {
            agent.ResetPath();
            agent.isStopped = true;
        }
        SetRunning(false);
    }

    public bool ReachedDestination(float threshold = 1.2f)
    {
        if (agent == null || !agent.isOnNavMesh)
            return true;
        if (agent.pathPending)
            return false;
        return agent.remainingDistance <= Mathf.Max(threshold, agent.stoppingDistance);
    }

    public void PickUpApple()
    {
        Transform apple = sensors != null ? sensors.currentApple : null;
        if (apple == null && AppleManager.Instance != null)
        {
            var nearest = AppleManager.Instance.FindNearestLooseApple(transform.position, 2.5f);
            if (nearest != null)
                apple = nearest.transform;
        }

        PickUpApple(apple, true);
    }

    public void PickUpApple(Transform apple)
    {
        PickUpApple(apple, true);
    }

    public void PickUpApple(Transform apple, bool playCatch)
    {
        if (apple == null || HoldingApple)
            return;

        EnsureAppleHoldInFront();

        var item = apple.GetComponent<AppleItem>();
        if (item != null)
            item.PrepareForNpcCarry();
        else
            FreezeLooseObject(apple);

        ParentToHoldPoint(apple, appleHoldPoint);
        heldApple = apple;
        SetAnimBool("HoldingApple", true);
        if (playCatch)
            PlayAction("Catch");
        PlayAudio.Play(PlayAudio.Cue.HappyChirp, transform.position);
        PlayLog.Logger?.NotifyNpcPickup(playCatch);
        if (currentState is RetrieveAppleState || currentState is ChaseAppleState || currentState is ThrownAtReactState)
            PlayLog.Logger?.NotifyNpcRetrieve();
        Debug.Log("Squirrel picked up apple");
    }

    public void DropApple()
    {
        if (!HoldingApple)
            return;

        Transform apple = heldApple;
        Vector3 desired = transform.position + transform.forward * 0.55f + Vector3.up * 0.4f;
        ReleaseAppleInternal(apple, desired, Vector3.zero, snapToGround: true);
    }

    public void ReleaseApple()
    {
        DropApple();
    }

    public void ThrowApple(Vector3 velocity)
    {
        if (!HoldingApple)
            return;

        Transform apple = heldApple;
        Vector3 releasePos = transform.position + transform.forward * 0.7f + Vector3.up * 1.15f;
        ReleaseAppleInternal(apple, releasePos, velocity, snapToGround: false);
        PlayAudio.Play(PlayAudio.Cue.AppleWhoosh, releasePos);
        PlayLog.Logger?.NotifyNpcThrow(velocity);
        Debug.Log("Squirrel threw apple");
    }

    public Vector3 ComputeOfferThrowVelocity()
    {
        Vector3 target;
        if (sensors != null && sensors.player != null && sensors.PlayerDistance < 5f)
            target = sensors.player.position + Vector3.up * 0.8f;
        else
            target = transform.position + transform.forward * 4f + Vector3.up * 1.2f;

        Vector3 toTarget = target - (transform.position + Vector3.up * 1.1f);
        float distance = toTarget.magnitude;
        Vector3 direction = distance > 0.01f ? toTarget.normalized : transform.forward;
        float speed = Mathf.Clamp(distance * 0.9f, 3.5f, 6.5f);
        return direction * speed + Vector3.up * 1.4f;
    }

    public void PlaceAppleNearPlayer()
    {
        if (!HoldingApple || PlayWorld.Instance == null)
        {
            DropApple();
            return;
        }

        Vector3 point = PlayWorld.Instance.GroundPointNearPlayer(0.85f);
        Transform apple = heldApple;
        ReleaseAppleInternal(apple, point, Vector3.zero, snapToGround: true);
    }

    void ReleaseAppleInternal(Transform apple, Vector3 worldPosition, Vector3 velocity, bool snapToGround)
    {
        var item = apple.GetComponent<AppleItem>();
        float radius = item != null ? item.WorldRadius : 0.2f;

        Vector3 worldScale = apple.lossyScale;
        apple.SetParent(null, true);
        apple.localScale = worldScale;

        Vector3 spawnPos = worldPosition;
        if (snapToGround)
        {
            Vector3 ground = PlayWorld.Instance != null
                ? PlayWorld.Instance.SnapToGround(worldPosition, 0.02f)
                : worldPosition;
            spawnPos = ground + Vector3.up * (radius + 0.06f);
        }

        apple.position = spawnPos;
        Physics.SyncTransforms();

        if (item != null)
            item.RestoreAsLoose();
        else
            RestoreLooseObject(apple);

        var rb = apple.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.position = spawnPos;
            rb.linearVelocity = velocity;
            rb.angularVelocity = Vector3.zero;
        }

        heldApple = null;
        SetAnimBool("HoldingApple", false);
    }

    void ParentToHoldPoint(Transform item, Transform holdPoint)
    {
        if (holdPoint == null)
            holdPoint = transform;

        Vector3 worldScale = item.lossyScale;
        item.SetParent(holdPoint, false);
        item.localPosition = Vector3.zero;
        item.localRotation = Quaternion.identity;
        Vector3 parentScale = holdPoint.lossyScale;
        item.localScale = new Vector3(
            SafeDivide(worldScale.x, parentScale.x),
            SafeDivide(worldScale.y, parentScale.y),
            SafeDivide(worldScale.z, parentScale.z));
        Physics.SyncTransforms();
    }

    static float SafeDivide(float value, float divisor)
    {
        return Mathf.Abs(divisor) < 0.0001f ? value : value / divisor;
    }

    public void SetAgentEnabled(bool enabled)
    {
        if (agent == null)
            return;

        if (!enabled)
        {
            if (agent.isOnNavMesh)
                agent.ResetPath();
            agent.updatePosition = false;
            agent.updateRotation = false;
            agent.enabled = false;
        }
        else
        {
            agent.enabled = true;
            agent.updatePosition = true;
            agent.updateRotation = true;
        }
    }

    public void SetPhysicsDriven(bool physicsDriven)
    {
        var rb = GetComponent<Rigidbody>();
        if (rb == null)
            return;

        rb.useGravity = physicsDriven;
        rb.isKinematic = !physicsDriven;
        if (!physicsDriven)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }
    }

    public void WarpTo(Vector3 position)
    {
        transform.position = position;
        if (agent != null && agent.enabled && agent.isOnNavMesh)
            agent.Warp(position);
    }

    public void PlayClimbAnimation(bool climbing)
    {
        SetAnimBool("Climbing", climbing);
        if (!climbing)
            ResetActionTriggers();
    }

    void MakeAgentAuthoritative()
    {
        SetPhysicsDriven(false);
        var rb = GetComponent<Rigidbody>();
        if (rb != null)
            rb.constraints = RigidbodyConstraints.FreezeRotation;
    }

    void EnsureAppleHoldInFront()
    {
        Transform hand = FindPreferredHand();
        if (appleHoldPoint == null)
        {
            Transform existing = FindChildByName(transform, "AppleHoldPoint");
            appleHoldPoint = existing != null ? existing : new GameObject("AppleHoldPoint").transform;
        }

        Transform parent = hand != null ? hand : transform;
        appleHoldPoint.SetParent(parent, false);
        appleHoldPoint.localScale = Vector3.one;
        appleHoldPoint.localRotation = Quaternion.identity;
        appleHoldPoint.localPosition = PalmLocalOffset(parent);
        appleHoldPoint.name = "AppleHoldPoint";

        var follow = appleHoldPoint.GetComponent<HandFollow>();
        if (follow != null)
            follow.enabled = false;
    }

    void KeepAppleInFront()
    {
        if (appleHoldPoint == null)
            EnsureAppleHoldInFront();
        if (appleHoldPoint == null)
            return;

        Transform hand = FindPreferredHand();
        Transform parent = hand != null ? hand : transform;
        if (appleHoldPoint.parent != parent)
            appleHoldPoint.SetParent(parent, false);

        appleHoldPoint.localScale = Vector3.one;
        appleHoldPoint.localRotation = Quaternion.identity;
        appleHoldPoint.localPosition = PalmLocalOffset(parent);

        if (!HoldingApple || heldApple == null)
            return;

        if (heldApple.parent != appleHoldPoint)
            ParentToHoldPoint(heldApple, appleHoldPoint);
        else
        {
            heldApple.localPosition = Vector3.zero;
            heldApple.localRotation = Quaternion.identity;
        }
    }

    /// <summary>
    /// Convert a few centimetres of palm offset into bone-local space.
    /// Squirrel hand bones are heavily scaled (~20), so raw local values fly away.
    /// </summary>
    static Vector3 PalmLocalOffset(Transform hand)
    {
        if (hand == null)
            return new Vector3(0f, 0.05f, 0.08f);

        float scale = Mathf.Max(0.001f, hand.lossyScale.x);
        // ~2.5 cm along palm, slight inward.
        float cm = 0.025f / scale;
        return new Vector3(0f, cm * 0.35f, cm);
    }

    Transform FindPreferredHand()
    {
        Transform tip = FindChildByName(transform, "Hand_R_end");
        if (tip != null)
            return tip;
        Transform right = FindChildByName(transform, "Hand_R");
        if (right != null)
            return right;
        tip = FindChildByName(transform, "Hand_L_end");
        if (tip != null)
            return tip;
        return FindChildByName(transform, "Hand_L");
    }

    static Transform FindChildByName(Transform root, string name)
    {
        var all = root.GetComponentsInChildren<Transform>(true);
        for (int i = 0; i < all.Length; i++)
        {
            if (all[i].name == name)
                return all[i];
        }
        return null;
    }

    void FreezeLooseObject(Transform item)
    {
        var rb = item.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
            rb.useGravity = false;
            rb.isKinematic = true;
        }

        var grab = item.GetComponent<XRGrabInteractable>();
        if (grab != null)
            grab.enabled = false;

        var col = item.GetComponent<Collider>();
        if (col != null)
            col.enabled = false;
    }

    void RestoreLooseObject(Transform item)
    {
        var rb = item.GetComponent<Rigidbody>();
        if (rb != null)
        {
            rb.isKinematic = false;
            rb.useGravity = true;
            rb.linearVelocity = Vector3.zero;
            rb.angularVelocity = Vector3.zero;
        }

        var col = item.GetComponent<Collider>();
        if (col != null)
            col.enabled = true;

        var grab = item.GetComponent<XRGrabInteractable>();
        if (grab != null)
            grab.enabled = true;
    }

    void TickAmbientAudio()
    {
        if (!(currentState is IdleState))
            return;

        chitterTimer -= Time.deltaTime;
        if (chitterTimer <= 0f)
        {
            PlayAudio.Play(PlayAudio.Cue.AmbientIdleChitter, transform.position);
            chitterTimer = Random.Range(4f, 9f);
        }
    }
}
