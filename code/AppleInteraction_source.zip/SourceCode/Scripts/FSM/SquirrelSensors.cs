using UnityEngine;
using UnityEngine.AI;

[DefaultExecutionOrder(-50)]
public class SquirrelSensors : MonoBehaviour
{
    public Transform player;
    public Transform currentApple;
    public float nearbyDistance = 5f;
    public float incomingAppleRadius = 2.6f;
    public float incomingWindow = 1.7f;

    public AppleItem incomingApple { get; private set; }
    public Vector3 incomingVelocity { get; private set; }
    public bool appleThrownAtNpc { get; private set; }
    public Vector3 interceptPoint { get; private set; }
    public float incomingEta { get; private set; }
    public bool incomingIsHigh { get; private set; }
    public bool incomingFromSide { get; private set; }

    float playerNearbySince = -1f;
    float playerFarSince = -1f;
    float playerIdleSince = -1f;
    float lastPlayerDistance = 999f;
    float ignoreIncomingUntil;
    float heardThrowAt = -999f;

    public float PlayerDistance
    {
        get
        {
            if (player == null)
                return float.MaxValue;
            return Vector3.Distance(transform.position, player.position);
        }
    }

    public bool PlayerApproaching
    {
        get
        {
            if (player == null)
                return false;
            float distance = PlayerDistance;
            bool approaching = distance < lastPlayerDistance - 0.05f;
            lastPlayerDistance = distance;
            return approaching && distance < 6f;
        }
    }

    void Start()
    {
        if (player == null && PlayWorld.Instance != null)
            player = PlayWorld.Instance.player;
        if (player == null && Camera.main != null)
            player = Camera.main.transform;
        currentApple = null;
        appleThrownAtNpc = false;
        incomingApple = null;
        ignoreIncomingUntil = Time.time + 2f;
    }

    void Update()
    {
        TickPlayer();
        TickIncomingApples();
    }

    void TickPlayer()
    {
        if (player == null)
            return;

        float distance = PlayerDistance;
        if (distance < nearbyDistance)
        {
            if (playerNearbySince < 0f)
                playerNearbySince = Time.time;
            playerFarSince = -1f;
        }
        else
        {
            playerNearbySince = -1f;
        }

        if (distance > 10f)
        {
            if (playerFarSince < 0f)
                playerFarSince = Time.time;
        }
        else
        {
            playerFarSince = -1f;
        }

        bool idle = PlayWorld.Instance == null || PlayWorld.Instance.PlayerIsIdle;
        if (idle)
        {
            if (playerIdleSince < 0f)
                playerIdleSince = Time.time;
        }
        else
        {
            playerIdleSince = -1f;
        }
    }

    void TickIncomingApples()
    {
        if (Time.time < ignoreIncomingUntil)
            return;
        if (AppleManager.Instance == null)
            return;

        Vector3 chest = transform.position + Vector3.up * 0.65f;
        var apples = AppleManager.Instance.AllApples();
        AppleItem bestAimed = null;
        float bestScore = float.MaxValue;
        AppleItem bestFlying = null;
        float bestFlyDist = float.MaxValue;

        for (int i = 0; i < apples.Count; i++)
        {
            var apple = apples[i];
            if (apple == null || !apple.IsLoose)
                continue;

            Vector3 velocity = apple.Body != null ? apple.Body.linearVelocity : Vector3.zero;
            float horizontal = Vector3.ProjectOnPlane(velocity, Vector3.up).magnitude;
            if (horizontal < 1.6f)
                continue;

            float dist = Vector3.Distance(chest, apple.transform.position);
            if (dist < bestFlyDist)
            {
                bestFlyDist = dist;
                bestFlying = apple;
            }

            PredictApproach(apple.transform.position, velocity, chest, out float closest, out float eta, out Vector3 closestPoint);
            if (closest > incomingAppleRadius || eta < 0f || eta > incomingWindow)
                continue;

            float score = closest + eta * 0.4f;
            if (score < bestScore)
            {
                bestScore = score;
                bestAimed = apple;
                incomingEta = eta;
                interceptPoint = FlattenToNav(closestPoint);
                incomingVelocity = velocity;
                incomingIsHigh = apple.transform.position.y > transform.position.y + 1.05f || closestPoint.y > transform.position.y + 1.2f;
                Vector3 toApple = apple.transform.position - transform.position;
                incomingFromSide = Mathf.Abs(Vector3.Dot(transform.right, toApple.normalized)) > 0.55f;
            }
        }

        if (bestAimed != null)
        {
            incomingApple = bestAimed;
            currentApple = bestAimed.transform;
            appleThrownAtNpc = true;
            heardThrowAt = Time.time;
            return;
        }

        if (bestFlying != null && currentApple == null)
        {
            currentApple = bestFlying.transform;
            heardThrowAt = Time.time;
        }
    }

    public bool PlayerNearby()
    {
        return PlayerDistance < nearbyDistance;
    }

    public bool PlayerDisengaged(float seconds = 10f)
    {
        return playerFarSince >= 0f && Time.time - playerFarSince > seconds;
    }

    public bool PlayerIdleFor(float seconds)
    {
        return playerIdleSince >= 0f && Time.time - playerIdleSince > seconds;
    }

    public bool PlayerNearbyFor(float seconds)
    {
        return playerNearbySince >= 0f && Time.time - playerNearbySince > seconds;
    }

    public bool AppleThrown()
    {
        return currentApple != null && Time.time - heardThrowAt < 12f;
    }

    public bool PlayerIsClimbing()
    {
        return PlayWorld.Instance != null && PlayWorld.Instance.PlayerIsClimbing;
    }

    public void DetectApple(Transform apple)
    {
        currentApple = apple;
        heardThrowAt = Time.time;
        Debug.Log("Squirrel detected apple: " + apple.name);
    }

    public void ClearApple()
    {
        currentApple = null;
        heardThrowAt = -999f;
    }

    public void NotifyThrownApple(Transform apple, Vector3 velocity)
    {
        if (apple == null)
            return;

        currentApple = apple;
        heardThrowAt = Time.time;
        incomingVelocity = velocity;

        Vector3 chest = transform.position + Vector3.up * 0.65f;
        PredictApproach(apple.position, velocity, chest, out float closest, out float eta, out Vector3 closestPoint);
        if (closest <= incomingAppleRadius && eta <= incomingWindow)
        {
            incomingApple = apple.GetComponent<AppleItem>();
            appleThrownAtNpc = true;
            incomingEta = eta;
            interceptPoint = FlattenToNav(closestPoint);
            incomingIsHigh = apple.position.y > transform.position.y + 1.05f;
            incomingFromSide = Mathf.Abs(Vector3.Dot(transform.right, (apple.position - transform.position).normalized)) > 0.55f;
            return;
        }
    }

    public void NotifyAppleCollision(AppleItem apple)
    {
        if (apple == null || Time.time < ignoreIncomingUntil)
            return;
        incomingApple = apple;
        incomingVelocity = apple.Body != null ? apple.Body.linearVelocity : Vector3.zero;
        appleThrownAtNpc = true;
        currentApple = apple.transform;
        heardThrowAt = Time.time;
        interceptPoint = FlattenToNav(apple.transform.position);
        incomingEta = 0f;
        incomingIsHigh = apple.transform.position.y > transform.position.y + 1.05f;
        incomingFromSide = Mathf.Abs(Vector3.Dot(transform.right, (apple.transform.position - transform.position).normalized)) > 0.55f;
    }

    public void ConsumeIncomingApple()
    {
        appleThrownAtNpc = false;
        incomingApple = null;
        incomingVelocity = Vector3.zero;
        ignoreIncomingUntil = Time.time + 0.35f;
    }

    public void IgnoreIncomingFor(float seconds)
    {
        appleThrownAtNpc = false;
        ignoreIncomingUntil = Time.time + seconds;
    }

    public AppleItem NearestLooseApple(float maxDistance = 8f)
    {
        if (AppleManager.Instance == null)
            return null;
        return AppleManager.Instance.FindNearestLooseApple(transform.position, maxDistance);
    }

    public bool ObjectWithin(float maxDistance)
    {
        return NearestLooseApple(maxDistance) != null;
    }

    public bool IsAppleAirborne(Transform apple)
    {
        if (apple == null)
            return false;
        var item = apple.GetComponent<AppleItem>();
        var body = item != null ? item.Body : apple.GetComponent<Rigidbody>();
        if (body != null && body.linearVelocity.magnitude > 1.1f)
            return true;
        return apple.position.y > transform.position.y + 0.55f;
    }

    static void PredictApproach(Vector3 origin, Vector3 velocity, Vector3 target, out float closest, out float eta, out Vector3 closestPoint)
    {
        float speed = velocity.magnitude;
        if (speed < 0.05f)
        {
            closest = Vector3.Distance(origin, target);
            eta = 0f;
            closestPoint = origin;
            return;
        }

        Vector3 toTarget = target - origin;
        float t = Vector3.Dot(toTarget, velocity) / (speed * speed);
        eta = Mathf.Clamp(t, 0f, 2.5f);
        closestPoint = origin + velocity * eta;
        closest = Vector3.Distance(closestPoint, target);
    }

    static Vector3 FlattenToNav(Vector3 point)
    {
        if (NavMesh.SamplePosition(point, out var hit, 3f, NavMesh.AllAreas))
            return hit.position;
        point.y = 0f;
        return point;
    }
}
