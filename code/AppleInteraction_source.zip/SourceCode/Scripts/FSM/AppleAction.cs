public enum AppleAction
{
    Offer,
    Evade,
    Drop,
    Throw
}