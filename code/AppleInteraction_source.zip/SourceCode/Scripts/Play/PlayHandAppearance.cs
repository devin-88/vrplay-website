using UnityEngine;

/// <summary>
/// Applies the GameSettings skin tone to Oculus hands in the play scene.
/// </summary>
public class PlayHandAppearance : MonoBehaviour
{
    void Start()
    {
        ApplyFromSettings();
    }

    public static void ApplyFromSettings()
    {
        int index = (int)SkinStyle.SoftBeige;
        if (GameSettings.Instance != null)
            index = (int)GameSettings.Instance.GetSkinStyle();

        HandSkinCatalog.ApplyToNamedHands(index);
    }
}
