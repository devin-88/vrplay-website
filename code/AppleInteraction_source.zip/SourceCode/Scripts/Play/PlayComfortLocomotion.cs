using Unity.XR.CoreUtils;
using UnityEngine;
using UnityEngine.InputSystem;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Movement;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation;
using UnityEngine.XR.Interaction.Toolkit.Samples.StarterAssets;
using CommonUsages = UnityEngine.XR.CommonUsages;
using XRInputDevice = UnityEngine.XR.InputDevice;

/// <summary>
/// Comfort locomotion: blink a short step in the look direction when the stick
/// is pushed forward. No aim arc. Grab/hold uses the index trigger.
/// </summary>
[DefaultExecutionOrder(50)]
public class PlayComfortLocomotion : MonoBehaviour
{
    public static event System.Action OnHop;
    public static event System.Action OnSnapTurn;

    public float hopDistance = 2.75f;
    public float hopThreshold = 0.65f;
    public float turnDeadzone = 0.45f;
    public float clearingRadius = 30f;
    public float snapTurnDegrees = 45f;

    TeleportationProvider teleportProvider;
    XROrigin xrOrigin;
    bool hopArmed = true;
    bool turnArmed = true;

    void Awake()
    {
        RemapSelectToTrigger();
    }

    void Start()
    {
        if (PlayWorld.Instance != null)
            clearingRadius = PlayWorld.Instance.meadowOuterRadius;

        DisableContinuousMove();
        HideTeleportAim();
        DisableTeleportAimActions();

        xrOrigin = GetComponent<XROrigin>();
        if (xrOrigin == null)
            xrOrigin = FindFirstObjectByType<XROrigin>();

        teleportProvider = null;
        if (xrOrigin != null)
            teleportProvider = xrOrigin.GetComponentInChildren<TeleportationProvider>(true);

        if (teleportProvider == null)
            teleportProvider = FindFirstObjectByType<TeleportationProvider>();

        var providers = FindObjectsByType<TeleportationProvider>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < providers.Length; i++)
        {
            // Only enable providers under the active project rig.
            if (xrOrigin != null && !providers[i].transform.IsChildOf(xrOrigin.transform))
                continue;
            providers[i].gameObject.SetActive(true);
            providers[i].enabled = true;
            providers[i].delayTime = 0f;
        }

        EnsureTreeCollisionsIgnored();
        if (TreeClimbRig.Instance != null)
            TreeClimbRig.Instance.IgnorePlayerTreeColliders();
    }

    void Update()
    {
        HideTeleportAim();
        DisableTeleportAimActions();

        if (PlayWorld.Instance != null && PlayWorld.Instance.PlayerIsClimbing)
        {
            hopArmed = true;
            turnArmed = true;
            return;
        }

        Vector2 stick = ReadMoveStick();
        bool wantsHop = stick.y >= hopThreshold && Mathf.Abs(stick.x) <= turnDeadzone;
        if (wantsHop)
        {
            if (hopArmed)
            {
                hopArmed = false;
                HopForward();
                OnHop?.Invoke();
            }
        }
        else
        {
            hopArmed = true;
        }

        // Stick L/R turning removed — it was unreliable in VR. Players turn by looking.
    }

    void HandleStickSnapTurn(Vector2 stick)
    {
        // Intentionally disabled.
    }

    void HandleKeyboardSnapTurn()
    {
#if UNITY_EDITOR || DEVELOPMENT_BUILD
        // Editor-only convenience (I/J). Stick turning stays off in headset builds.
        if (Keyboard.current == null)
            return;

        bool left = Keyboard.current.iKey.wasPressedThisFrame;
        bool right = Keyboard.current.jKey.wasPressedThisFrame;
        if (!left && !right)
        {
            turnArmed = true;
            return;
        }

        if (!turnArmed)
            return;

        turnArmed = false;
        float yaw = left ? -snapTurnDegrees : snapTurnDegrees;
        SnapTurn(yaw);
        OnSnapTurn?.Invoke();
#endif
    }

    void SnapTurn(float yawDegrees)
    {
        if (xrOrigin == null)
            return;

        Transform head = xrOrigin.Camera != null ? xrOrigin.Camera.transform : null;
        Vector3 pivot = head != null ? head.position : xrOrigin.transform.position;
        xrOrigin.transform.RotateAround(pivot, Vector3.up, yawDegrees);
    }

    void HopForward()
    {
        Transform head = xrOrigin != null && xrOrigin.Camera != null
            ? xrOrigin.Camera.transform
            : Camera.main != null ? Camera.main.transform : null;
        if (head == null)
            return;

        Vector3 facing = head.forward;
        facing.y = 0f;
        if (facing.sqrMagnitude < 0.001f)
            return;
        facing.Normalize();

        Vector3 feet = GetFeetPosition(head);
        Vector3 destination = ResolveGroundHopDestination(feet, feet + facing * hopDistance);

        // Direct move — TeleportationProvider can settle onto ClimbInteractable /
        // branch volumes near the tree and leave you in the canopy.
        MoveOriginTo(destination, head);
        EnsureTreeCollisionsIgnored();
    }

    Vector3 GetFeetPosition(Transform head)
    {
        if (xrOrigin != null)
        {
            var controller = xrOrigin.GetComponent<CharacterController>();
            if (controller != null && controller.enabled)
            {
                Vector3 bottom = xrOrigin.transform.TransformPoint(
                    controller.center - Vector3.up * (controller.height * 0.5f - controller.radius));
                return new Vector3(head.position.x, bottom.y - controller.radius + controller.skinWidth, head.position.z);
            }

            return new Vector3(head.position.x, xrOrigin.transform.position.y, head.position.z);
        }

        return new Vector3(head.position.x, head.position.y - 1.6f, head.position.z);
    }

    /// <summary>
    /// Builds a hop landing on real ground outside the trunk. Ignores canopy / branch
    /// hits that SnapToGround and NavMesh can otherwise stick to.
    /// </summary>
    Vector3 ResolveGroundHopDestination(Vector3 feet, Vector3 proposed)
    {
        Vector3 flat = new Vector3(proposed.x, feet.y, proposed.z);

        if (PlayWorld.Instance != null)
        {
            float radius = PlayWorld.Instance.DistanceFromCenter(flat);
            if (radius > clearingRadius)
            {
                Vector3 center = PlayWorld.Instance.Center;
                Vector3 fromCenter = flat - center;
                fromCenter.y = 0f;
                if (fromCenter.sqrMagnitude > 0.001f)
                    flat = center + fromCenter.normalized * clearingRadius;
            }
        }

        // Large clearance so the CharacterController cannot overlap trunk / platforms.
        const float bodyClearance = 1.15f;
        if (TrunkClimbPath.Instance != null)
            flat = TrunkClimbPath.Instance.PushPointOutsideTrunkBase(flat, bodyClearance);

        flat = SampleGroundIgnoringTree(flat, feet.y);

        if (TrunkClimbPath.Instance != null)
        {
            flat = TrunkClimbPath.Instance.PushPointOutsideTrunkBase(flat, bodyClearance);
            flat = SampleGroundIgnoringTree(flat, feet.y);
        }

        // Always stay on ground-level hops — never inherit branch / platform height.
        flat.y = SampleTerrainOrFallback(flat, feet.y);
        if (flat.y > feet.y + 0.25f)
            flat.y = feet.y;

        return flat;
    }

    static float SampleTerrainOrFallback(Vector3 position, float fallbackY)
    {
        var terrain = Terrain.activeTerrain;
        if (terrain != null)
            return terrain.SampleHeight(position) + terrain.transform.position.y;
        return fallbackY;
    }

    static Vector3 SampleGroundIgnoringTree(Vector3 position, float fallbackY)
    {
        Vector3 origin = new Vector3(position.x, Mathf.Max(position.y, fallbackY) + 10f, position.z);
        var hits = Physics.RaycastAll(origin, Vector3.down, 50f, ~0, QueryTriggerInteraction.Ignore);
        System.Array.Sort(hits, (a, b) => a.distance.CompareTo(b.distance));

        for (int i = 0; i < hits.Length; i++)
        {
            var col = hits[i].collider;
            if (col == null)
                continue;
            if (IsElevatedTreeVolume(col))
                continue;
            if (col.GetComponentInParent<AppleItem>() != null)
                continue;

            // Skip anything well above the player's feet (branches / platforms).
            if (hits[i].point.y > fallbackY + 0.45f)
                continue;

            return hits[i].point;
        }

        float y = SampleTerrainOrFallback(position, fallbackY);
        return new Vector3(position.x, y, position.z);
    }

    static bool IsElevatedTreeVolume(Collider col)
    {
        if (col == null)
            return false;
        string n = col.name;
        if (n.StartsWith("ClimbSegment") || n.StartsWith("BranchPlatform") ||
            n == "TreeClimbMesh" || n == "TrunkWalkBlocker" || n == "TreeTrunkCollider")
            return true;
        if (TrunkClimbPath.Instance != null && TrunkClimbPath.Instance.IsTreeCollider(col))
            return true;
        Transform t = col.transform;
        while (t != null)
        {
            if (t.name == "TreeClimb" || t.name == "Tree")
                return true;
            t = t.parent;
        }
        return false;
    }

    void EnsureTreeCollisionsIgnored()
    {
        if (xrOrigin == null)
            return;
        var controller = xrOrigin.GetComponent<CharacterController>();
        if (controller == null)
            return;

        var mesh = GameObject.Find("TreeClimbMesh");
        if (mesh != null)
        {
            var mc = mesh.GetComponent<Collider>();
            if (mc != null)
                Physics.IgnoreCollision(controller, mc, true);
        }

        var platforms = FindObjectsByType<Collider>(FindObjectsInactive.Exclude, FindObjectsSortMode.None);
        for (int i = 0; i < platforms.Length; i++)
        {
            var col = platforms[i];
            if (col == null)
                continue;
            if (!col.name.StartsWith("BranchPlatform"))
                continue;
            Physics.IgnoreCollision(controller, col, true);
        }
    }

    void MoveOriginTo(Vector3 groundPoint, Transform head)
    {
        if (xrOrigin == null)
            return;

        var controller = xrOrigin.GetComponent<CharacterController>();
        if (controller != null)
            controller.enabled = false;

        // Keep headset height; only slide XZ, then pin the floor to sampled ground.
        Vector3 pos = xrOrigin.transform.position;
        pos.x += groundPoint.x - head.position.x;
        pos.z += groundPoint.z - head.position.z;
        pos.y = groundPoint.y;
        xrOrigin.transform.position = pos;

        if (controller != null)
            controller.enabled = true;
    }

    static Vector2 ReadMoveStick()
    {
        Vector2 stick = Vector2.zero;
        AccumulateStick(XRNode.LeftHand, ref stick);
        AccumulateStick(XRNode.RightHand, ref stick);

        // XR Interaction Simulator drives Input System actions, not always XR InputDevice axes.
        if (stick.sqrMagnitude < 0.0001f)
            stick += ReadInputSystemMove();

#if UNITY_EDITOR || DEVELOPMENT_BUILD
        if (stick.sqrMagnitude < 0.0001f)
            stick += ReadKeyboardMove();
#endif
        return Vector2.ClampMagnitude(stick, 1f);
    }

    static void AccumulateStick(XRNode node, ref Vector2 stick)
    {
        XRInputDevice device = InputDevices.GetDeviceAtXRNode(node);
        if (device.isValid && device.TryGetFeatureValue(CommonUsages.primary2DAxis, out Vector2 axis))
            stick += axis;
    }

    static Vector2 ReadInputSystemMove()
    {
        Vector2 sum = Vector2.zero;
        var managers = FindObjectsByType<UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager>(
            FindObjectsInactive.Exclude, FindObjectsSortMode.None);
        for (int i = 0; i < managers.Length; i++)
        {
            var list = managers[i].actionAssets;
            if (list == null)
                continue;
            for (int a = 0; a < list.Count; a++)
            {
                var asset = list[a];
                if (asset == null)
                    continue;
                sum += ReadMoveAction(asset, "XRI Left Locomotion");
                sum += ReadMoveAction(asset, "XRI Right Locomotion");
            }
        }
        return sum;
    }

    static Vector2 ReadMoveAction(InputActionAsset asset, string mapName)
    {
        var map = asset.FindActionMap(mapName);
        var action = map != null ? map.FindAction("Move") : null;
        if (action == null)
            return Vector2.zero;
        if (!action.enabled)
            action.Enable();
        return action.ReadValue<Vector2>();
    }

#if UNITY_EDITOR || DEVELOPMENT_BUILD
    static Vector2 ReadKeyboardMove()
    {
        if (Keyboard.current == null)
            return Vector2.zero;

        Vector2 v = Vector2.zero;
        if (Keyboard.current.wKey.isPressed || Keyboard.current.upArrowKey.isPressed)
            v.y += 1f;
        if (Keyboard.current.sKey.isPressed || Keyboard.current.downArrowKey.isPressed)
            v.y -= 1f;
        if (Keyboard.current.aKey.isPressed || Keyboard.current.leftArrowKey.isPressed)
            v.x -= 1f;
        if (Keyboard.current.dKey.isPressed || Keyboard.current.rightArrowKey.isPressed)
            v.x += 1f;
        return v;
    }
#endif

    void DisableContinuousMove()
    {
        var movers = FindObjectsByType<DynamicMoveProvider>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < movers.Length; i++)
            movers[i].enabled = false;

        // Comfort loco owns snap turns so the tutorial receives OnSnapTurn in VR.
        var snapTurns = FindObjectsByType<UnityEngine.XR.Interaction.Toolkit.Locomotion.Turning.SnapTurnProvider>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < snapTurns.Length; i++)
            snapTurns[i].enabled = false;

        var continuousTurns = FindObjectsByType<UnityEngine.XR.Interaction.Toolkit.Locomotion.Turning.ContinuousTurnProvider>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < continuousTurns.Length; i++)
            continuousTurns[i].enabled = false;

        var managers = FindObjectsByType<ControllerInputActionManager>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < managers.Length; i++)
        {
            managers[i].smoothMotionEnabled = false;
            managers[i].smoothTurnEnabled = false;
        }
    }

    static void HideTeleportAim()
    {
        foreach (var child in FindObjectsByType<Transform>(FindObjectsInactive.Include, FindObjectsSortMode.None))
        {
            if (child == null)
                continue;
            if (child.name == "Teleport Interactor" || child.name == "Climb Teleport")
                child.gameObject.SetActive(false);
        }

        var rays = FindObjectsByType<XRRayInteractor>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < rays.Length; i++)
        {
            if (rays[i] != null && rays[i].gameObject.name.Contains("Teleport"))
                rays[i].gameObject.SetActive(false);
        }
    }

    static void DisableTeleportAimActions()
    {
        var actionManagers = FindObjectsByType<UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < actionManagers.Length; i++)
        {
            var list = actionManagers[i].actionAssets;
            if (list == null)
                continue;
            for (int a = 0; a < list.Count; a++)
                DisableTeleportActions(list[a]);
        }
    }

    static void DisableTeleportActions(InputActionAsset asset)
    {
        if (asset == null)
            return;
        DisableAction(asset, "XRI Left Locomotion", "Teleport Mode");
        DisableAction(asset, "XRI Left Locomotion", "Teleport Mode Cancel");
        DisableAction(asset, "XRI Right Locomotion", "Teleport Mode");
        DisableAction(asset, "XRI Right Locomotion", "Teleport Mode Cancel");
    }

    static void DisableAction(InputActionAsset asset, string mapName, string actionName)
    {
        var map = asset.FindActionMap(mapName);
        var action = map != null ? map.FindAction(actionName) : null;
        if (action != null && action.enabled)
            action.Disable();
    }

    static void RemapSelectToTrigger()
    {
        var actionManagers = FindObjectsByType<UnityEngine.XR.Interaction.Toolkit.Inputs.InputActionManager>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < actionManagers.Length; i++)
        {
            var list = actionManagers[i].actionAssets;
            if (list == null)
                continue;
            for (int a = 0; a < list.Count; a++)
            {
                if (list[a] != null)
                    RemapAsset(list[a]);
            }
        }
    }

    static void RemapAsset(InputActionAsset asset)
    {
        RemapMap(asset.FindActionMap("XRI Left Interaction"));
        RemapMap(asset.FindActionMap("XRI Right Interaction"));
    }

    static void RemapMap(InputActionMap map)
    {
        if (map == null)
            return;

        ReplaceBinding(map.FindAction("Select"), "{GripButton}", "{TriggerButton}");
        ReplaceBinding(map.FindAction("Select Value"), "{Grip}", "{Trigger}");
        ReplaceBinding(map.FindAction("Activate"), "{TriggerButton}", "{GripButton}");
        ReplaceBinding(map.FindAction("Activate Value"), "{Trigger}", "{Grip}");
    }

    static void ReplaceBinding(InputAction action, string fromToken, string toToken)
    {
        if (action == null)
            return;

        for (int i = 0; i < action.bindings.Count; i++)
        {
            string path = action.bindings[i].effectivePath;
            if (string.IsNullOrEmpty(path) || !path.Contains(fromToken))
                continue;
            if (fromToken == "{Grip}" && path.Contains("{GripButton}"))
                continue;
            if (fromToken == "{Trigger}" && path.Contains("{TriggerButton}"))
                continue;
            action.ApplyBindingOverride(i, path.Replace(fromToken, toToken));
        }
    }
}
