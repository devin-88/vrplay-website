using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Interactables;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Climbing;

/// <summary>
/// Shared world facts for the woodland clearing: centre, player pose, climb/hold queries.
/// </summary>
public class PlayWorld : MonoBehaviour
{
    public static PlayWorld Instance { get; private set; }

    [Header("Clearing")]
    public Transform clearingCenter;
    public float treeBaseRadius = 2f;
    public float meadowInnerRadius = 5f;
    public float meadowOuterRadius = 30f;

    [Header("Player")]
    public Transform player;
    public Transform leftHand;
    public Transform rightHand;
    public ClimbProvider climbProvider;

    [Header("Idle")]
    public float idleSpeedThreshold = 0.1f;

    Vector3 lastPlayerPosition;
    float playerSpeed;
    bool hasLastPlayerPosition;

    public Vector3 Center
    {
        get
        {
            if (clearingCenter != null)
                return clearingCenter.position;
            return Vector3.zero;
        }
    }

    public float PlayerSpeed => playerSpeed;

    public bool PlayerIsIdle => playerSpeed < idleSpeedThreshold;

    public bool PlayerIsClimbing =>
        climbProvider != null && climbProvider.climbAnchorInteractable != null;

    void Awake()
    {
        Instance = this;
        ResolveReferences();
    }

    void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    void Start()
    {
        ResolveReferences();
    }

    void Update()
    {
        if (player == null)
            return;

        if (!hasLastPlayerPosition)
        {
            lastPlayerPosition = player.position;
            hasLastPlayerPosition = true;
            return;
        }

        Vector3 delta = player.position - lastPlayerPosition;
        delta.y = 0f;
        playerSpeed = delta.magnitude / Mathf.Max(Time.deltaTime, 0.0001f);
        lastPlayerPosition = player.position;
    }

    public void ResolveReferences()
    {
        if (clearingCenter == null)
        {
            var tree = GameObject.Find("Tree");
            if (tree != null)
                clearingCenter = tree.transform;
        }

        if (player == null && Camera.main != null)
            player = Camera.main.transform;

        if (leftHand == null)
        {
            var left = GameObject.Find("Left Controller");
            if (left != null)
                leftHand = left.transform;
        }

        if (rightHand == null)
        {
            var right = GameObject.Find("Right Controller");
            if (right != null)
                rightHand = right.transform;
        }

        if (climbProvider == null)
            climbProvider = FindFirstObjectByType<ClimbProvider>();
    }

    public float DistanceFromCenter(Vector3 worldPosition)
    {
        Vector3 flat = worldPosition - Center;
        flat.y = 0f;
        return flat.magnitude;
    }

    public float PlayerDistanceFromCenter()
    {
        if (player == null)
            return 0f;
        return DistanceFromCenter(player.position);
    }

    public float PlayerDistanceTo(Vector3 worldPosition)
    {
        if (player == null)
            return float.MaxValue;
        return Vector3.Distance(player.position, worldPosition);
    }

    public Vector3 FlatDirectionFromCenter(Vector3 worldPosition)
    {
        Vector3 flat = worldPosition - Center;
        flat.y = 0f;
        if (flat.sqrMagnitude < 0.0001f)
            return Vector3.forward;
        return flat.normalized;
    }

    public Vector3 RandomPointAroundTree(float minRadius, float maxRadius)
    {
        Vector2 circle = Random.insideUnitCircle.normalized * Random.Range(minRadius, maxRadius);
        Vector3 point = Center + new Vector3(circle.x, 0f, circle.y);
        point.y = Center.y;
        if (UnityEngine.AI.NavMesh.SamplePosition(point, out var hit, 4f, UnityEngine.AI.NavMesh.AllAreas))
            return hit.position;
        return point;
    }

    public Vector3 GroundPointNearPlayer(float distance)
    {
        if (player == null)
            return RandomPointAroundTree(treeBaseRadius, meadowInnerRadius);

        Vector3 origin = player.position;
        Vector3 forward = player.forward;
        forward.y = 0f;
        if (forward.sqrMagnitude < 0.001f)
            forward = Vector3.forward;
        Vector3 point = origin + forward.normalized * distance;
        return SnapToGround(point, 0.2f);
    }

    public Vector3 SnapToGround(Vector3 worldPosition, float extraHeight = 0.05f)
    {
        Vector3 origin = worldPosition + Vector3.up * 4f;
        int mask = ~0;
        if (Physics.Raycast(origin, Vector3.down, out var hit, 12f, mask, QueryTriggerInteraction.Ignore))
        {
            if (hit.collider != null && hit.collider.GetComponentInParent<AppleItem>() == null)
                return hit.point + Vector3.up * extraHeight;
        }

        if (UnityEngine.AI.NavMesh.SamplePosition(worldPosition, out var navHit, 4f, UnityEngine.AI.NavMesh.AllAreas))
            return navHit.position + Vector3.up * extraHeight;

        var terrain = Terrain.activeTerrain;
        if (terrain != null)
        {
            float y = terrain.SampleHeight(worldPosition) + terrain.transform.position.y;
            return new Vector3(worldPosition.x, y + extraHeight, worldPosition.z);
        }

        return worldPosition + Vector3.up * extraHeight;
    }

    public bool TryGetHeldApple(out AppleItem apple)
    {
        apple = FindHeldApple();
        return apple != null;
    }

    public AppleItem FindHeldApple()
    {
        var apples = FindObjectsByType<AppleItem>(FindObjectsSortMode.None);
        for (int i = 0; i < apples.Length; i++)
        {
            if (apples[i] != null && apples[i].IsHeldByPlayer)
                return apples[i];
        }

        return null;
    }

    public bool PlayerIsHoldingApple => FindHeldApple() != null;

    public void PulseHaptics(float amplitude = 0.4f, float duration = 0.08f)
    {
        var players = FindObjectsByType<UnityEngine.XR.Interaction.Toolkit.Inputs.Haptics.HapticImpulsePlayer>(
            FindObjectsSortMode.None);
        for (int i = 0; i < players.Length; i++)
        {
            if (players[i] != null)
                players[i].SendHapticImpulse(amplitude, duration);
        }
    }
}
