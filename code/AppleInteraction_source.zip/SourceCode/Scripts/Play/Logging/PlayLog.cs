using System;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

/// <summary>
/// Static facade for PLAY session logging. Safe no-op when no logger is active.
/// </summary>
public static class PlayLog
{
    public static PlaySessionLogger Logger { get; set; }

    public static float SessionTime =>
        PlaySession.Instance != null ? PlaySession.Instance.Elapsed : Time.time;

    public static string NpcStateName()
    {
        var fsm = UnityEngine.Object.FindFirstObjectByType<SquirrelFSM>();
        return StateLabel(fsm);
    }

    public static string StateLabel(SquirrelFSM fsm)
    {
        if (fsm == null || fsm.currentState == null)
            return "none";

        if (fsm.currentState is ThrownAtReactState react)
            return "react_" + react.Reaction.ToString().ToLowerInvariant();

        if (fsm.currentState is OnTreeState)
            return "on_tree";

        switch (fsm.currentStateId)
        {
            case SquirrelState.Idle: return "idle";
            case SquirrelState.OfferingApple: return "offering_apple";
            case SquirrelState.Watching: return "watching";
            case SquirrelState.ChasingApple: return "chasing_apple";
            case SquirrelState.Retrieving: return "retrieving";
            case SquirrelState.HoldingApple: return "holding_apple";
            case SquirrelState.Evading: return "keepaway";
            case SquirrelState.ThrowingApple: return "throwing_apple";
            case SquirrelState.DroppingApple: return "dropping_apple";
            case SquirrelState.Surprise: return "surprise";
            case SquirrelState.End: return "end";
            default: return fsm.currentStateId.ToString().ToLowerInvariant();
        }
    }

    public static void Event(
        string eventType,
        string actor = "",
        string state = null,
        string value1 = "",
        string value2 = "",
        string value3 = "")
    {
        if (Logger == null)
            return;
        if (string.IsNullOrEmpty(state))
            state = NpcStateName();
        Logger.LogEvent(eventType, actor, state, value1, value2, value3);
    }
}
