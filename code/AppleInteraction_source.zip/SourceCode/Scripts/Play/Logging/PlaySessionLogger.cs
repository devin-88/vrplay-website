using System;
using System.Collections.Generic;
using System.Globalization;
using System.IO;
using System.Text;
using UnityEngine;

/// <summary>
/// Writes per-session PLAY CSV logs:
/// - {id}_events.csv (discrete events)
/// - {id}_continuous.csv (10 Hz)
/// - {id}_metadata.csv (session + summary stats)
/// Does not alter gameplay; only observes and records.
/// </summary>
[DefaultExecutionOrder(100)]
public class PlaySessionLogger : MonoBehaviour
{
    const string PrefsLastId = "PLAY_LastParticipantNumber";
    const float ContinuousHz = 10f;
    const float ThrowTargetRadius = 1.5f;
    const float ApproachNear = 2f;
    const float ApproachFar = 5f;
    const float MutualRadius = 3f;
    const float MutualHoldSeconds = 5f;
    const float FollowRadius = 4f;
    const float FollowHoldSeconds = 3f;
    const float IdleSpeed = 0.1f;
    const float IdleHoldSeconds = 10f;
    const float ChainGapSeconds = 5f;
    const float OfferIgnoreSeconds = 12f;
    const float FleeSpeed = 1.2f;

    [Tooltip("Override auto ID, e.g. P001. Leave empty to auto-increment.")]
    public string participantIdOverride = "";

    [Tooltip("Optional condition label stored in metadata (e.g. with_npc / baseline).")]
    public string conditionLabel = "play";

    public string ParticipantId { get; private set; }
    public string SessionFolder { get; private set; }

    StreamWriter eventsWriter;
    StreamWriter continuousWriter;
    float nextContinuousAt;
    float sessionStartTime;
    bool started;
    bool closed;

    Transform participant;
    Transform npc;
    SquirrelFSM fsm;
    Vector3 prevParticipantPos;
    Vector3 prevNpcPos;
    float prevSampleTime;

    // Proximity / social tracking
    float lastDistance = 999f;
    bool wasFarFromNpc = true;
    bool npcWasFarFromParticipant = true;
    float mutualCloseSince = -1f;
    bool mutualActive;
    float participantFollowSince = -1f;
    float npcFollowSince = -1f;
    bool participantFollowing;
    bool npcFollowing;
    float participantIdleSince = -1f;
    bool participantIdle;
    bool wasIdleLong;
    string lastNpcState = "none";
    float npcIdleSince = -1f;
    bool npcIdleLogged;

    // Offer tracking
    bool offerPending;
    float offerStartedAt = -1f;
    bool invitationPending;
    float invitationStartedAt = -1f;

    // Keepaway
    bool keepawayActive;
    float keepawayStartedAt = -1f;

    // Chains
    int chainId;
    int chainLength;
    string chainInitiator = "";
    string lastChainActor = "";
    float lastChainActionAt = -999f;
    bool chainOpen;
    readonly List<int> completedChainLengths = new List<int>();
    float lastChainEndedAt = -1f;
    float lastParticipantFleeLogAt = -999f;
    float lastNpcFleeLogAt = -999f;

    // Summary counters
    int totalInteractions;
    int participantInitiated;
    int npcInitiated;
    int invitationCount;
    int invitationAccepted;
    int keepawayCount;
    int keepawayCaught;
    float proximityAccum;
    float activeAccum;
    float timeToFirstInteraction = -1f;
    bool hadFirstInteraction;

    readonly StringBuilder line = new StringBuilder(256);
    readonly CultureInfo culture = CultureInfo.InvariantCulture;

    void Awake()
    {
        PlayLog.Logger = this;
    }

    void Start()
    {
        BeginSession();
    }

    void OnDestroy()
    {
        EndSession();
        if (PlayLog.Logger == this)
            PlayLog.Logger = null;
    }

    void OnApplicationQuit()
    {
        EndSession();
    }

    void BeginSession()
    {
        if (started)
            return;

        sessionStartTime = Time.time;
        if (PlaySession.Instance != null)
            sessionStartTime = Time.time - PlaySession.Instance.Elapsed;

        ParticipantId = ResolveParticipantId();
        string stamp = DateTime.Now.ToString("yyyyMMdd_HHmmss", culture);
        SessionFolder = Path.Combine(Application.persistentDataPath, "PLAY_Logs", ParticipantId + "_" + stamp);
        Directory.CreateDirectory(SessionFolder);

        string eventsPath = Path.Combine(SessionFolder, ParticipantId + "_events.csv");
        string continuousPath = Path.Combine(SessionFolder, ParticipantId + "_continuous.csv");

        eventsWriter = new StreamWriter(eventsPath, false, Encoding.UTF8) { AutoFlush = true };
        continuousWriter = new StreamWriter(continuousPath, false, Encoding.UTF8) { AutoFlush = false };
        eventsWriter.WriteLine("timestamp,event_type,actor,state,value1,value2,value3");
        continuousWriter.WriteLine(
            "timestamp,participant_x,participant_y,participant_z,npc_x,npc_y,npc_z,distance_to_npc,participant_velocity,npc_state,participant_climbing");

        ResolveActors();
        if (participant != null)
            prevParticipantPos = participant.position;
        if (npc != null)
            prevNpcPos = npc.position;
        prevSampleTime = Time.time;
        nextContinuousAt = Time.time;

        started = true;
        LogEvent("session_started", "system", "idle",
            "participant_id: " + ParticipantId,
            "condition: " + conditionLabel,
            "folder: " + SessionFolder);

        Debug.Log("PLAY logging → " + SessionFolder);
    }

    string ResolveParticipantId()
    {
        if (!string.IsNullOrWhiteSpace(participantIdOverride))
            return participantIdOverride.Trim();

        int n = PlayerPrefs.GetInt(PrefsLastId, 0) + 1;
        PlayerPrefs.SetInt(PrefsLastId, n);
        PlayerPrefs.Save();
        return "P" + n.ToString("000", culture);
    }

    void ResolveActors()
    {
        if (PlayWorld.Instance != null && PlayWorld.Instance.player != null)
            participant = PlayWorld.Instance.player;
        else
        {
            var origin = FindFirstObjectByType<Unity.XR.CoreUtils.XROrigin>();
            if (origin != null)
                participant = origin.Camera != null ? origin.Camera.transform : origin.transform;
            else if (Camera.main != null)
                participant = Camera.main.transform;
        }

        fsm = FindFirstObjectByType<SquirrelFSM>();
        if (fsm != null)
            npc = fsm.transform;
    }

    void Update()
    {
        if (!started || closed)
            return;

        if (participant == null || npc == null || fsm == null)
            ResolveActors();

        float now = Time.time;
        TickProximityAndSocial(now);
        TickOfferAndKeepaway(now);
        TickChainTimeout(now);

        while (now >= nextContinuousAt)
        {
            WriteContinuousRow(nextContinuousAt);
            nextContinuousAt += 1f / ContinuousHz;
        }

        if (PlaySession.Instance != null && PlaySession.Instance.HasSoftExited)
            EndSession();
        else if (PlaySession.Instance != null && PlaySession.Instance.HasEnded && !closed)
        {
            // Soft exit may still be fading; close after a short buffer via HasSoftExited.
        }
    }

    float Stamp(float absoluteTime)
    {
        return Mathf.Max(0f, absoluteTime - sessionStartTime);
    }

    public void LogEvent(string eventType, string actor, string state, string value1, string value2, string value3)
    {
        if (!started)
            BeginSession();
        if (closed || eventsWriter == null)
            return;

        NoteInteraction(eventType, actor);
        UpdateChain(eventType, actor, value1);

        line.Length = 0;
        line.Append(Stamp(Time.time).ToString("F3", culture)).Append(',')
            .Append(Escape(eventType)).Append(',')
            .Append(Escape(actor)).Append(',')
            .Append(Escape(state ?? PlayLog.NpcStateName())).Append(',')
            .Append(Escape(value1)).Append(',')
            .Append(Escape(value2)).Append(',')
            .Append(Escape(value3));
        eventsWriter.WriteLine(line.ToString());
    }

    static string Escape(string s)
    {
        if (string.IsNullOrEmpty(s))
            return "";
        if (s.IndexOfAny(new[] { ',', '"', '\n', '\r' }) < 0)
            return s;
        return "\"" + s.Replace("\"", "\"\"") + "\"";
    }

    void NoteInteraction(string eventType, string actor)
    {
        bool counts =
            eventType.StartsWith("apple_", StringComparison.Ordinal) ||
            eventType.StartsWith("npc_offer", StringComparison.Ordinal) ||
            eventType.StartsWith("npc_reaction", StringComparison.Ordinal) ||
            eventType == "participant_initiated_play" ||
            eventType == "npc_proactive_initiation" ||
            eventType == "apple_transferred_to_npc";

        if (!counts)
            return;

        totalInteractions++;
        if (actor == "participant")
            participantInitiated++;
        else if (actor == "npc")
            npcInitiated++;

        if (!hadFirstInteraction)
        {
            hadFirstInteraction = true;
            timeToFirstInteraction = Stamp(Time.time);
        }
    }

    void UpdateChain(string eventType, string actor, string value1)
    {
        bool link =
            eventType == "apple_thrown_at_npc" ||
            eventType == "apple_thrown_npc" ||
            eventType == "apple_retrieved_npc" ||
            eventType == "apple_caught_participant" ||
            eventType == "apple_transferred_to_npc" ||
            eventType == "npc_reaction_catch" ||
            eventType == "apple_offered_npc" ||
            eventType == "npc_offer_accepted";

        if (!link)
            return;
        if (actor != "participant" && actor != "npc")
            return;

        float t = Time.time;
        if (chainOpen && t - lastChainActionAt > ChainGapSeconds)
            CloseChain("gap");

        if (!chainOpen)
        {
            chainOpen = true;
            chainId++;
            chainLength = 1;
            chainInitiator = actor;
            lastChainActor = actor;
            lastChainActionAt = t;
            LogEventRaw("chain_started", actor, PlayLog.NpcStateName(),
                "chain_id: " + chainId,
                "initiator: " + actor,
                "action: " + eventType);
            LogEventRaw("chain_initiator", actor, PlayLog.NpcStateName(),
                "chain_id: " + chainId, actor, eventType);
            return;
        }

        if (actor != lastChainActor)
        {
            chainLength++;
            lastChainActor = actor;
            lastChainActionAt = t;
            LogEventRaw("chain_link_added", actor, PlayLog.NpcStateName(),
                "chain_id: " + chainId,
                "action: " + eventType,
                "length: " + chainLength);
        }
        else
        {
            lastChainActionAt = t;
        }
    }

    void TickChainTimeout(float now)
    {
        if (chainOpen && now - lastChainActionAt > ChainGapSeconds)
            CloseChain("gap");
    }

    void CloseChain(string reason)
    {
        if (!chainOpen)
            return;
        completedChainLengths.Add(chainLength);
        LogEventRaw("chain_ended", lastChainActor, PlayLog.NpcStateName(),
            "chain_id: " + chainId,
            "length: " + chainLength,
            "reason: " + reason);
        LogEventRaw("chain_length", lastChainActor, PlayLog.NpcStateName(),
            "chain_id: " + chainId,
            chainLength.ToString(culture),
            "");
        if (lastChainEndedAt > 0f)
        {
            float gap = Stamp(Time.time) - lastChainEndedAt;
            LogEventRaw("time_between_chains", "system", PlayLog.NpcStateName(),
                gap.ToString("F3", culture),
                "from_chain: " + chainId,
                "");
        }

        lastChainEndedAt = Stamp(Time.time);
        chainOpen = false;
        chainLength = 0;
        lastChainActor = "";
        LogEventRaw("chain_count", "system", PlayLog.NpcStateName(),
            completedChainLengths.Count.ToString(culture), "", "");
    }

    void LogEventRaw(string eventType, string actor, string state, string v1, string v2, string v3)
    {
        if (eventsWriter == null || closed)
            return;
        line.Length = 0;
        line.Append(Stamp(Time.time).ToString("F3", culture)).Append(',')
            .Append(Escape(eventType)).Append(',')
            .Append(Escape(actor)).Append(',')
            .Append(Escape(state)).Append(',')
            .Append(Escape(v1)).Append(',')
            .Append(Escape(v2)).Append(',')
            .Append(Escape(v3));
        eventsWriter.WriteLine(line.ToString());
    }

    void WriteContinuousRow(float absoluteTime)
    {
        if (continuousWriter == null)
            return;

        Vector3 p = participant != null ? participant.position : Vector3.zero;
        Vector3 n = npc != null ? npc.position : Vector3.zero;
        float dt = Mathf.Max(0.0001f, absoluteTime - prevSampleTime);
        float pSpeed = participant != null ? Vector3.Distance(p, prevParticipantPos) / dt : 0f;
        float dist = participant != null && npc != null ? Vector3.Distance(p, n) : 0f;
        bool climbing = PlayWorld.Instance != null && PlayWorld.Instance.PlayerIsClimbing;
        string state = PlayLog.StateLabel(fsm);

        if (dist <= ApproachNear)
            proximityAccum += 1f / ContinuousHz;
        if (pSpeed >= IdleSpeed)
            activeAccum += 1f / ContinuousHz;

        continuousWriter.WriteLine(string.Format(culture,
            "{0:F3},{1:F3},{2:F3},{3:F3},{4:F3},{5:F3},{6:F3},{7:F3},{8:F3},{9},{10}",
            Stamp(absoluteTime),
            p.x, p.y, p.z,
            n.x, n.y, n.z,
            dist, pSpeed,
            state,
            climbing ? "true" : "false"));

        if ((int)(absoluteTime * ContinuousHz) % 10 == 0)
            continuousWriter.Flush();

        prevParticipantPos = p;
        prevNpcPos = n;
        prevSampleTime = absoluteTime;
        lastDistance = dist;
        lastNpcState = state;
    }

    void TickProximityAndSocial(float now)
    {
        if (participant == null || npc == null)
            return;

        Vector3 p = participant.position;
        Vector3 n = npc.position;
        float dist = Vector3.Distance(p, n);
        float dt = Mathf.Max(0.0001f, now - prevSampleTime);
        Vector3 pDelta = p - prevParticipantPos;
        Vector3 nDelta = n - prevNpcPos;
        float pSpeed = pDelta.magnitude / dt;
        float nSpeed = nDelta.magnitude / dt;

        // Approach: from >5m to <=2m
        if (wasFarFromNpc && dist <= ApproachNear)
        {
            wasFarFromNpc = false;
            LogEvent("participant_approached_npc", "participant", lastNpcState,
                "distance: " + dist.ToString("F2", culture),
                FormatPos("participant", p),
                FormatPos("npc", n));
            MaybeParticipantInitiated("approach");
        }
        else if (dist > ApproachFar)
        {
            wasFarFromNpc = true;
        }

        if (npcWasFarFromParticipant && dist <= ApproachNear && nSpeed > 0.35f)
        {
            npcWasFarFromParticipant = false;
            LogEvent("npc_approached_participant", "npc", lastNpcState,
                "distance: " + dist.ToString("F2", culture),
                FormatPos("npc", n),
                FormatPos("participant", p));
        }
        else if (dist > ApproachFar)
        {
            npcWasFarFromParticipant = true;
        }

        // Mutual proximity
        if (dist <= MutualRadius)
        {
            if (mutualCloseSince < 0f)
                mutualCloseSince = now;
            if (!mutualActive && now - mutualCloseSince >= MutualHoldSeconds)
            {
                mutualActive = true;
                LogEvent("mutual_proximity_start", "system", lastNpcState,
                    "distance: " + dist.ToString("F2", culture),
                    FormatPos("participant", p),
                    FormatPos("npc", n));
            }
        }
        else
        {
            if (mutualActive)
            {
                LogEvent("mutual_proximity_end", "system", lastNpcState,
                    "distance: " + dist.ToString("F2", culture), "", "");
                mutualActive = false;
            }

            mutualCloseSince = -1f;
        }

        // Follow
        bool pMoving = pSpeed > 0.35f;
        bool nMoving = nSpeed > 0.35f;
        if (dist < FollowRadius && nMoving && pMoving &&
            Vector3.Dot(pDelta.normalized, (n - p).normalized) > 0.2f)
        {
            if (participantFollowSince < 0f)
                participantFollowSince = now;
            if (!participantFollowing && now - participantFollowSince >= FollowHoldSeconds)
            {
                participantFollowing = true;
                LogEvent("participant_followed_npc", "participant", lastNpcState,
                    "distance: " + dist.ToString("F2", culture), "", "");
            }
        }
        else
        {
            participantFollowSince = -1f;
            participantFollowing = false;
        }

        if (dist < FollowRadius && pMoving && nMoving &&
            Vector3.Dot(nDelta.normalized, (p - n).normalized) > 0.2f)
        {
            if (npcFollowSince < 0f)
                npcFollowSince = now;
            if (!npcFollowing && now - npcFollowSince >= FollowHoldSeconds)
            {
                npcFollowing = true;
                LogEvent("npc_followed_participant", "npc", lastNpcState,
                    "distance: " + dist.ToString("F2", culture), "", "");
            }
        }
        else
        {
            npcFollowSince = -1f;
            npcFollowing = false;
        }

        // Flee (throttled)
        if (nMoving && Vector3.Dot(nDelta.normalized, (p - n).normalized) > 0.35f &&
            pSpeed > FleeSpeed && Vector3.Dot(pDelta.normalized, (p - n).normalized) > 0.35f &&
            now - lastParticipantFleeLogAt > 2f)
        {
            lastParticipantFleeLogAt = now;
            LogEvent("participant_fled_npc", "participant", lastNpcState,
                "speed: " + pSpeed.ToString("F2", culture),
                "distance: " + dist.ToString("F2", culture), "");
        }

        if (fsm != null && fsm.currentStateId == SquirrelState.Evading && nSpeed > 0.5f &&
            now - lastNpcFleeLogAt > 2f)
        {
            lastNpcFleeLogAt = now;
            LogEvent("npc_fled_participant", "npc", "keepaway",
                "speed: " + nSpeed.ToString("F2", culture),
                "distance: " + dist.ToString("F2", culture), "");
        }

        // Participant idle
        if (pSpeed < IdleSpeed)
        {
            if (participantIdleSince < 0f)
                participantIdleSince = now;
            if (!participantIdle && now - participantIdleSince >= IdleHoldSeconds)
            {
                participantIdle = true;
                wasIdleLong = true;
                LogEvent("participant_idle_start", "participant", lastNpcState, "", "", "");
            }
        }
        else if (participantIdle)
        {
            participantIdle = false;
            participantIdleSince = -1f;
            LogEvent("participant_idle_end", "participant", lastNpcState, "", "", "");
        }
        else
        {
            participantIdleSince = -1f;
        }

        // NPC idle enter
        string state = PlayLog.StateLabel(fsm);
        if (state == "idle")
        {
            if (npcIdleSince < 0f)
                npcIdleSince = now;
            if (!npcIdleLogged && lastNpcState != "idle" && lastNpcState != "none")
            {
                npcIdleLogged = true;
                LogEvent("npc_idle_start", "npc", "idle", "from: " + lastNpcState, "", "");
            }
        }
        else
        {
            npcIdleSince = -1f;
            npcIdleLogged = false;
        }

        lastDistance = dist;
    }

    void TickOfferAndKeepaway(float now)
    {
        if (fsm == null)
            return;

        string state = PlayLog.StateLabel(fsm);

        // Invitation / offer = OfferingApple
        if (state == "offering_apple")
        {
            if (!invitationPending)
            {
                invitationPending = true;
                invitationStartedAt = now;
                invitationCount++;
                LogEvent("npc_play_invitation_started", "npc", state, "", "", "");
            }

            if (!offerPending && fsm.HoldingApple == false)
            {
                // Apple already placed near player.
                offerPending = true;
                offerStartedAt = now;
            }

            if (invitationPending && participant != null &&
                Vector3.Distance(participant.position, npc.position) <= ApproachNear)
            {
                invitationAccepted++;
                LogEvent("npc_play_invitation_accepted", "participant", state,
                    "distance: " + Vector3.Distance(participant.position, npc.position).ToString("F2", culture),
                    "", "");
                invitationPending = false;
            }

            if (invitationPending && now - invitationStartedAt > 8f)
            {
                LogEvent("npc_play_invitation_ignored", "participant", state, "timeout: 8s", "", "");
                invitationPending = false;
            }

            if (offerPending && PlayWorld.Instance != null && PlayWorld.Instance.PlayerIsHoldingApple)
            {
                LogEvent("npc_offer_accepted", "participant", state, "", "", "");
                offerPending = false;
                NoteVoluntaryReinit("offer_accepted");
            }
            else if (offerPending && now - offerStartedAt > OfferIgnoreSeconds)
            {
                LogEvent("npc_offer_ignored", "participant", state, "timeout: 12s", "", "");
                offerPending = false;
            }
        }
        else
        {
            invitationPending = false;
            if (offerPending && state != "watching")
                offerPending = false;
        }

        // Keepaway = Evading while holding / after hold
        if (state == "keepaway")
        {
            if (!keepawayActive)
            {
                keepawayActive = true;
                keepawayStartedAt = now;
                keepawayCount++;
                LogEvent("npc_keepaway_start", "npc", state, "", "", "");
            }
            else if (participant != null && Vector3.Distance(participant.position, npc.position) <= ApproachNear)
            {
                keepawayCaught++;
                LogEvent("npc_keepaway_caught", "participant", state,
                    "distance: " + Vector3.Distance(participant.position, npc.position).ToString("F2", culture),
                    "", "");
                keepawayActive = false;
            }
        }
        else if (keepawayActive)
        {
            LogEvent("npc_keepaway_abandoned", "npc", state,
                "duration: " + (now - keepawayStartedAt).ToString("F2", culture), "", "");
            keepawayActive = false;
        }
    }

    public void NotifyParticipantPickup()
    {
        LogEvent("apple_picked_up_participant", "participant", PlayLog.NpcStateName(), "", "", "");
        NoteVoluntaryReinit("pickup");
        if (offerPending)
        {
            LogEvent("npc_offer_accepted", "participant", PlayLog.NpcStateName(), "", "", "");
            offerPending = false;
        }
    }

    public void NotifyParticipantThrow(Vector3 origin, Vector3 velocity)
    {
        float speed = velocity.magnitude;
        bool atNpc = TrajectoryTargetsNpc(origin, velocity);
        LogEvent("apple_thrown_participant", "participant", PlayLog.NpcStateName(),
            "velocity: " + speed.ToString("F2", culture),
            atNpc ? "at_npc" : "away_from_npc",
            "");
        if (atNpc)
        {
            LogEvent("apple_thrown_at_npc", "participant", PlayLog.NpcStateName(),
                "velocity: " + speed.ToString("F2", culture),
                FormatPos("origin", origin),
                FormatPos("npc", npc != null ? npc.position : Vector3.zero));
            MaybeParticipantInitiated("throw_at_npc");
        }
        else
        {
            LogEvent("apple_thrown_away_from_npc", "participant", PlayLog.NpcStateName(),
                "velocity: " + speed.ToString("F2", culture), "", "");
        }

        NoteVoluntaryReinit("throw");
    }

    public void NotifyParticipantDrop(Vector3 origin)
    {
        LogEvent("apple_dropped_participant", "participant", PlayLog.NpcStateName(),
            FormatPos("pos", origin), "", "");
    }

    public void NotifyTransferToNpc()
    {
        LogEvent("apple_transferred_to_npc", "participant", PlayLog.NpcStateName(), "", "", "");
        MaybeParticipantInitiated("transfer");
        NoteVoluntaryReinit("transfer");
    }

    public void NotifyNpcPickup(bool catchPlay)
    {
        LogEvent("apple_picked_up_npc", "npc", PlayLog.NpcStateName(),
            catchPlay ? "catch: true" : "catch: false", "", "");
    }

    public void NotifyNpcThrow(Vector3 velocity)
    {
        LogEvent("apple_thrown_npc", "npc", PlayLog.NpcStateName(),
            "velocity: " + velocity.magnitude.ToString("F2", culture), "", "");
    }

    public void NotifyNpcOfferPlaced()
    {
        offerPending = true;
        offerStartedAt = Time.time;
        LogEvent("apple_offered_npc", "npc", PlayLog.NpcStateName(), "", "", "");
    }

    public void NotifyNpcRetrieve()
    {
        LogEvent("apple_retrieved_npc", "npc", PlayLog.NpcStateName(), "", "", "");
    }

    public void NotifyNpcReaction(ThrownAtReaction reaction)
    {
        string name;
        switch (reaction)
        {
            case ThrownAtReaction.Dodge: name = "npc_reaction_dodge"; break;
            case ThrownAtReaction.Catch: name = "npc_reaction_catch"; break;
            case ThrownAtReaction.Shocked: name = "npc_reaction_shocked"; break;
            case ThrownAtReaction.PlayfulTrip: name = "npc_reaction_trip"; break;
            case ThrownAtReaction.Taunt: name = "npc_reaction_taunt"; break;
            default: name = "npc_reaction_" + reaction.ToString().ToLowerInvariant(); break;
        }

        LogEvent(name, "npc", PlayLog.NpcStateName(), reaction.ToString(), "", "");
    }

    public void NotifyNpcSurprise()
    {
        LogEvent("npc_reaction_surprise_jump", "npc", PlayLog.NpcStateName(), "", "", "");
    }

    public void NotifyNpcStateEnter(string fromState, string toState)
    {
        if (toState == "idle" && fromState != "idle" && fromState != "none")
            LogEvent("npc_idle_start", "npc", toState, "from: " + fromState, "", "");

        // Proactive play: idle long then chase/retrieve/offer without player nearby.
        if ((toState == "chasing_apple" || toState == "retrieving" || toState == "offering_apple") &&
            fromState == "idle" &&
            npcIdleSince > 0f && Time.time - npcIdleSince >= 20f &&
            (participant == null || Vector3.Distance(participant.position, npc.position) > ApproachFar))
        {
            LogEvent("npc_proactive_initiation", "npc", toState,
                "idle_for: " + (Time.time - npcIdleSince).ToString("F1", culture),
                toState, "");
        }
    }

    void MaybeParticipantInitiated(string how)
    {
        string state = PlayLog.NpcStateName();
        if (state == "idle" || state == "watching" || state == "on_tree")
        {
            LogEvent("participant_initiated_play", "participant", state, "via: " + how, "", "");
        }
    }

    void NoteVoluntaryReinit(string via)
    {
        if (!wasIdleLong)
            return;
        wasIdleLong = false;
        LogEvent("participant_voluntary_reinitiation", "participant", PlayLog.NpcStateName(),
            "via: " + via, "", "");
    }

    bool TrajectoryTargetsNpc(Vector3 origin, Vector3 velocity)
    {
        if (npc == null || velocity.sqrMagnitude < 0.01f)
            return false;

        Vector3 target = npc.position + Vector3.up * 0.6f;
        Vector3 toNpc = target - origin;
        float speed = velocity.magnitude;
        float horizon = Mathf.Clamp(toNpc.magnitude / Mathf.Max(0.1f, speed) + 0.5f, 0.3f, 3.5f);
        Vector3 end = origin + velocity * horizon;
        float closest = DistancePointToSegment(target, origin, end);
        if (closest <= ThrowTargetRadius)
            return true;

        // Also treat near-NPC release as targeting.
        return toNpc.magnitude <= ThrowTargetRadius + 0.5f &&
               Vector3.Dot(velocity.normalized, toNpc.normalized) > 0.25f;
    }

    static float DistancePointToSegment(Vector3 point, Vector3 a, Vector3 b)
    {
        Vector3 ab = b - a;
        float denom = ab.sqrMagnitude;
        if (denom < 1e-6f)
            return Vector3.Distance(point, a);
        float t = Mathf.Clamp01(Vector3.Dot(point - a, ab) / denom);
        return Vector3.Distance(point, a + ab * t);
    }

    static string FormatPos(string label, Vector3 p)
    {
        return string.Format(CultureInfo.InvariantCulture, "{0}: ({1:F2},{2:F2},{3:F2})", label, p.x, p.y, p.z);
    }

    public void EndSession()
    {
        if (!started || closed)
            return;
        closed = true;

        if (chainOpen)
            CloseChain("session_end");

        LogEventRaw("session_ended", "system", PlayLog.NpcStateName(),
            "duration: " + Stamp(Time.time).ToString("F3", culture), "", "");

        WriteMetadata();

        if (eventsWriter != null)
        {
            eventsWriter.Flush();
            eventsWriter.Dispose();
            eventsWriter = null;
        }

        if (continuousWriter != null)
        {
            continuousWriter.Flush();
            continuousWriter.Dispose();
            continuousWriter = null;
        }
    }

    void WriteMetadata()
    {
        float duration = Mathf.Max(0.001f, Stamp(Time.time));
        float meanChain = 0f;
        int maxChain = 0;
        if (completedChainLengths.Count > 0)
        {
            int sum = 0;
            for (int i = 0; i < completedChainLengths.Count; i++)
            {
                sum += completedChainLengths[i];
                if (completedChainLengths[i] > maxChain)
                    maxChain = completedChainLengths[i];
            }

            meanChain = sum / (float)completedChainLengths.Count;
        }

        float roleBalance = 0f;
        int a = participantInitiated;
        int b = npcInitiated;
        if (a > 0 || b > 0)
            roleBalance = Mathf.Min(a, b) / (float)Mathf.Max(1, Mathf.Max(a, b));

        string path = Path.Combine(SessionFolder, ParticipantId + "_metadata.csv");
        using (var w = new StreamWriter(path, false, Encoding.UTF8))
        {
            w.WriteLine("key,value");
            w.WriteLine("participant_id," + Escape(ParticipantId));
            w.WriteLine("condition," + Escape(conditionLabel));
            w.WriteLine("session_folder," + Escape(SessionFolder));
            w.WriteLine("unity_scene," + Escape(UnityEngine.SceneManagement.SceneManager.GetActiveScene().name));
            w.WriteLine("started_utc," + DateTime.UtcNow.ToString("o", culture));
            w.WriteLine("session_duration_s," + duration.ToString("F3", culture));
            w.WriteLine("total_interactions," + totalInteractions.ToString(culture));
            w.WriteLine("interaction_rate," + (totalInteractions / duration).ToString("F4", culture));
            w.WriteLine("participant_initiated_ratio," + (totalInteractions > 0 ? participantInitiated / (float)totalInteractions : 0f).ToString("F4", culture));
            w.WriteLine("npc_initiated_ratio," + (totalInteractions > 0 ? npcInitiated / (float)totalInteractions : 0f).ToString("F4", culture));
            w.WriteLine("mean_chain_length," + meanChain.ToString("F3", culture));
            w.WriteLine("max_chain_length," + maxChain.ToString(culture));
            w.WriteLine("chain_count," + completedChainLengths.Count.ToString(culture));
            w.WriteLine("time_in_proximity_ratio," + (proximityAccum / duration).ToString("F4", culture));
            w.WriteLine("active_time_ratio," + (activeAccum / duration).ToString("F4", culture));
            w.WriteLine("time_to_first_interaction," + (timeToFirstInteraction >= 0f ? timeToFirstInteraction.ToString("F3", culture) : ""));
            w.WriteLine("play_invitation_acceptance_rate," + (invitationCount > 0 ? invitationAccepted / (float)invitationCount : 0f).ToString("F4", culture));
            w.WriteLine("keepaway_chase_rate," + (keepawayCount > 0 ? keepawayCaught / (float)keepawayCount : 0f).ToString("F4", culture));
            w.WriteLine("role_balance_ratio," + roleBalance.ToString("F4", culture));
        }
    }
}
