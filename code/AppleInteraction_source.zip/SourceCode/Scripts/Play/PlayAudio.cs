using UnityEngine;

/// <summary>
/// Spatial audio bank for PLAY. Music/ambience loop in 2D; NPC cues play spatial with pitch variation.
/// Assign clips in the Inspector, or use PLAY/Audio/Auto-Assign Sound Clips.
/// </summary>
public class PlayAudio : MonoBehaviour
{
    public enum Cue
    {
        EntryChime,
        SessionEndChime,
        FirstPickupPing,
        AmbientIdleChitter,
        ExcitedChitter,
        HappyChirp,
        DisappointedMurmur,
        SurpriseEep,
        PlayfulGiggle,
        Laugh,
        Laugh2,
        Mumble,
        Doh,
        Taunt,
        DodgeWhoop,
        ApplePop,
        AppleWhoosh,
        AppleThud,
        AppleBonk,
        AppleShimmer,
        AppleTransfer,
        BasketRustle,
        BasketOverturn,
        BasketCatch,
        ClimbStart
    }

    public static PlayAudio Instance { get; private set; }

    public AudioSource templateSource;

    [Header("Music & Ambience (2D loops)")]
    public AudioClip backgroundMusic;
    public AudioClip outdoorAmbience;
    [Range(0f, 1f)] public float musicVolume = 0.28f;
    [Range(0f, 1f)] public float ambienceVolume = 0.45f;
    [Tooltip("Playback speed for the song. 1 = normal, 0.85 = slower, 1.15 = faster. Also shifts pitch.")]
    [Range(0.5f, 1.5f)] public float musicSpeed = 1f;
    [Range(0.5f, 1.5f)] public float ambienceSpeed = 1f;

    [Header("Session")]
    public AudioClip entryChime;
    public AudioClip sessionEndChime;
    public AudioClip firstPickupPing;

    [Header("NPC")]
    public AudioClip idleChitter;
    public AudioClip excitedChitter;
    public AudioClip happyChirp;
    public AudioClip disappointedMurmur;
    public AudioClip surpriseEep;
    public AudioClip playfulGiggle;
    public AudioClip laugh;
    public AudioClip laugh2;
    public AudioClip mumble;
    public AudioClip doh;
    public AudioClip taunt;
    public AudioClip dodgeWhoop;

    [Header("NPC Voice — Master")]
    [Tooltip("Base pitch for all squirrel voice clips. Raise for smaller/cuter, lower for deeper.")]
    [Range(0.5f, 2.5f)] public float npcBasePitch = 1.35f;
    [Tooltip("Random pitch wobble added around the base (± this amount).")]
    [Range(0f, 0.5f)] public float npcPitchJitter = 0.12f;
    [Range(0f, 1f)] public float npcVolume = 0.8f;
    [Tooltip("Extra random volume variation (± this amount).")]
    [Range(0f, 0.4f)] public float npcVolumeJitter = 0.08f;

    [Header("NPC Voice — Mood Offsets")]
    [Tooltip("Added on top of base pitch for each mood.")]
    [Range(-0.5f, 0.5f)] public float idlePitchOffset = -0.05f;
    [Range(-0.5f, 0.5f)] public float happyPitchOffset = 0.08f;
    [Range(-0.5f, 0.5f)] public float excitedPitchOffset = 0.15f;
    [Range(-0.5f, 0.5f)] public float sadPitchOffset = -0.12f;
    [Range(-0.5f, 0.5f)] public float surprisePitchOffset = 0.2f;
    [Range(-0.5f, 0.5f)] public float tauntPitchOffset = 0.05f;
    [Range(-0.5f, 0.5f)] public float dodgePitchOffset = 0.18f;

    [Header("NPC Voice — Space")]
    [Range(0f, 1f)] public float npcSpatialBlend = 1f;
    public float npcMinDistance = 1.2f;
    public float npcMaxDistance = 18f;
    [Range(0f, 1.1f)] public float npcReverbZoneMix = 1f;
    public AudioRolloffMode npcRolloff = AudioRolloffMode.Linear;

    [Header("Objects")]
    public AudioClip applePop;
    public AudioClip appleWhoosh;
    public AudioClip appleThud;
    public AudioClip appleBonk;
    public AudioClip appleShimmer;
    public AudioClip appleTransfer;
    public AudioClip basketRustle;
    public AudioClip basketOverturn;
    public AudioClip basketCatch;
    public AudioClip climbStart;

    [Header("Object Tuning")]
    public float objectPitchMin = 0.92f;
    public float objectPitchMax = 1.08f;
    [Range(0f, 1f)] public float objectVolume = 0.85f;

    AudioSource musicSource;
    AudioSource ambienceSource;

    void Awake()
    {
        Instance = this;
#if UNITY_EDITOR
        if (!HasCoreClips())
            AutoAssignClips();
#endif
        EnsureTemplate();
        EnsureLoops();
    }

    void Start()
    {
        EnsureLoops();
        PlayLoops();
    }

    void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    void EnsureTemplate()
    {
        if (templateSource != null)
            return;
        templateSource = gameObject.AddComponent<AudioSource>();
        templateSource.playOnAwake = false;
        templateSource.spatialBlend = 1f;
        templateSource.rolloffMode = AudioRolloffMode.Linear;
        templateSource.maxDistance = 18f;
    }

    void EnsureLoops()
    {
        if (musicSource == null)
        {
            musicSource = gameObject.AddComponent<AudioSource>();
            musicSource.playOnAwake = false;
            musicSource.loop = true;
            musicSource.spatialBlend = 0f;
            musicSource.priority = 64;
        }

        if (ambienceSource == null)
        {
            ambienceSource = gameObject.AddComponent<AudioSource>();
            ambienceSource.playOnAwake = false;
            ambienceSource.loop = true;
            ambienceSource.spatialBlend = 0f;
            ambienceSource.priority = 80;
        }
    }

    void PlayLoops()
    {
        if (backgroundMusic != null)
        {
            musicSource.clip = backgroundMusic;
            musicSource.volume = musicVolume;
            musicSource.pitch = musicSpeed;
            if (!musicSource.isPlaying)
                musicSource.Play();
        }

        if (outdoorAmbience != null)
        {
            ambienceSource.clip = outdoorAmbience;
            ambienceSource.volume = ambienceVolume;
            ambienceSource.pitch = ambienceSpeed;
            if (!ambienceSource.isPlaying)
                ambienceSource.Play();
        }
    }

    bool fadingLoops;
    float loopFadeStartMusic;
    float loopFadeStartAmbience;
    float loopFadeDuration;
    float loopFadeElapsed;

    void Update()
    {
        if (fadingLoops)
        {
            loopFadeElapsed += Time.deltaTime;
            float t = loopFadeDuration > 0.01f ? Mathf.Clamp01(loopFadeElapsed / loopFadeDuration) : 1f;
            if (musicSource != null)
                musicSource.volume = Mathf.Lerp(loopFadeStartMusic, 0f, t);
            if (ambienceSource != null)
                ambienceSource.volume = Mathf.Lerp(loopFadeStartAmbience, 0f, t);
            if (t >= 1f)
            {
                fadingLoops = false;
                if (musicSource != null)
                    musicSource.Stop();
                if (ambienceSource != null)
                    ambienceSource.Stop();
            }

            return;
        }

        if (musicSource != null && backgroundMusic != null)
        {
            musicSource.volume = musicVolume;
            musicSource.pitch = musicSpeed;
        }

        if (ambienceSource != null && outdoorAmbience != null)
        {
            ambienceSource.volume = ambienceVolume;
            ambienceSource.pitch = ambienceSpeed;
        }
    }

    /// <summary>
    /// Softly silence music and ambience for session end.
    /// </summary>
    public void FadeOutLoops(float duration)
    {
        EnsureLoops();
        fadingLoops = true;
        loopFadeElapsed = 0f;
        loopFadeDuration = Mathf.Max(0.1f, duration);
        loopFadeStartMusic = musicSource != null ? musicSource.volume : 0f;
        loopFadeStartAmbience = ambienceSource != null ? ambienceSource.volume : 0f;
    }

    public static void Play(Cue cue, Vector3 position)
    {
        if (Instance == null)
            return;
        Instance.PlayCue(cue, position);
    }

    /// <summary>
    /// Picks a random non-null cue from the list and plays it.
    /// </summary>
    public static void PlayRandom(Vector3 position, params Cue[] cues)
    {
        if (Instance == null || cues == null || cues.Length == 0)
            return;

        int start = Random.Range(0, cues.Length);
        for (int i = 0; i < cues.Length; i++)
        {
            Cue cue = cues[(start + i) % cues.Length];
            if (Instance.ClipFor(cue) != null)
            {
                Instance.PlayCue(cue, position);
                return;
            }
        }
    }

    public void PlayCue(Cue cue, Vector3 position)
    {
        AudioClip clip = ClipFor(cue);
        if (clip == null)
            return;

        bool npc = IsNpcCue(cue);
        float volume;
        float pitch;
        if (npc)
        {
            volume = Mathf.Clamp01(npcVolume + Random.Range(-npcVolumeJitter, npcVolumeJitter));
            pitch = ResolveNpcPitch(cue);
            PlayNpcAt(clip, position, volume, pitch);
        }
        else if (cue == Cue.EntryChime || cue == Cue.SessionEndChime || cue == Cue.FirstPickupPing)
        {
            volume = 0.9f;
            pitch = cue == Cue.SessionEndChime ? 0.92f : 1f;
            PlayAt(clip, position, volume, pitch, 0f, 1f, 50f, AudioRolloffMode.Linear, 0.5f);
        }
        else
        {
            volume = objectVolume;
            pitch = Random.Range(objectPitchMin, objectPitchMax);
            PlayAt(clip, position, volume, pitch, 1f, 1.2f, 18f, AudioRolloffMode.Linear, 1f);
        }
    }

    float ResolveNpcPitch(Cue cue)
    {
        float mood = 0f;
        switch (cue)
        {
            case Cue.AmbientIdleChitter:
            case Cue.Mumble:
                mood = idlePitchOffset;
                break;
            case Cue.HappyChirp:
            case Cue.PlayfulGiggle:
            case Cue.Laugh:
            case Cue.Laugh2:
                mood = happyPitchOffset;
                break;
            case Cue.ExcitedChitter:
                mood = excitedPitchOffset;
                break;
            case Cue.DisappointedMurmur:
            case Cue.Doh:
                mood = sadPitchOffset;
                break;
            case Cue.SurpriseEep:
                mood = surprisePitchOffset;
                break;
            case Cue.Taunt:
                mood = tauntPitchOffset;
                break;
            case Cue.DodgeWhoop:
                mood = dodgePitchOffset;
                break;
        }

        float pitch = npcBasePitch + mood + Random.Range(-npcPitchJitter, npcPitchJitter);
        return Mathf.Clamp(pitch, 0.4f, 3f);
    }

    void PlayNpcAt(AudioClip clip, Vector3 position, float volume, float pitch)
    {
        PlayAt(clip, position, volume, pitch, npcSpatialBlend, npcMinDistance, npcMaxDistance, npcRolloff, npcReverbZoneMix);
    }

    void PlayAt(
        AudioClip clip,
        Vector3 position,
        float volume,
        float pitch,
        float spatialBlend,
        float minDistance,
        float maxDistance,
        AudioRolloffMode rolloff,
        float reverbMix)
    {
        var go = new GameObject("PlayCue");
        go.transform.position = position;
        var source = go.AddComponent<AudioSource>();
        source.clip = clip;
        source.volume = volume;
        source.pitch = pitch;
        source.spatialBlend = spatialBlend;
        source.rolloffMode = rolloff;
        source.minDistance = minDistance;
        source.maxDistance = maxDistance;
        source.reverbZoneMix = reverbMix;
        source.Play();
        Destroy(go, clip.length / Mathf.Max(0.05f, pitch) + 0.1f);
    }

    static bool IsNpcCue(Cue cue)
    {
        switch (cue)
        {
            case Cue.AmbientIdleChitter:
            case Cue.ExcitedChitter:
            case Cue.HappyChirp:
            case Cue.DisappointedMurmur:
            case Cue.SurpriseEep:
            case Cue.PlayfulGiggle:
            case Cue.Laugh:
            case Cue.Laugh2:
            case Cue.Mumble:
            case Cue.Doh:
            case Cue.Taunt:
            case Cue.DodgeWhoop:
                return true;
            default:
                return false;
        }
    }

    AudioClip ClipFor(Cue cue)
    {
        switch (cue)
        {
            case Cue.EntryChime: return entryChime;
            case Cue.SessionEndChime: return sessionEndChime != null ? sessionEndChime : entryChime;
            case Cue.FirstPickupPing: return firstPickupPing;
            case Cue.AmbientIdleChitter: return idleChitter;
            case Cue.ExcitedChitter: return excitedChitter;
            case Cue.HappyChirp: return happyChirp;
            case Cue.DisappointedMurmur: return disappointedMurmur;
            case Cue.SurpriseEep: return surpriseEep;
            case Cue.PlayfulGiggle: return playfulGiggle;
            case Cue.Laugh: return laugh;
            case Cue.Laugh2: return laugh2;
            case Cue.Mumble: return mumble;
            case Cue.Doh: return doh;
            case Cue.Taunt: return taunt;
            case Cue.DodgeWhoop: return dodgeWhoop;
            case Cue.ApplePop: return applePop;
            case Cue.AppleWhoosh: return appleWhoosh;
            case Cue.AppleThud: return appleThud;
            case Cue.AppleBonk: return appleBonk;
            case Cue.AppleShimmer: return appleShimmer;
            case Cue.AppleTransfer: return appleTransfer;
            case Cue.BasketRustle: return basketRustle;
            case Cue.BasketOverturn: return basketOverturn;
            case Cue.BasketCatch: return basketCatch;
            case Cue.ClimbStart: return climbStart;
            default: return null;
        }
    }

    bool HasCoreClips()
    {
        return backgroundMusic != null && outdoorAmbience != null && happyChirp != null;
    }

#if UNITY_EDITOR
    [ContextMenu("Auto-Assign Sound Clips")]
    public void AutoAssignClips()
    {
        const string root = "Assets/Models/Sound/";
        backgroundMusic = Load(root + "Lily-Paddling Down the Stream.wav");
        outdoorAmbience = Load(root + "OUTDOOR_GENERIC_AMBIENCE.wav");

        idleChitter = Load(root + "Character Sounds/indifferent/hmm.mp3");
        excitedChitter = Load(root + "Character Sounds/happy/aha.mp3");
        happyChirp = Load(root + "Character Sounds/happy/ha.mp3");
        disappointedMurmur = Load(root + "Character Sounds/indifferent/uh.mp3");
        surpriseEep = Load(root + "Character Sounds/happy/huh.mp3");
        playfulGiggle = Load(root + "Character Sounds/indifferent/haha.mp3");
        if (playfulGiggle == null)
            playfulGiggle = Load(root + "Character Sounds/random/laugh.mp3");
        laugh = Load(root + "Character Sounds/random/laugh.mp3");
        laugh2 = Load(root + "Character Sounds/random/laugh2.mp3");
        mumble = Load(root + "Character Sounds/random/mumble.mp3");
        doh = Load(root + "Character Sounds/happy/doh.mp3");
        if (doh == null)
            doh = Load(root + "Character Sounds/indifferent/doh.mp3");
        taunt = Load(root + "Character Sounds/happy/aha.mp3");
        dodgeWhoop = Load(root + "Character Sounds/indifferent/whew.mp3");

        entryChime = Load(root + "Character Sounds/happy/aaah.mp3");
        sessionEndChime = Load(root + "Character Sounds/indifferent/whew.mp3");
        firstPickupPing = Load(root + "Character Sounds/happy/ah.mp3");

        applePop = Load(root + "INTERACTIONS/FABRIC_1.wav");
        appleWhoosh = Load(root + "INTERACTIONS/LEAFS_1.wav");
        appleThud = Load(root + "INTERACTIONS/WOOD_1.wav");
        appleBonk = Load(root + "INTERACTIONS/WOOD_2.wav");
        appleShimmer = Load(root + "INTERACTIONS/WATER_1.wav");
        appleTransfer = Load(root + "INTERACTIONS/FABRIC_2.wav");
        basketRustle = Load(root + "INTERACTIONS/LEAFS_2.wav");
        basketOverturn = Load(root + "INTERACTIONS/WOOD_3.wav");
        basketCatch = Load(root + "INTERACTIONS/FABRIC_3.wav");
        climbStart = Load(root + "WOOD/WOOD_FOOTSTEP_1.wav");

        UnityEditor.EditorUtility.SetDirty(this);
    }

    static AudioClip Load(string path)
    {
        return UnityEditor.AssetDatabase.LoadAssetAtPath<AudioClip>(path);
    }
#endif
}
