using UnityEngine;

/// <summary>
/// Shared access to the HandSkinPalette (12 material slots) for tutorial + Final.
/// </summary>
public static class HandSkinCatalog
{
    const string ResourcesPath = "HandSkinPalette";

    static HandSkinPalette cachedPalette;

    public static HandSkinPalette Palette
    {
        get
        {
            EnsurePalette();
            return cachedPalette;
        }
    }

    public static int Count => HandSkinPalette.SlotCount;

    public static void SetPalette(HandSkinPalette palette)
    {
        if (palette == null)
            return;
        palette.EnsureSlotCount();
        cachedPalette = palette;
    }

    public static void RefreshFromPalette(HandSkinPalette palette) => SetPalette(palette);

    static void EnsurePalette()
    {
        if (cachedPalette != null)
            return;

        cachedPalette = Resources.Load<HandSkinPalette>(ResourcesPath);
        if (cachedPalette != null)
            cachedPalette.EnsureSlotCount();
    }

    public static int ClampIndex(int index)
    {
        return Mathf.Clamp(index, 0, HandSkinPalette.SlotCount - 1);
    }

    public static string GetLabel(int index)
    {
        EnsurePalette();
        if (cachedPalette != null)
            return cachedPalette.GetLabel(index);
        return HandSkinPalette.CreateDefaults()[ClampIndex(index)].label;
    }

    public static Color GetSwatchColor(int index)
    {
        EnsurePalette();
        if (cachedPalette != null)
            return cachedPalette.GetSwatchColor(index);
        return HandSkinPalette.CreateDefaults()[ClampIndex(index)].swatchColor;
    }

    public static Material GetMaterial(int index)
    {
        EnsurePalette();
        return cachedPalette != null ? cachedPalette.GetMaterial(index) : null;
    }

    public static Material[] GetMaterials()
    {
        EnsurePalette();
        if (cachedPalette != null)
            return cachedPalette.GetMaterials();
        return new Material[HandSkinPalette.SlotCount];
    }

    /// <summary>Legacy helpers used by older callers.</summary>
    public static string[] Labels
    {
        get
        {
            var labels = new string[Count];
            for (int i = 0; i < labels.Length; i++)
                labels[i] = GetLabel(i);
            return labels;
        }
    }

    public static Color[] Colors
    {
        get
        {
            var colors = new Color[Count];
            for (int i = 0; i < colors.Length; i++)
                colors[i] = GetSwatchColor(i);
            return colors;
        }
    }

    public static void ApplyToHand(GameObject hand, int index)
    {
        if (hand == null)
            return;

        index = ClampIndex(index);
        Material mat = GetMaterial(index);
        if (mat != null)
        {
            foreach (var smr in hand.GetComponentsInChildren<SkinnedMeshRenderer>(true))
                smr.material = mat;
            foreach (var mr in hand.GetComponentsInChildren<MeshRenderer>(true))
                mr.material = mat;
            return;
        }

        // Fallback tint if a slot has no material assigned yet.
        Color baseColor = GetSwatchColor(index);
        Color spec = baseColor * 0.65f;
        foreach (var smr in hand.GetComponentsInChildren<SkinnedMeshRenderer>(true))
            TintRenderer(smr, baseColor, spec);
        foreach (var mr in hand.GetComponentsInChildren<MeshRenderer>(true))
            TintRenderer(mr, baseColor, spec);
    }

    public static void ApplyToNamedHands(int index)
    {
        ApplyToHand(GameObject.Find("Left Hand Model"), index);
        ApplyToHand(GameObject.Find("Right Hand Model"), index);
    }

    static void TintRenderer(Renderer renderer, Color baseColor, Color spec)
    {
        if (renderer == null)
            return;

        var mats = renderer.materials;
        for (int i = 0; i < mats.Length; i++)
        {
            var mat = mats[i];
            if (mat == null)
                continue;
            if (mat.HasProperty("_BaseColor"))
                mat.SetColor("_BaseColor", baseColor);
            if (mat.HasProperty("_Color"))
                mat.SetColor("_Color", baseColor);
            mat.color = baseColor;
            if (mat.HasProperty("_SpecColor"))
                mat.SetColor("_SpecColor", spec);
            if (mat.HasProperty("_Smoothness"))
                mat.SetFloat("_Smoothness", 0.28f);
        }
        renderer.materials = mats;
    }
}
