using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR;

/// <summary>
/// Terrain vegetation tuning for PLAY.
/// VR gets cheaper grass (shorter draw distance, lower density, almost no wind)
/// so waving details stop chewing frames and causing headset judder.
/// Flat PC keeps denser foliage with a light breeze.
/// </summary>
[DefaultExecutionOrder(-40)]
public class PlayTerrainTuning : MonoBehaviour
{
    [Header("PC (flat screen)")]
    public float pcDetailDistance = 70f;
    public float pcDetailDensity = 0.85f;
    public float pcGrassStrength = 0.22f;
    public float pcGrassSpeed = 0.35f;
    public float pcGrassAmount = 0.12f;
    public float pcWindIntensity = 0.03f;

    [Header("VR headset")]
    public float vrDetailDistance = 28f;
    public float vrDetailDensity = 0.35f;
    public float vrGrassStrength = 0.04f;
    public float vrGrassSpeed = 0.08f;
    public float vrGrassAmount = 0.04f;
    public float vrWindIntensity = 0f;
    public float vrTreeBillboardDistance = 1000f;
    public int vrTreeFullLodCount = 25;

    [Header("Shared")]
    public bool enableDrawInstanced = true;

    static readonly int WindIntensityId = Shader.PropertyToID("_WindIntensity");
    static readonly int WindSpeedId = Shader.PropertyToID("_WindSpeed");

    Terrain terrain;
    TerrainData data;
    Material[] grassMaterials;
    float[] originalWindIntensity;
    float[] originalWindSpeed;
    bool appliedVr;
    bool appliedPc;

    void Start()
    {
        terrain = Terrain.activeTerrain;
        if (terrain == null)
            terrain = FindFirstObjectByType<Terrain>();
        if (terrain == null)
            return;

        data = terrain.terrainData;
        CacheGrassMaterials();
        ApplyForCurrentMode(force: true);
    }

    void Update()
    {
        if (terrain == null)
            return;
        ApplyForCurrentMode(force: false);
    }

    void ApplyForCurrentMode(bool force)
    {
        bool vr = IsVrRunning();
        if (!force && ((vr && appliedVr) || (!vr && appliedPc)))
            return;

        if (vr)
            ApplyVr();
        else
            ApplyPc();
    }

    void ApplyPc()
    {
        terrain.detailObjectDistance = pcDetailDistance;
        terrain.detailObjectDensity = pcDetailDensity;
        terrain.drawInstanced = enableDrawInstanced;
        terrain.treeBillboardDistance = 50f;
        terrain.treeMaximumFullLODCount = 50;

        if (data != null)
        {
            data.wavingGrassStrength = pcGrassStrength;
            data.wavingGrassSpeed = pcGrassSpeed;
            data.wavingGrassAmount = pcGrassAmount;
        }

        SetGrassWind(pcWindIntensity, pcGrassSpeed);
        appliedPc = true;
        appliedVr = false;
    }

    void ApplyVr()
    {
        terrain.detailObjectDistance = vrDetailDistance;
        terrain.detailObjectDensity = vrDetailDensity;
        terrain.drawInstanced = enableDrawInstanced;
        terrain.treeBillboardDistance = vrTreeBillboardDistance;
        terrain.treeMaximumFullLODCount = vrTreeFullLodCount;

        if (data != null)
        {
            data.wavingGrassStrength = vrGrassStrength;
            data.wavingGrassSpeed = vrGrassSpeed;
            data.wavingGrassAmount = vrGrassAmount;
        }

        SetGrassWind(vrWindIntensity, vrGrassSpeed);

        appliedVr = true;
        appliedPc = false;
    }

    void CacheGrassMaterials()
    {
        if (data == null)
            return;

        var mats = new List<Material>();
        var prototypes = data.detailPrototypes;
        for (int i = 0; i < prototypes.Length; i++)
        {
            var prefab = prototypes[i].prototype;
            if (prefab == null)
                continue;
            var renderers = prefab.GetComponentsInChildren<Renderer>(true);
            for (int r = 0; r < renderers.Length; r++)
            {
                var shared = renderers[r].sharedMaterials;
                for (int m = 0; m < shared.Length; m++)
                {
                    if (shared[m] != null && !mats.Contains(shared[m]))
                        mats.Add(shared[m]);
                }
            }
        }

        grassMaterials = mats.ToArray();
        originalWindIntensity = new float[grassMaterials.Length];
        originalWindSpeed = new float[grassMaterials.Length];
        for (int i = 0; i < grassMaterials.Length; i++)
        {
            originalWindIntensity[i] = grassMaterials[i].HasProperty(WindIntensityId)
                ? grassMaterials[i].GetFloat(WindIntensityId) : 0f;
            originalWindSpeed[i] = grassMaterials[i].HasProperty(WindSpeedId)
                ? grassMaterials[i].GetFloat(WindSpeedId) : 0f;
        }
    }

    void SetGrassWind(float intensity, float speed)
    {
        if (grassMaterials == null)
            return;
        for (int i = 0; i < grassMaterials.Length; i++)
        {
            var mat = grassMaterials[i];
            if (mat == null)
                continue;
            if (mat.HasProperty(WindIntensityId))
                mat.SetFloat(WindIntensityId, intensity);
            if (mat.HasProperty(WindSpeedId))
                mat.SetFloat(WindSpeedId, Mathf.Min(speed, originalWindSpeed[i] > 0f ? originalWindSpeed[i] : speed));
        }
    }

    void OnDestroy()
    {
        // Restore authored wind so leaving Play Mode does not leave VR values on disk.
        if (grassMaterials == null || originalWindIntensity == null)
            return;
        for (int i = 0; i < grassMaterials.Length; i++)
        {
            var mat = grassMaterials[i];
            if (mat == null)
                continue;
            if (mat.HasProperty(WindIntensityId))
                mat.SetFloat(WindIntensityId, originalWindIntensity[i]);
            if (mat.HasProperty(WindSpeedId))
                mat.SetFloat(WindSpeedId, originalWindSpeed[i]);
        }
    }

    public static bool IsVrRunning()
    {
        var displays = new List<XRDisplaySubsystem>();
        SubsystemManager.GetSubsystems(displays);
        for (int i = 0; i < displays.Count; i++)
        {
            if (displays[i] != null && displays[i].running)
                return true;
        }

        return XRSettings.isDeviceActive;
    }
}
