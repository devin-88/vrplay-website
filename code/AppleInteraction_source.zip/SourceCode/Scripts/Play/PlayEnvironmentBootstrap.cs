using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Movement;
using UnityEngine.XR.Interaction.Toolkit.Samples.StarterAssets;

/// <summary>
/// Ensures the clearing, NPC, climbables, and locomotion match the design even if the scene was only partly wired.
/// </summary>
public class PlayEnvironmentBootstrap : MonoBehaviour
{
    [RuntimeInitializeOnLoadMethod(RuntimeInitializeLoadType.AfterSceneLoad)]
    static void AutoBootstrap()
    {
        // Tutorial / non-play scenes must not spawn woodland systems.
        var scene = UnityEngine.SceneManagement.SceneManager.GetActiveScene().name;
        if (scene == "VE_Tutorial" || FindFirstObjectByType<TutorialManager>() != null)
            return;

        if (FindFirstObjectByType<PlayEnvironmentBootstrap>() != null)
            return;

        var go = new GameObject("PlayEnvironment");
        go.AddComponent<PlayEnvironmentBootstrap>();
    }

    void Awake()
    {
        EnsureManagers();
        EnsureInteractionManager();
        EnsureHandGrabAnimations();
        EnsureHandAppearance();
        EnsureSquirrel();
        RemoveBaskets();
        EnsureClimbing();
        EnsureLocomotion();
        EnsureComfortLocomotion();
        EnsureTerrainTuning();
        EnsureSessionLogger();
    }

    void EnsureSessionLogger()
    {
        if (FindFirstObjectByType<PlaySessionLogger>() == null)
            gameObject.AddComponent<PlaySessionLogger>();
    }

    void EnsureHandGrabAnimations()
    {
        WireHandGrab("Left Hand Model", XRNode.LeftHand);
        WireHandGrab("Right Hand Model", XRNode.RightHand);
    }

    void EnsureHandAppearance()
    {
        if (FindFirstObjectByType<PlayHandAppearance>() == null)
            gameObject.AddComponent<PlayHandAppearance>();
        PlayHandAppearance.ApplyFromSettings();
    }

    static void WireHandGrab(string handName, XRNode node)
    {
        var hand = GameObject.Find(handName);
        if (hand == null)
            return;

        var animator = hand.GetComponent<Animator>();
        if (animator != null)
            animator.enabled = true;

        var misplaced = hand.GetComponent<ControllerAnimator>();
        if (misplaced != null)
            Destroy(misplaced);

        var driver = hand.GetComponent<PlayHandGrabAnimator>();
        if (driver == null)
            driver = hand.AddComponent<PlayHandGrabAnimator>();
        driver.handAnimator = animator;
        driver.handNode = node;
        if (driver.interactor == null && hand.transform.parent != null)
        {
            driver.interactor = hand.transform.parent.GetComponentInChildren<NearFarInteractor>(true);
            if (driver.interactor == null)
                driver.interactor = hand.transform.parent.GetComponentInChildren<XRBaseInputInteractor>(true);
        }
    }

    void EnsureTerrainTuning()
    {
        if (FindFirstObjectByType<PlayTerrainTuning>() == null)
            gameObject.AddComponent<PlayTerrainTuning>();
    }

    void EnsureManagers()
    {
        var world = FindFirstObjectByType<PlayWorld>();
        if (world == null)
            world = gameObject.AddComponent<PlayWorld>();
        world.ResolveReferences();

        if (FindFirstObjectByType<PlaySession>() == null)
            gameObject.AddComponent<PlaySession>();

        if (FindFirstObjectByType<PlayAudio>() == null)
        {
            var audio = gameObject.AddComponent<PlayAudio>();
#if UNITY_EDITOR
            audio.AutoAssignClips();
#endif
        }
        else
        {
#if UNITY_EDITOR
            var audio = FindFirstObjectByType<PlayAudio>();
            if (audio != null && audio.backgroundMusic == null)
                audio.AutoAssignClips();
#endif
        }

        var manager = FindFirstObjectByType<AppleManager>();
        if (manager == null)
            manager = gameObject.AddComponent<AppleManager>();

        var spawner = FindFirstObjectByType<AppleSpawner>();
        if (spawner != null)
        {
            if (manager.applePrefab == null)
                manager.applePrefab = spawner.applePrefab;
            if (manager.spawnPoints == null || manager.spawnPoints.Length == 0)
                manager.spawnPoints = spawner.spawnPoints;
            if (manager.appleMaterials == null || manager.appleMaterials.Length == 0)
                manager.appleMaterials = spawner.appleMaterials;
        }
    }

    void EnsureSquirrel()
    {
        var squirrel = FindFirstObjectByType<SquirrelFSM>();
        if (squirrel == null)
            return;

        if (squirrel.appleHoldPoint == null)
        {
            var existing = squirrel.transform.Find("AppleHoldPoint");
            squirrel.appleHoldPoint = existing != null
                ? existing
                : CreateHoldPoint(squirrel.transform, "AppleHoldPoint", new Vector3(0f, 0.04f, 0.06f));
        }

        // SquirrelFSM parents the hold point to Hand_R every LateUpdate.
        var follow = squirrel.appleHoldPoint.GetComponent<HandFollow>();
        if (follow != null)
            follow.enabled = false;

        if (squirrel.GetComponent<SquirrelExpression>() == null)
            squirrel.gameObject.AddComponent<SquirrelExpression>();

        var basketHold = squirrel.transform.Find("BasketHoldPoint");
        if (basketHold != null)
            basketHold.gameObject.SetActive(false);

        if (PlayWorld.Instance != null)
        {
            squirrel.treeBase = PlayWorld.Instance.clearingCenter;
            float dist = PlayWorld.Instance.DistanceFromCenter(squirrel.transform.position);
            if (dist > 8f)
            {
                Vector3 home = PlayWorld.Instance.RandomPointAroundTree(1.5f, 2.5f);
                if (squirrel.agent != null && squirrel.agent.isOnNavMesh)
                    squirrel.agent.Warp(home);
                else
                    squirrel.transform.position = home;
            }
        }
    }

    void RemoveBaskets()
    {
        var baskets = FindObjectsByType<PlayBasket>(FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < baskets.Length; i++)
        {
            if (baskets[i] != null)
                baskets[i].gameObject.SetActive(false);
        }

        var named = GameObject.Find("Basket");
        if (named != null)
            named.SetActive(false);
    }

    void EnsureInteractionManager()
    {
        if (FindFirstObjectByType<UnityEngine.XR.Interaction.Toolkit.XRInteractionManager>() != null)
            return;

        var go = GameObject.Find("XR Interaction Manager");
        if (go == null)
            go = new GameObject("XR Interaction Manager");
        if (go.GetComponent<UnityEngine.XR.Interaction.Toolkit.XRInteractionManager>() == null)
            go.AddComponent<UnityEngine.XR.Interaction.Toolkit.XRInteractionManager>();
    }

    void EnsureClimbing()
    {
        var tree = GameObject.Find("Tree");
        DisableLegacyClimbChildren(tree);

        var rigGo = GameObject.Find("TreeClimb");
        if (rigGo == null)
            rigGo = new GameObject("TreeClimb");

        var rig = rigGo.GetComponent<TreeClimbRig>();
        if (rig == null)
            rig = rigGo.AddComponent<TreeClimbRig>();
        if (tree != null)
        {
            rig.tree = tree.transform;
            var treeBody = tree.GetComponent<Rigidbody>();
            if (treeBody != null)
            {
                treeBody.isKinematic = true;
                treeBody.useGravity = false;
            }
        }
        rig.EnsureCreated();
        if (rig.trunkPath != null)
            EnsureClimbMotes(rig.trunkPath.transform);
    }

    static void DisableLegacyClimbChildren(GameObject tree)
    {
        if (tree == null)
            return;

        string[] legacy = { "TreeTrunkCollider", "BranchPlatform_1_5", "BranchPlatform_3_0", "BranchPlatform_5_0" };
        for (int i = 0; i < legacy.Length; i++)
        {
            var child = tree.transform.Find(legacy[i]);
            if (child != null)
                child.gameObject.SetActive(false);
        }
    }

    void EnsureClimbMotes(Transform trunk)
    {
        if (trunk.Find("ClimbMotes") != null)
            return;

        var motesGo = new GameObject("ClimbMotes");
        motesGo.transform.SetParent(trunk, false);
        motesGo.transform.localPosition = Vector3.up * 0.2f;
        var ps = motesGo.AddComponent<ParticleSystem>();
        var main = ps.main;
        main.startLifetime = 2.4f;
        main.startSpeed = 0.15f;
        main.startSize = 0.08f;
        main.startColor = new Color(1f, 0.92f, 0.55f, 0.8f);
        main.maxParticles = 40;
        var emission = ps.emission;
        emission.rateOverTime = 6f;
        var shape = ps.shape;
        shape.shapeType = ParticleSystemShapeType.Hemisphere;
        shape.radius = 0.6f;
        var hint = motesGo.AddComponent<ClimbHintMotes>();
        hint.trunk = trunk;
    }

    void EnsureLocomotion()
    {
        var move = FindFirstObjectByType<DynamicMoveProvider>();
        if (move != null)
            move.moveSpeed = 1.5f;

        if (FindFirstObjectByType<LocomotionTuning>() == null)
        {
            var tuning = gameObject.AddComponent<LocomotionTuning>();
            tuning.moveProvider = move;
        }

        var controller = FindFirstObjectByType<CharacterController>();
        if (controller != null && controller.radius < 0.22f)
            controller.radius = 0.22f;
    }

    void EnsureComfortLocomotion()
    {
        if (GetComponent<PlayComfortLocomotion>() == null)
            gameObject.AddComponent<PlayComfortLocomotion>();
    }

    static Transform CreateHoldPoint(Transform parent, string name, Vector3 localPosition)
    {
        var go = new GameObject(name);
        go.transform.SetParent(parent, false);
        go.transform.localPosition = localPosition;
        return go.transform;
    }
}
