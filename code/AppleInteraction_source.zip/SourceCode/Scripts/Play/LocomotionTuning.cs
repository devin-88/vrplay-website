using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit.Locomotion.Movement;
using UnityEngine.XR.Interaction.Toolkit.Samples.StarterAssets;

/// <summary>
/// Keeps the player inside the clearing radius around the tree and outside the trunk.
/// Continuous move (if enabled) slows near the edge; hops are hard-clamped.
/// </summary>
public class LocomotionTuning : MonoBehaviour
{
    public DynamicMoveProvider moveProvider;
    public float walkSpeed = 1.5f;
    public float sprintSpeed = 3f;
    public float sprintStickThreshold = 0.9f;
    public float boundaryRadius = 30f;
    public float boundarySpeed = 0.5f;

    CharacterController playerController;

    void Start()
    {
        if (moveProvider == null)
            moveProvider = FindFirstObjectByType<DynamicMoveProvider>();
        playerController = FindFirstObjectByType<CharacterController>();
        if (PlayWorld.Instance != null)
            boundaryRadius = PlayWorld.Instance.meadowOuterRadius;
    }

    void Update()
    {
        if (moveProvider != null && moveProvider.enabled)
        {
            Vector2 input = ReadMoveInput();
            float stick = input.magnitude;
            float desired = stick >= sprintStickThreshold ? sprintSpeed : walkSpeed;

            if (PlayWorld.Instance != null && PlayWorld.Instance.player != null)
            {
                Vector3 player = PlayWorld.Instance.player.position;
                float radius = PlayWorld.Instance.DistanceFromCenter(player);
                if (radius > boundaryRadius)
                {
                    Vector3 away = PlayWorld.Instance.FlatDirectionFromCenter(player);
                    Vector3 moveDir = new Vector3(input.x, 0f, input.y);
                    if (moveDir.sqrMagnitude > 0.01f)
                    {
                        Vector3 worldMove = PlayWorld.Instance.player.TransformDirection(moveDir.normalized);
                        worldMove.y = 0f;
                        if (Vector3.Dot(worldMove.normalized, away) > 0.1f)
                            desired = boundarySpeed;
                    }
                }
            }

            moveProvider.moveSpeed = desired;
        }

        KeepPlayerOutsideTrunk();
        KeepPlayerInsideClearing();
    }

    void LateUpdate()
    {
        KeepPlayerOutsideTrunk();
        KeepPlayerInsideClearing();
    }

    void KeepPlayerOutsideTrunk()
    {
        if (PlayWorld.Instance != null && PlayWorld.Instance.PlayerIsClimbing)
            return;

        var path = TrunkClimbPath.Instance;
        if (path == null)
            return;

        if (playerController == null)
            playerController = FindFirstObjectByType<CharacterController>();

        Transform body = playerController != null
            ? playerController.transform
            : PlayWorld.Instance != null ? PlayWorld.Instance.player : null;

        path.TryKeepOutside(body, 0.28f, false);
    }

    void KeepPlayerInsideClearing()
    {
        if (PlayWorld.Instance == null)
            return;
        if (PlayWorld.Instance.PlayerIsClimbing)
            return;

        if (playerController == null)
            playerController = FindFirstObjectByType<CharacterController>();

        Transform body = playerController != null
            ? playerController.transform
            : PlayWorld.Instance.player;
        if (body == null)
            return;

        Vector3 center = PlayWorld.Instance.Center;
        Vector3 flat = body.position - center;
        flat.y = 0f;
        float radius = flat.magnitude;
        float max = boundaryRadius;
        if (radius <= max || radius < 0.001f)
            return;

        Vector3 clamped = center + flat.normalized * max;
        clamped.y = body.position.y;
        Vector3 delta = clamped - body.position;
        delta.y = 0f;
        if (playerController != null && playerController.enabled)
            playerController.Move(delta);
        else
            body.position = clamped;
    }

    Vector2 ReadMoveInput()
    {
        if (moveProvider == null)
            return Vector2.zero;
        return moveProvider.leftHandMoveInput.ReadValue() + moveProvider.rightHandMoveInput.ReadValue();
    }
}
