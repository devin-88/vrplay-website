using System.Collections;
using Unity.XR.CoreUtils;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Fixed-duration PLAY session with first-interaction flags. No scores or goals.
/// When the timer ends: chime, fade music, fade to black, stop locomotion.
/// </summary>
public class PlaySession : MonoBehaviour
{
    public static PlaySession Instance { get; private set; }

    [Tooltip("Session length in seconds. The experience ends only when this elapses.")]
    public float sessionDuration = 600f;

    [Header("Soft Exit")]
    public float endChimeDelay = 0.15f;
    public float fadeOutDuration = 4.5f;
    public float musicFadeDuration = 5f;
    public Color fadeColor = Color.black;

    public bool hasPlayedEntryChime;

    public bool FirstPickupDone { get; private set; }
    public bool FirstThrowDone { get; private set; }
    public bool ShouldReturnFirstThrow { get; private set; }
    public bool TutorialOfferDone { get; set; }
    public bool IsEnding { get; private set; }
    public bool HasSoftExited { get; private set; }

    float startTime;
    Canvas fadeCanvas;
    Image fadeImage;
    Coroutine exitRoutine;

    public float Elapsed => Time.time - startTime;
    public float Remaining => Mathf.Max(0f, sessionDuration - Elapsed);
    public bool HasEnded => Elapsed >= sessionDuration;

    void Awake()
    {
        Instance = this;
        startTime = Time.time;
    }

    void Start()
    {
        startTime = Time.time;
        if (!hasPlayedEntryChime)
        {
            hasPlayedEntryChime = true;
            PlayAudio.Play(PlayAudio.Cue.EntryChime, transform.position);
        }
    }

    void Update()
    {
        if (!HasEnded || IsEnding)
            return;
        BeginSoftExit();
    }

    void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
    }

    public void NotifyFirstPickup()
    {
        if (FirstPickupDone)
            return;

        FirstPickupDone = true;
        PlayAudio.Play(PlayAudio.Cue.FirstPickupPing, transform.position);
    }

    public void NotifyFirstThrow()
    {
        if (FirstThrowDone)
            return;
        FirstThrowDone = true;
        ShouldReturnFirstThrow = true;
    }

    public bool ConsumeFirstThrowReturn()
    {
        if (!ShouldReturnFirstThrow)
            return false;
        ShouldReturnFirstThrow = false;
        return true;
    }

    public void BeginSoftExit()
    {
        if (IsEnding)
            return;
        IsEnding = true;
        if (exitRoutine != null)
            StopCoroutine(exitRoutine);
        exitRoutine = StartCoroutine(SoftExitRoutine());
    }

    IEnumerator SoftExitRoutine()
    {
        EnsureFadeOverlay();
        DisableLocomotion();

        if (endChimeDelay > 0f)
            yield return new WaitForSeconds(endChimeDelay);

        PlayAudio.Play(PlayAudio.Cue.SessionEndChime, transform.position);
        if (PlayAudio.Instance != null)
            PlayAudio.Instance.FadeOutLoops(musicFadeDuration);

        float duration = Mathf.Max(0.5f, fadeOutDuration);
        float t = 0f;
        while (t < duration)
        {
            t += Time.deltaTime;
            SetFadeAlpha(Mathf.SmoothStep(0f, 1f, Mathf.Clamp01(t / duration)));
            yield return null;
        }

        SetFadeAlpha(1f);
        HasSoftExited = true;
        PlayLog.Logger?.EndSession();
        exitRoutine = null;
    }

    void DisableLocomotion()
    {
        var comfort = FindFirstObjectByType<PlayComfortLocomotion>();
        if (comfort != null)
            comfort.enabled = false;

        var movers = FindObjectsByType<UnityEngine.XR.Interaction.Toolkit.Samples.StarterAssets.DynamicMoveProvider>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < movers.Length; i++)
        {
            if (movers[i] != null)
                movers[i].enabled = false;
        }

        var teleports = FindObjectsByType<UnityEngine.XR.Interaction.Toolkit.Locomotion.Teleportation.TeleportationProvider>(
            FindObjectsInactive.Include, FindObjectsSortMode.None);
        for (int i = 0; i < teleports.Length; i++)
        {
            if (teleports[i] != null)
                teleports[i].enabled = false;
        }
    }

    void EnsureFadeOverlay()
    {
        if (fadeImage != null)
            return;

        Camera cam = null;
        var origin = FindFirstObjectByType<XROrigin>();
        if (origin != null)
            cam = origin.Camera;
        if (cam == null)
            cam = Camera.main;

        var canvasGo = new GameObject("SessionEndFade");
        fadeCanvas = canvasGo.AddComponent<Canvas>();
        fadeCanvas.renderMode = RenderMode.ScreenSpaceCamera;
        fadeCanvas.worldCamera = cam;
        fadeCanvas.planeDistance = 0.2f;
        fadeCanvas.sortingOrder = short.MaxValue;

        var scaler = canvasGo.AddComponent<CanvasScaler>();
        scaler.uiScaleMode = CanvasScaler.ScaleMode.ScaleWithScreenSize;
        scaler.referenceResolution = new Vector2(1920f, 1080f);
        canvasGo.AddComponent<GraphicRaycaster>();

        var imageGo = new GameObject("Fade");
        imageGo.transform.SetParent(canvasGo.transform, false);
        fadeImage = imageGo.AddComponent<Image>();
        fadeImage.color = new Color(fadeColor.r, fadeColor.g, fadeColor.b, 0f);
        fadeImage.raycastTarget = true;

        var rect = fadeImage.rectTransform;
        rect.anchorMin = Vector2.zero;
        rect.anchorMax = Vector2.one;
        rect.offsetMin = Vector2.zero;
        rect.offsetMax = Vector2.zero;

        if (cam != null)
            canvasGo.transform.SetParent(cam.transform, false);
    }

    void SetFadeAlpha(float alpha)
    {
        if (fadeImage == null)
            return;
        Color c = fadeColor;
        c.a = Mathf.Clamp01(alpha);
        fadeImage.color = c;
    }
}
