#if UNITY_EDITOR
using UnityEditor;
using UnityEngine;

/// <summary>
/// Editor tools to diversify terrain trees and soften authored grass wind.
/// </summary>
public static class PlayTerrainEditorTools
{
    const string MenuRoot = "PLAY/Terrain/";

    [MenuItem(MenuRoot + "Diversify Terrain Trees")]
    public static void DiversifyTreesMenu()
    {
        var terrain = Terrain.activeTerrain;
        if (terrain == null)
            terrain = Object.FindFirstObjectByType<Terrain>();
        if (terrain == null || terrain.terrainData == null)
        {
            Debug.LogError("No Terrain found.");
            return;
        }

        int changed = DiversifyTrees(terrain.terrainData, seed: 18421);
        SoftenAuthoredGrassWind(terrain.terrainData);
        ApplyBaselineTerrainComponent(terrain);
        EditorUtility.SetDirty(terrain.terrainData);
        EditorUtility.SetDirty(terrain);
        AssetDatabase.SaveAssets();
        Debug.Log($"Diversified {changed} terrain trees and softened grass wind on '{terrain.terrainData.name}'.");
    }

    [MenuItem(MenuRoot + "Soften Grass Wind (authored)")]
    public static void SoftenGrassMenu()
    {
        var terrain = Terrain.activeTerrain;
        if (terrain == null)
            terrain = Object.FindFirstObjectByType<Terrain>();
        if (terrain == null || terrain.terrainData == null)
        {
            Debug.LogError("No Terrain found.");
            return;
        }

        SoftenAuthoredGrassWind(terrain.terrainData);
        ApplyBaselineTerrainComponent(terrain);
        EditorUtility.SetDirty(terrain.terrainData);
        EditorUtility.SetDirty(terrain);
        AssetDatabase.SaveAssets();
        Debug.Log($"Softened grass wind on '{terrain.terrainData.name}'.");
    }

    public static int DiversifyTrees(TerrainData data, int seed)
    {
        var trees = data.treeInstances;
        if (trees == null || trees.Length == 0)
            return 0;

        int protoCount = data.treePrototypes != null ? data.treePrototypes.Length : 0;
        if (protoCount <= 0)
            return 0;

        var rng = new System.Random(seed);
        int changed = 0;

        // Prefer underused prototypes so the forest is not one cloned mesh.
        int[] weights = new int[protoCount];
        for (int i = 0; i < protoCount; i++)
            weights[i] = 1;
        // CommonTree_1..5 — boost rarer ones when present.
        if (protoCount >= 5)
        {
            weights[0] = 3;
            weights[1] = 3;
            weights[2] = 3;
            weights[3] = 4;
            weights[4] = 4;
        }

        int weightSum = 0;
        for (int i = 0; i < weights.Length; i++)
            weightSum += weights[i];

        for (int i = 0; i < trees.Length; i++)
        {
            var t = trees[i];

            // Independent width/height so trunks don't look stamped.
            float height = Mathf.Lerp(0.72f, 1.65f, (float)rng.NextDouble());
            float width = height * Mathf.Lerp(0.78f, 1.22f, (float)rng.NextDouble());
            t.heightScale = height;
            t.widthScale = width;
            t.rotation = (float)(rng.NextDouble() * Mathf.PI * 2.0);

            // Re-roll prototype for ~55% of trees toward a more even mix.
            if (rng.NextDouble() < 0.55)
                t.prototypeIndex = PickWeighted(rng, weights, weightSum);

            // Tiny position jitter breaks grid feel without overlapping the clearing much.
            float jx = (float)(rng.NextDouble() * 2.0 - 1.0) * 0.012f;
            float jz = (float)(rng.NextDouble() * 2.0 - 1.0) * 0.012f;
            t.position = new Vector3(
                Mathf.Clamp01(t.position.x + jx),
                t.position.y,
                Mathf.Clamp01(t.position.z + jz));

            trees[i] = t;
            changed++;
        }

        data.SetTreeInstances(trees, true);
        return changed;
    }

    static int PickWeighted(System.Random rng, int[] weights, int sum)
    {
        int roll = rng.Next(sum);
        int acc = 0;
        for (int i = 0; i < weights.Length; i++)
        {
            acc += weights[i];
            if (roll < acc)
                return i;
        }

        return weights.Length - 1;
    }

    public static void SoftenAuthoredGrassWind(TerrainData data)
    {
        // Authored baseline for PC; PlayTerrainTuning lowers further in VR.
        data.wavingGrassStrength = 0.22f;
        data.wavingGrassSpeed = 0.35f;
        data.wavingGrassAmount = 0.12f;
    }

    public static void ApplyBaselineTerrainComponent(Terrain terrain)
    {
        terrain.detailObjectDistance = 70f;
        terrain.detailObjectDensity = 0.85f;
        terrain.drawInstanced = true;
        terrain.treeBillboardDistance = 50f;
        terrain.treeMaximumFullLODCount = 50;
        terrain.treeDistance = Mathf.Min(terrain.treeDistance, 120f);
        terrain.heightmapPixelError = Mathf.Max(terrain.heightmapPixelError, 8f);
    }
}
#endif
