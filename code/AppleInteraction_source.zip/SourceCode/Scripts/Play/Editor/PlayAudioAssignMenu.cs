using UnityEditor;
using UnityEngine;

public static class PlayAudioAssignMenu
{
    [MenuItem("PLAY/Audio/Auto-Assign Sound Clips")]
    public static void AssignAll()
    {
        var audio = Object.FindFirstObjectByType<PlayAudio>();
        if (audio == null)
        {
            var go = GameObject.Find("PlayEnvironment");
            if (go == null)
                go = new GameObject("PlayEnvironment");
            audio = go.GetComponent<PlayAudio>();
            if (audio == null)
                audio = go.AddComponent<PlayAudio>();
        }

        audio.AutoAssignClips();
        EditorUtility.SetDirty(audio);
        AssetDatabase.SaveAssets();
        Debug.Log("Assigned Sound clips on " + audio.name);
    }
}
