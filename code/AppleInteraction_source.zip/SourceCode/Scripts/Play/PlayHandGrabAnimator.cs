using UnityEngine;
using UnityEngine.XR;
using UnityEngine.XR.Interaction.Toolkit.Interactors;
using UnityEngine.XR.Interaction.Toolkit.Samples.StarterAssets;
using CommonUsages = UnityEngine.XR.CommonUsages;
using XRInputDevice = UnityEngine.XR.InputDevice;

/// <summary>
/// Drives Oculus hand Animator Grip/Trigger from controller axes.
/// Select is the trigger (grab) → fist via Grip. Activate/grip button → pinch via Trigger.
/// While holding an interactable, the fist stays closed.
/// </summary>
[DefaultExecutionOrder(40)]
[RequireComponent(typeof(Animator))]
public class PlayHandGrabAnimator : MonoBehaviour
{
    public Animator handAnimator;
    public XRNode handNode = XRNode.RightHand;
    public XRBaseInputInteractor interactor;

    [Range(0f, 1f)] public float heldGripFloor = 0.9f;
    public float smoothTime = 0.06f;

    static readonly int GripId = Animator.StringToHash("Grip");
    static readonly int TriggerId = Animator.StringToHash("Trigger");

    float gripVelocity;
    float triggerVelocity;
    float currentGrip;
    float currentTrigger;

    void Awake()
    {
        if (handAnimator == null)
            handAnimator = GetComponent<Animator>();
        if (handAnimator != null)
            handAnimator.enabled = true;

        // ControllerAnimator is for plastic controller meshes, not skeletal hands.
        var controllerAnimator = GetComponent<ControllerAnimator>();
        if (controllerAnimator != null)
            Destroy(controllerAnimator);

        if (interactor == null)
        {
            var controller = transform.parent;
            if (controller != null)
            {
                interactor = controller.GetComponentInChildren<NearFarInteractor>(true);
                if (interactor == null)
                    interactor = controller.GetComponentInChildren<XRBaseInputInteractor>(true);
            }
        }
    }

    void Update()
    {
        if (handAnimator == null || !handAnimator.enabled)
            return;

        float selectAxis = 0f;
        float activateAxis = 0f;
        XRInputDevice device = InputDevices.GetDeviceAtXRNode(handNode);
        if (device.isValid)
        {
            device.TryGetFeatureValue(CommonUsages.trigger, out selectAxis);
            device.TryGetFeatureValue(CommonUsages.grip, out activateAxis);
        }

        bool holding = interactor != null && interactor.hasSelection;
        float targetGrip = holding ? Mathf.Max(selectAxis, heldGripFloor) : selectAxis;
        float targetTrigger = activateAxis;

        currentGrip = Mathf.SmoothDamp(currentGrip, targetGrip, ref gripVelocity, smoothTime);
        currentTrigger = Mathf.SmoothDamp(currentTrigger, targetTrigger, ref triggerVelocity, smoothTime);

        handAnimator.SetFloat(GripId, Mathf.Clamp01(currentGrip));
        handAnimator.SetFloat(TriggerId, Mathf.Clamp01(currentTrigger));
    }
}
