using System;
using UnityEngine;

[Serializable]
public class HandSkinTone
{
    public string label = "Skin";
    public Material material;
    [Tooltip("Optional swatch preview. If alpha is 0, the material base color is used.")]
    public Color swatchColor = new Color(0f, 0f, 0f, 0f);
}

/// <summary>
/// Fixed set of hand skin materials shared by the tutorial swatches and play hands.
/// Edit labels / materials here — both the UI and models read from this asset.
/// </summary>
[CreateAssetMenu(fileName = "HandSkinPalette", menuName = "PLAY/Hand Skin Palette")]
public class HandSkinPalette : ScriptableObject
{
    public const int SlotCount = 12;

    [Tooltip("Exactly 12 slots (matches SkinStyle). Assign a Material per slot.")]
    public HandSkinTone[] tones = CreateDefaults();

    public int Count => SlotCount;

    void OnValidate()
    {
        EnsureSlotCount();
    }

    public void EnsureSlotCount()
    {
        if (tones != null && tones.Length == SlotCount)
            return;

        var defaults = CreateDefaults();
        var next = new HandSkinTone[SlotCount];
        for (int i = 0; i < SlotCount; i++)
        {
            if (tones != null && i < tones.Length && tones[i] != null)
            {
                next[i] = tones[i];
                if (string.IsNullOrWhiteSpace(next[i].label))
                    next[i].label = defaults[i].label;
            }
            else
            {
                next[i] = defaults[i];
            }
        }
        tones = next;
    }

    public HandSkinTone Get(int index)
    {
        EnsureSlotCount();
        index = Mathf.Clamp(index, 0, SlotCount - 1);
        return tones[index] ?? CreateDefaults()[index];
    }

    public Material GetMaterial(int index) => Get(index).material;

    public string GetLabel(int index)
    {
        var tone = Get(index);
        return string.IsNullOrWhiteSpace(tone.label) ? $"Tone {index + 1}" : tone.label;
    }

    public Color GetSwatchColor(int index)
    {
        var tone = Get(index);
        Color c = tone.swatchColor.a > 0.01f
            ? tone.swatchColor
            : SampleMaterialColor(tone.material, FallbackColor(index));
        c.a = 1f;
        return c;
    }

    public Material[] GetMaterials()
    {
        EnsureSlotCount();
        var mats = new Material[SlotCount];
        for (int i = 0; i < SlotCount; i++)
            mats[i] = tones[i] != null ? tones[i].material : null;
        return mats;
    }

    public static Color SampleMaterialColor(Material mat, Color fallback)
    {
        if (mat == null)
            return fallback;
        if (mat.HasProperty("_BaseColor"))
            return mat.GetColor("_BaseColor");
        if (mat.HasProperty("_Color"))
            return mat.GetColor("_Color");
        return mat.color;
    }

    static Color FallbackColor(int index)
    {
        var d = CreateDefaults();
        index = Mathf.Clamp(index, 0, d.Length - 1);
        return d[index].swatchColor.a > 0.01f ? d[index].swatchColor : new Color(0.92f, 0.68f, 0.50f, 1f);
    }

    public static HandSkinTone[] CreateDefaults()
    {
        return new[]
        {
            new HandSkinTone { label = "Porcelain",     swatchColor = new Color(1.00f, 0.88f, 0.80f, 1f) },
            new HandSkinTone { label = "Fair Rose",     swatchColor = new Color(0.99f, 0.82f, 0.76f, 1f) },
            new HandSkinTone { label = "Light Peach",   swatchColor = new Color(0.97f, 0.78f, 0.66f, 1f) },
            new HandSkinTone { label = "Warm Ivory",    swatchColor = new Color(0.95f, 0.74f, 0.58f, 1f) },
            new HandSkinTone { label = "Soft Beige",    swatchColor = new Color(0.92f, 0.68f, 0.50f, 1f) },
            new HandSkinTone { label = "Golden Sand",   swatchColor = new Color(0.88f, 0.62f, 0.40f, 1f) },
            new HandSkinTone { label = "Honey Tan",     swatchColor = new Color(0.82f, 0.54f, 0.32f, 1f) },
            new HandSkinTone { label = "Warm Olive",    swatchColor = new Color(0.74f, 0.52f, 0.34f, 1f) },
            new HandSkinTone { label = "Caramel",       swatchColor = new Color(0.66f, 0.42f, 0.26f, 1f) },
            new HandSkinTone { label = "Chestnut",      swatchColor = new Color(0.54f, 0.32f, 0.20f, 1f) },
            new HandSkinTone { label = "Rich Brown",    swatchColor = new Color(0.40f, 0.23f, 0.15f, 1f) },
            new HandSkinTone { label = "Deep Espresso", swatchColor = new Color(0.26f, 0.15f, 0.11f, 1f) },
        };
    }
}
