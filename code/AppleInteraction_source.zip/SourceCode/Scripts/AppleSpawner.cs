using UnityEngine;

/// <summary>
/// Meadow spawn-zone source. AppleManager owns the live population cap and refill.
/// </summary>
public class AppleSpawner : MonoBehaviour
{
    public GameObject applePrefab;
    public Transform[] spawnPoints;
    public int amount = 2;
    public Material[] appleMaterials;
    public float physicsDelay = 0.5f;

    void Start()
    {
        var manager = AppleManager.Instance;
        if (manager == null)
            manager = gameObject.AddComponent<AppleManager>();

        if (manager.applePrefab == null)
            manager.applePrefab = applePrefab;
        if (manager.spawnPoints == null || manager.spawnPoints.Length == 0)
            manager.spawnPoints = spawnPoints;
        if (manager.appleMaterials == null || manager.appleMaterials.Length == 0)
            manager.appleMaterials = appleMaterials;
        manager.physicsDelay = physicsDelay;

        int toSpawn = Mathf.Max(0, amount);
        for (int i = 0; i < toSpawn; i++)
            manager.SpawnApple();
    }
}
