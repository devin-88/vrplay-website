using UnityEngine;

/// <summary>
/// Weighted random action selection from the design document. Weights are floored at 0.05 then normalised.
/// </summary>
public static class SquirrelDecisions
{
    const float Floor = 0.05f;

    public static AppleAction ChooseAppleAction(SquirrelMemory memory, SquirrelSensors sensors, float holdingSeconds)
    {
        float offer = 0.4f;
        float evade = 0.3f;
        float drop = 0.15f;
        float throwApple = 0.15f;

        bool closeAndRecentChain = sensors.PlayerDistance < 3f && memory.ChainCompletedInLast(10f);
        bool farOrIdle = sensors.PlayerDistance > 8f || sensors.PlayerIdleFor(10f);

        if (closeAndRecentChain)
        {
            offer += 0.1f;
            evade += 0.05f;
            throwApple += 0.05f;
        }

        if (farOrIdle)
        {
            offer -= 0.1f;
            drop += 0.05f;
            throwApple += 0.05f;
        }

        if (memory.lastAppleAction == AppleAction.Evade)
        {
            evade -= 0.15f;
            offer += 0.1f;
            throwApple += 0.05f;
        }
        else if (memory.lastAppleAction == AppleAction.Offer)
        {
            offer -= 0.05f;
            evade += 0.05f;
            throwApple += 0.05f;
        }

        if (memory.JustCaughtApple)
        {
            evade += 0.10f;
            throwApple += 0.05f;
        }

        if (memory.playfulness > 0.7f)
        {
            evade += 0.05f;
            throwApple += 0.1f;
        }

        if (memory.tiredness > 0.7f)
        {
            evade -= 0.10f;
            offer += 0.05f;
            throwApple -= 0.10f;
        }

        if (holdingSeconds > 15f && !sensors.PlayerApproaching)
        {
            drop += 0.10f;
            offer += 0.05f;
            throwApple += 0.05f;
        }

        return Pick(
            new[] { AppleAction.Offer, AppleAction.Evade, AppleAction.Drop, AppleAction.Throw },
            new[] { offer, evade, drop, throwApple });
    }

    public static ThrownAtReaction ChooseThrownAtReaction(SquirrelMemory memory, SquirrelSensors sensors, bool holdingApple)
    {
        if (holdingApple)
        {
            return Pick(
                new[] { ThrownAtReaction.Dodge, ThrownAtReaction.Shocked, ThrownAtReaction.Taunt },
                new[] { 0.55f, 0.25f, 0.20f });
        }

        if (sensors != null && sensors.incomingIsHigh && memory != null && memory.playfulness > 0.45f)
        {
            return Pick(
                new[] { ThrownAtReaction.Catch, ThrownAtReaction.Dodge },
                new[] { 0.88f, 0.12f });
        }

        float catchWeight = 0.78f;
        float dodge = 0.10f;
        float shocked = 0.06f;
        float trip = 0.03f;
        float taunt = 0.03f;

        if (memory != null && memory.tiredness > 0.65f)
        {
            catchWeight -= 0.18f;
            shocked += 0.12f;
            dodge += 0.06f;
        }
        else if (memory != null && memory.playfulness > 0.7f)
        {
            catchWeight += 0.08f;
            trip += 0.04f;
        }

        return Pick(
            new[]
            {
                ThrownAtReaction.Catch,
                ThrownAtReaction.Dodge,
                ThrownAtReaction.Shocked,
                ThrownAtReaction.PlayfulTrip,
                ThrownAtReaction.Taunt
            },
            new[] { catchWeight, dodge, shocked, trip, taunt });
    }

    public static bool ChooseThrowWhileOnTree()
    {
        // On-tree: throw 0.7, drop 0.3
        return Random.value < 0.7f;
    }

    static T Pick<T>(T[] actions, float[] weights)
    {
        float total = 0f;
        for (int i = 0; i < weights.Length; i++)
        {
            weights[i] = Mathf.Max(Floor, weights[i]);
            total += weights[i];
        }

        float roll = Random.value * total;
        float cumulative = 0f;
        for (int i = 0; i < actions.Length; i++)
        {
            cumulative += weights[i];
            if (roll <= cumulative)
                return actions[i];
        }

        return actions[actions.Length - 1];
    }
}

public enum ThrownAtReaction
{
    Dodge,
    Catch,
    Shocked,
    PlayfulTrip,
    Taunt
}
