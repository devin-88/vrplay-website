using UnityEditor;
using UnityEditor.Animations;
using UnityEngine;

public static class RebuildSquirrelAnimator
{
    const string ControllerPath = "Assets/Models/Squirrel/SquirrellAnimator.controller";

    static readonly string[] LoopingClips =
    {
        "Assets/Models/Squirrel/AnimationsUpdate/Happy Idle.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Walking.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Jogging.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Sprint.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Idle Carry.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Walking Carry.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Run Carry.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Idle Carry2.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Jogging With Box.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Sprinting With Box.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/Climbing Ladder.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/waiting.fbx",
        "Assets/Models/Squirrel/AnimationsUpdate/waiting2.fbx"
    };

    [MenuItem("PLAY/Squirrel/Lock Locomotion Clips In Place")]
    public static void LockLocomotionClips()
    {
        for (int i = 0; i < LoopingClips.Length; i++)
            SetLoopInPlace(LoopingClips[i], true);

        AssetDatabase.SaveAssets();
        Debug.Log("Squirrel locomotion clips set to loop in place.");
    }

    [MenuItem("PLAY/Squirrel/Rebuild Dynamic Animator")]
    public static void RebuildDynamicAnimator()
    {
        LockLocomotionClips();
        BuildController();
        Debug.Log("Rebuilt dynamic squirrel animator.");
    }

    public static void BuildController()
    {
        var ac = AssetDatabase.LoadAssetAtPath<AnimatorController>(ControllerPath);
        if (ac == null)
        {
            Debug.LogError("Missing " + ControllerPath);
            return;
        }

        var leftovers = AssetDatabase.LoadAllAssetsAtPath(ControllerPath);
        for (int i = 0; i < leftovers.Length; i++)
        {
            if (leftovers[i] is BlendTree)
                Object.DestroyImmediate(leftovers[i], true);
        }

        var sm = ac.layers[0].stateMachine;
        var existing = sm.states;
        for (int i = existing.Length - 1; i >= 0; i--)
            sm.RemoveState(existing[i].state);
        var any = sm.anyStateTransitions;
        for (int i = any.Length - 1; i >= 0; i--)
            sm.RemoveAnyStateTransition(any[i]);
        for (int i = ac.parameters.Length - 1; i >= 0; i--)
            ac.RemoveParameter(i);

        ac.AddParameter("Speed", AnimatorControllerParameterType.Float);
        ac.AddParameter("Fidget", AnimatorControllerParameterType.Float);
        ac.AddParameter("HoldingApple", AnimatorControllerParameterType.Bool);
        ac.AddParameter("Climbing", AnimatorControllerParameterType.Bool);
        ac.AddParameter("Tired", AnimatorControllerParameterType.Bool);
        ac.AddParameter("Waiting", AnimatorControllerParameterType.Bool);
        string[] triggers =
        {
            "Catch", "SideCatch", "FarCatch", "Header", "Pickup",
            "Throw", "Throwing", "StrongThrow", "StopCarry",
            "Offer", "Cheer", "Jump", "Hit", "HitSide"
        };
        for (int i = 0; i < triggers.Length; i++)
            ac.AddParameter(triggers[i], AnimatorControllerParameterType.Trigger);

        var locoTree = MakeBlend(ac, "Locomotion", "Speed",
            Clip("Happy Idle.fbx"), 0f,
            Clip("Walking.fbx"), 0.8f,
            Clip("Jogging.fbx"), 1.8f,
            Clip("Sprint.fbx"), 3f);
        var carryTree = MakeBlend(ac, "Carry", "Speed",
            Clip("Idle Carry.fbx"), 0f,
            Clip("Walking Carry.fbx"), 0.8f,
            Clip("Run Carry.fbx"), 2.4f);
        var tiredTree = MakeBlend(ac, "TiredCarry", "Speed",
            Clip("Idle Carry2.fbx"), 0f,
            Clip("Jogging With Box.fbx"), 0.9f,
            Clip("Sprinting With Box.fbx"), 2.4f);
        var waitTree = MakeBlend(ac, "Wait", "Fidget",
            Clip("waiting.fbx"), 0f,
            Clip("waiting2.fbx"), 1f);

        var loco = sm.AddState("Locomotion", new Vector3(280, 80, 0));
        loco.motion = locoTree;
        var carry = sm.AddState("Carry", new Vector3(280, 180, 0));
        carry.motion = carryTree;
        var tired = sm.AddState("TiredCarry", new Vector3(280, 280, 0));
        tired.motion = tiredTree;
        var stop = sm.AddState("CarryStop", new Vector3(40, 280, 0));
        stop.motion = Clip("Walk to stop Carry.fbx");
        var wait = sm.AddState("Wait", new Vector3(40, 80, 0));
        wait.motion = waitTree;
        var climb = sm.AddState("Climb", new Vector3(40, 180, 0));
        climb.motion = Clip("Climbing Ladder.fbx");

        var catchSt = AddShot(sm, "Catch", "catch.fbx", 560, 0);
        var side = AddShot(sm, "SideCatch", "side catch.fbx", 760, 0);
        var far = AddShot(sm, "FarCatch", "far catch.fbx", 560, 70);
        var header = AddShot(sm, "Header", "Soccer Header.fbx", 760, 70);
        var pickup = AddShot(sm, "Pickup", "Pick up.fbx", 560, 140);
        var throwSt = AddShot(sm, "Throw", "Throw.fbx", 760, 140);
        var throwing = AddShot(sm, "Throwing", "Throwing.fbx", 560, 210);
        var strong = AddShot(sm, "StrongThrow", "Strong Throw.fbx", 760, 210);
        var offer = AddShot(sm, "Offer", "Waving.fbx", 560, 280);
        var cheer = AddShot(sm, "Cheer", "Cheering.fbx", 760, 280);
        var jump = AddShot(sm, "Jump", "Joyful Jump.fbx", 560, 350);
        var hit = AddShot(sm, "Hit", "Hit On The Back.fbx", 760, 350);
        var hitSide = AddShot(sm, "HitSide", "Hit On Side Of Head.fbx", 560, 420);

        sm.defaultState = loco;

        BoolTrans(loco, carry, "HoldingApple", true);
        loco.transitions[loco.transitions.Length - 1].AddCondition(AnimatorConditionMode.IfNot, 0, "Tired");
        BoolTrans(loco, tired, "HoldingApple", true);
        loco.transitions[loco.transitions.Length - 1].AddCondition(AnimatorConditionMode.If, 0, "Tired");
        BoolTrans(carry, loco, "HoldingApple", false);
        BoolTrans(tired, loco, "HoldingApple", false);
        BoolTrans(carry, tired, "Tired", true);
        BoolTrans(tired, carry, "Tired", false);
        BoolTrans(loco, wait, "Waiting", true);
        BoolTrans(wait, loco, "Waiting", false);
        var waitMove = wait.AddTransition(loco);
        waitMove.hasExitTime = false;
        waitMove.duration = 0.15f;
        waitMove.AddCondition(AnimatorConditionMode.Greater, 0.22f, "Speed");

        AnyTrigger(sm, catchSt, "Catch");
        AnyTrigger(sm, side, "SideCatch");
        AnyTrigger(sm, far, "FarCatch");
        AnyTrigger(sm, header, "Header");
        AnyTrigger(sm, pickup, "Pickup");
        AnyTrigger(sm, throwSt, "Throw");
        AnyTrigger(sm, throwing, "Throwing");
        AnyTrigger(sm, strong, "StrongThrow");
        AnyTrigger(sm, offer, "Offer");
        AnyTrigger(sm, cheer, "Cheer");
        AnyTrigger(sm, jump, "Jump");
        AnyTrigger(sm, hit, "Hit");
        AnyTrigger(sm, hitSide, "HitSide");
        AnyTrigger(sm, stop, "StopCarry");
        AnyBool(sm, climb, "Climbing", true);

        ExitHold(catchSt, loco, carry, tired, 0.82f);
        ExitHold(side, loco, carry, tired, 0.88f);
        ExitHold(far, loco, carry, tired, 0.88f);
        ExitHold(header, loco, carry, tired, 0.86f);
        ExitHold(pickup, loco, carry, tired, 0.88f);
        ExitHold(throwSt, loco, carry, tired, 0.88f);
        ExitHold(throwing, loco, carry, tired, 0.88f);
        ExitHold(strong, loco, carry, tired, 0.88f);
        ExitHold(offer, loco, carry, tired, 0.9f);
        ExitHold(cheer, loco, carry, tired, 0.9f);
        ExitHold(jump, loco, carry, tired, 0.88f);
        ExitHold(hit, loco, carry, tired, 0.88f);
        ExitHold(hitSide, loco, carry, tired, 0.88f);
        ExitHold(stop, loco, carry, tired, 0.9f);

        BoolTrans(climb, loco, "Climbing", false);
        climb.transitions[0].AddCondition(AnimatorConditionMode.IfNot, 0, "HoldingApple");
        BoolTrans(climb, carry, "Climbing", false);
        climb.transitions[1].AddCondition(AnimatorConditionMode.If, 0, "HoldingApple");
        climb.transitions[1].AddCondition(AnimatorConditionMode.IfNot, 0, "Tired");
        BoolTrans(climb, tired, "Climbing", false);
        climb.transitions[2].AddCondition(AnimatorConditionMode.If, 0, "HoldingApple");
        climb.transitions[2].AddCondition(AnimatorConditionMode.If, 0, "Tired");

        EditorUtility.SetDirty(ac);
        AssetDatabase.SaveAssets();
    }

    static AnimatorState AddShot(AnimatorStateMachine sm, string name, string file, float x, float y)
    {
        var state = sm.AddState(name, new Vector3(x, y, 0));
        state.motion = Clip(file);
        return state;
    }

    static BlendTree MakeBlend(AnimatorController ac, string name, string param, params object[] clipsAndThresholds)
    {
        var tree = new BlendTree
        {
            name = name,
            blendType = BlendTreeType.Simple1D,
            blendParameter = param,
            useAutomaticThresholds = false
        };
        for (int i = 0; i < clipsAndThresholds.Length; i += 2)
            tree.AddChild((Motion)clipsAndThresholds[i], (float)clipsAndThresholds[i + 1]);
        AssetDatabase.AddObjectToAsset(tree, ac);
        return tree;
    }

    static AnimationClip Clip(string fileName)
    {
        string path = "Assets/Models/Squirrel/AnimationsUpdate/" + fileName;
        var assets = AssetDatabase.LoadAllAssetsAtPath(path);
        for (int i = 0; i < assets.Length; i++)
        {
            var clip = assets[i] as AnimationClip;
            if (clip != null && !clip.name.StartsWith("__preview"))
                return clip;
        }

        Debug.LogWarning("Missing clip " + path);
        return null;
    }

    static void SetLoopInPlace(string path, bool loop)
    {
        var importer = AssetImporter.GetAtPath(path) as ModelImporter;
        if (importer == null)
            return;
        var clips = importer.clipAnimations;
        if (clips == null || clips.Length == 0)
            clips = importer.defaultClipAnimations;
        for (int i = 0; i < clips.Length; i++)
        {
            clips[i].loopTime = loop;
            clips[i].loopPose = loop;
            clips[i].lockRootRotation = true;
            clips[i].lockRootHeightY = true;
            clips[i].lockRootPositionXZ = true;
        }

        importer.clipAnimations = clips;
        importer.SaveAndReimport();
    }

    static void AnyTrigger(AnimatorStateMachine sm, AnimatorState dst, string trigger)
    {
        var t = sm.AddAnyStateTransition(dst);
        t.hasExitTime = false;
        t.duration = 0.12f;
        t.canTransitionToSelf = false;
        t.AddCondition(AnimatorConditionMode.If, 0, trigger);
    }

    static void AnyBool(AnimatorStateMachine sm, AnimatorState dst, string param, bool value)
    {
        var t = sm.AddAnyStateTransition(dst);
        t.hasExitTime = false;
        t.duration = 0.15f;
        t.canTransitionToSelf = false;
        t.AddCondition(value ? AnimatorConditionMode.If : AnimatorConditionMode.IfNot, 0, param);
    }

    static void BoolTrans(AnimatorState from, AnimatorState to, string param, bool value)
    {
        var t = from.AddTransition(to);
        t.hasExitTime = false;
        t.duration = 0.15f;
        t.AddCondition(value ? AnimatorConditionMode.If : AnimatorConditionMode.IfNot, 0, param);
    }

    static void ExitHold(AnimatorState from, AnimatorState loco, AnimatorState carry, AnimatorState tired, float exitTime)
    {
        var a = from.AddTransition(loco);
        a.hasExitTime = true;
        a.exitTime = exitTime;
        a.duration = 0.15f;
        a.AddCondition(AnimatorConditionMode.IfNot, 0, "HoldingApple");

        var b = from.AddTransition(tired);
        b.hasExitTime = true;
        b.exitTime = exitTime;
        b.duration = 0.15f;
        b.AddCondition(AnimatorConditionMode.If, 0, "HoldingApple");
        b.AddCondition(AnimatorConditionMode.If, 0, "Tired");

        var c = from.AddTransition(carry);
        c.hasExitTime = true;
        c.exitTime = exitTime;
        c.duration = 0.15f;
        c.AddCondition(AnimatorConditionMode.If, 0, "HoldingApple");
        c.AddCondition(AnimatorConditionMode.IfNot, 0, "Tired");
    }
}
