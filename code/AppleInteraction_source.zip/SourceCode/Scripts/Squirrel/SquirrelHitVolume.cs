using UnityEngine;

public class SquirrelHitVolume : MonoBehaviour
{
    public SquirrelFSM squirrel;

    void OnTriggerEnter(Collider other)
    {
        if (squirrel == null || squirrel.sensors == null)
            return;

        var apple = other.GetComponentInParent<AppleItem>();
        if (apple == null || apple.IsHeldByNpc || apple.IsHeldByPlayer)
            return;

        var body = apple.Body;
        if (body != null && body.linearVelocity.sqrMagnitude > 0.25f)
            squirrel.sensors.NotifyAppleCollision(apple);
    }
}
