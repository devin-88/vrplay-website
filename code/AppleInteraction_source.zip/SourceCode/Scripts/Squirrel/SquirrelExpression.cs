using UnityEngine;

/// <summary>
/// Swaps the squirrel eye and mouth albedo textures to match mood, gaze, and blinks.
/// </summary>
public class SquirrelExpression : MonoBehaviour
{
    public enum Eye
    {
        Default = 0,
        Tired = 1,
        Peaceful = 2,
        Angry = 3,
        Sad = 4,
        HappyClosed = 5,
        Shocked = 6,
        Pain = 7,
        LookLeft = 8,
        LookLeftSoft = 9,
        LookRight = 10,
        LookRightSoft = 11,
        LookUp = 12,
        LookUpSoft = 13,
        LookDown = 14,
        LookDownSoft = 15
    }

    public enum Mouth
    {
        Happy = 0,
        HappySlight = 1,
        HappyOpen = 2,
        Neutral = 3,
        NeutralSlight = 4,
        NeutralOpen = 5,
        Sad = 6,
        SurpriseSlight = 7,
        SurpriseOpen = 8
    }

    public SquirrelFSM squirrel;
    public Renderer eyeRenderer;
    public Renderer mouthRenderer;
    public Texture2D[] eyeTextures = new Texture2D[16];
    public Texture2D[] mouthTextures = new Texture2D[9];

    static readonly int BaseMapId = Shader.PropertyToID("_BaseMap");
    static readonly int MainTexId = Shader.PropertyToID("_MainTex");

    MaterialPropertyBlock eyeBlock;
    MaterialPropertyBlock mouthBlock;

    Eye currentEye = Eye.Default;
    Mouth currentMouth = Mouth.Happy;
    float nextBlinkAt;
    float blinkUntil;
    bool blinking;

    void Awake()
    {
        if (squirrel == null)
            squirrel = GetComponent<SquirrelFSM>();
        if (eyeRenderer == null)
            eyeRenderer = FindRenderer("Body__mEye");
        if (mouthRenderer == null)
            mouthRenderer = FindRenderer("Body__mMouth");
        if (eyeBlock == null)
            eyeBlock = new MaterialPropertyBlock();
        if (mouthBlock == null)
            mouthBlock = new MaterialPropertyBlock();
#if UNITY_EDITOR
        if (!HasTextures())
            LoadExpressionTextures();
#endif
        ScheduleBlink();
        Apply(Eye.Default, Mouth.Happy);
    }

#if UNITY_EDITOR
    [ContextMenu("Load Expression Textures")]
    public void LoadExpressionTextures()
    {
        eyeTextures = new Texture2D[16];
        for (int i = 0; i < eyeTextures.Length; i++)
            eyeTextures[i] = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>(
                "Assets/Models/Squirrel/mEye_Alb." + i + ".png");

        mouthTextures = new Texture2D[9];
        for (int i = 0; i < mouthTextures.Length; i++)
            mouthTextures[i] = UnityEditor.AssetDatabase.LoadAssetAtPath<Texture2D>(
                "Assets/Models/Squirrel/mMouth_Alb." + i + ".png");
    }
#endif

    bool HasTextures()
    {
        return eyeTextures != null && eyeTextures.Length > 6 && eyeTextures[0] != null &&
               mouthTextures != null && mouthTextures.Length > 3 && mouthTextures[0] != null;
    }

    void LateUpdate()
    {
        ChooseExpression(out Eye eye, out Mouth mouth);
        UpdateBlink(ref eye);
        if (eye != currentEye || mouth != currentMouth)
            Apply(eye, mouth);
    }

    public void Apply(Eye eye, Mouth mouth)
    {
        currentEye = eye;
        currentMouth = mouth;
        SetTexture(eyeRenderer, eyeBlock, GetEye((int)eye));
        SetTexture(mouthRenderer, mouthBlock, GetMouth((int)mouth));
    }

    void ChooseExpression(out Eye eye, out Mouth mouth)
    {
        eye = Eye.Default;
        mouth = Mouth.Happy;
        if (squirrel == null)
            return;

        var memory = squirrel.memory;
        bool tired = memory != null && memory.tiredness > 0.55f;
        bool sad = memory != null && memory.playfulness < 0.35f;
        bool playful = memory != null && memory.playfulness > 0.7f;
        State state = squirrel.currentState;

        if (state is EndState)
        {
            eye = tired ? Eye.Peaceful : Eye.HappyClosed;
            mouth = Mouth.Happy;
            return;
        }

        if (state is SurpriseState)
        {
            eye = Eye.Shocked;
            mouth = Mouth.SurpriseOpen;
            return;
        }

        if (state is ThrownAtReactState thrown)
        {
            switch (thrown.Reaction)
            {
                case ThrownAtReaction.Catch:
                    eye = squirrel.sensors != null && squirrel.sensors.incomingIsHigh
                        ? Eye.LookUp
                        : Eye.HappyClosed;
                    mouth = Mouth.HappyOpen;
                    break;
                case ThrownAtReaction.Shocked:
                    eye = Eye.Shocked;
                    mouth = Mouth.SurpriseOpen;
                    break;
                case ThrownAtReaction.PlayfulTrip:
                    eye = Eye.Pain;
                    mouth = Mouth.NeutralOpen;
                    break;
                case ThrownAtReaction.Taunt:
                    eye = Eye.Angry;
                    mouth = Mouth.HappyOpen;
                    break;
                default:
                    eye = Eye.Shocked;
                    mouth = Mouth.SurpriseSlight;
                    break;
            }
            return;
        }

        if (state is ThrowAppleState)
        {
            eye = Eye.Default;
            mouth = Mouth.HappyOpen;
            return;
        }

        if (state is DropAppleState)
        {
            eye = tired ? Eye.Tired : Eye.Default;
            mouth = Mouth.Neutral;
            return;
        }

        if (state is EvadeState)
        {
            eye = playful ? Eye.Angry : LookTowardPlayer(tired);
            mouth = Mouth.HappySlight;
            return;
        }

        if (state is ChaseAppleState || state is RetrieveAppleState)
        {
            eye = Eye.Default;
            mouth = Mouth.HappySlight;
            return;
        }

        if (state is OfferAppleState)
        {
            eye = sad ? Eye.Sad : LookTowardPlayer(false);
            mouth = sad ? Mouth.Sad : Mouth.HappyOpen;
            return;
        }

        if (state is HoldAppleState)
        {
            eye = Eye.HappyClosed;
            mouth = Mouth.Happy;
            return;
        }

        if (state is OnTreeState)
        {
            if (squirrel.IsClimbingTree)
            {
                eye = Eye.LookUp;
                mouth = Mouth.NeutralSlight;
            }
            else
            {
                eye = Eye.HappyClosed;
                mouth = Mouth.HappySlight;
            }
            return;
        }

        if (state is WatchingState)
        {
            if (squirrel.sensors != null && squirrel.sensors.PlayerIsClimbing())
                eye = tired ? Eye.LookUpSoft : Eye.LookUp;
            else
                eye = LookTowardPlayer(tired);
            mouth = Mouth.NeutralSlight;
            return;
        }

        if (tired)
        {
            eye = Eye.Tired;
            mouth = Mouth.Neutral;
        }
        else if (sad)
        {
            eye = Eye.Sad;
            mouth = Mouth.Sad;
        }
        else
        {
            eye = LookTowardPlayer(false);
            mouth = Mouth.Happy;
        }
    }

    Eye LookTowardPlayer(bool soft)
    {
        if (squirrel == null || squirrel.sensors == null || squirrel.sensors.player == null)
            return soft ? Eye.Tired : Eye.Default;

        Vector3 local = squirrel.transform.InverseTransformPoint(squirrel.sensors.player.position);
        float absX = Mathf.Abs(local.x);
        float absY = Mathf.Abs(local.y - 0.8f);
        const float threshold = 0.45f;

        if (local.y - 0.8f > threshold && local.y - 0.8f >= absX)
            return soft ? Eye.LookUpSoft : Eye.LookUp;
        if (0.8f - local.y > threshold && 0.8f - local.y >= absX)
            return soft ? Eye.LookDownSoft : Eye.LookDown;
        if (absX > threshold && absX >= absY)
        {
            if (local.x > 0f)
                return soft ? Eye.LookRightSoft : Eye.LookRight;
            return soft ? Eye.LookLeftSoft : Eye.LookLeft;
        }

        return soft ? Eye.Tired : Eye.Default;
    }

    void UpdateBlink(ref Eye eye)
    {
        bool alreadyClosed = eye == Eye.Peaceful || eye == Eye.HappyClosed || eye == Eye.Pain;
        if (alreadyClosed)
        {
            blinking = false;
            return;
        }

        if (!blinking && Time.time >= nextBlinkAt)
        {
            blinking = true;
            blinkUntil = Time.time + 0.12f;
        }

        if (blinking)
        {
            if (Time.time <= blinkUntil)
                eye = Eye.Peaceful;
            else
            {
                blinking = false;
                ScheduleBlink();
            }
        }
    }

    void ScheduleBlink()
    {
        nextBlinkAt = Time.time + Random.Range(2.2f, 5.5f);
    }

    Texture2D GetEye(int index)
    {
        if (eyeTextures == null || index < 0 || index >= eyeTextures.Length)
            return null;
        return eyeTextures[index];
    }

    Texture2D GetMouth(int index)
    {
        if (mouthTextures == null || index < 0 || index >= mouthTextures.Length)
            return null;
        return mouthTextures[index];
    }

    static void SetTexture(Renderer renderer, MaterialPropertyBlock block, Texture2D texture)
    {
        if (renderer == null || texture == null)
            return;
        if (block == null)
            return;
        renderer.GetPropertyBlock(block);
        block.SetTexture(BaseMapId, texture);
        block.SetTexture(MainTexId, texture);
        renderer.SetPropertyBlock(block);
    }

    Renderer FindRenderer(string objectName)
    {
        var renderers = GetComponentsInChildren<Renderer>(true);
        for (int i = 0; i < renderers.Length; i++)
        {
            if (renderers[i] != null && renderers[i].name == objectName)
                return renderers[i];
        }
        return null;
    }
}
