using System.Collections.Generic;
using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

/// <summary>
/// Shared woven basket: player and NPC can carry it, fill it, catch apples, and overturn it.
/// </summary>
[RequireComponent(typeof(Rigidbody))]
[RequireComponent(typeof(XRGrabInteractable))]
public class PlayBasket : MonoBehaviour
{
    public static PlayBasket Instance { get; private set; }

    public float overturnAngle = 120f;
    public float outOfBoundsDistance = 20f;
    public float respawnDelay = 10f;
    public float catchRadius = 0.5f;

    Rigidbody body;
    XRGrabInteractable grab;
    Vector3 spawnPosition;
    Quaternion spawnRotation;
    readonly List<AppleItem> contents = new List<AppleItem>();
    bool heldByPlayer;
    bool heldByNpc;
    bool waitingToRespawn;
    float respawnAt;
    float lastUprightTime;

    public int ContainedAppleCount
    {
        get
        {
            contents.RemoveAll(a => a == null);
            return contents.Count;
        }
    }

    public bool IsHeld => heldByPlayer || heldByNpc;
    public bool IsHeldByNpc => heldByNpc;
    public XRGrabInteractable Grab => grab;
    public Rigidbody Body => body;

    void Awake()
    {
        Instance = this;
        body = GetComponent<Rigidbody>();
        grab = GetComponent<XRGrabInteractable>();
        spawnPosition = transform.position;
        spawnRotation = transform.rotation;
        lastUprightTime = Time.time;

        grab.selectEntered.AddListener(OnGrab);
        grab.selectExited.AddListener(OnRelease);
    }

    void OnDestroy()
    {
        if (Instance == this)
            Instance = null;
        if (grab != null)
        {
            grab.selectEntered.RemoveListener(OnGrab);
            grab.selectExited.RemoveListener(OnRelease);
        }
    }

    void Update()
    {
        if (waitingToRespawn && Time.time >= respawnAt)
            Respawn();

        if (IsOverturned())
            Spill();

        if (!IsHeld && IsOutOfBounds() && !waitingToRespawn)
        {
            waitingToRespawn = true;
            respawnAt = Time.time + respawnDelay;
        }

        CaptureNearbyApples();
    }

    void OnGrab(SelectEnterEventArgs args)
    {
        heldByPlayer = true;
        waitingToRespawn = false;
        PlayAudio.Play(PlayAudio.Cue.BasketRustle, transform.position);
        PlayWorld.Instance?.PulseHaptics(0.3f, 0.08f);
    }

    void OnRelease(SelectExitEventArgs args)
    {
        heldByPlayer = false;
    }

    public void PrepareForNpcCarry()
    {
        heldByNpc = true;
        heldByPlayer = false;
        waitingToRespawn = false;
        if (body != null)
        {
            body.linearVelocity = Vector3.zero;
            body.angularVelocity = Vector3.zero;
            body.useGravity = false;
            body.isKinematic = true;
        }

        if (grab != null)
            grab.enabled = false;
    }

    public void RestoreAsLoose()
    {
        heldByNpc = false;
        if (body != null)
        {
            body.isKinematic = false;
            body.useGravity = true;
        }

        if (grab != null)
            grab.enabled = true;
    }

    public bool TryCatch(AppleItem apple)
    {
        if (apple == null || contents.Contains(apple) || apple.IsHeldByPlayer || apple.IsHeldByNpc)
            return false;

        contents.Add(apple);
        apple.SetContainingBasket(this);
        SnapAppleIntoBasket(apple);
        PlayAudio.Play(PlayAudio.Cue.BasketCatch, transform.position);
        return true;
    }

    public void ReleaseApple(AppleItem apple)
    {
        contents.Remove(apple);
    }

    public void Spill()
    {
        contents.RemoveAll(a => a == null);
        if (contents.Count == 0)
            return;

        var spilled = contents.ToArray();
        contents.Clear();
        for (int i = 0; i < spilled.Length; i++)
        {
            var apple = spilled[i];
            if (apple == null)
                continue;
            apple.SetContainingBasket(null);
            apple.RestoreAsLoose();
            if (apple.Body != null)
            {
                apple.Body.linearVelocity = Random.insideUnitSphere + Vector3.up;
            }
        }

        PlayAudio.Play(PlayAudio.Cue.BasketOverturn, transform.position);

        var squirrel = FindFirstObjectByType<SquirrelFSM>();
        if (squirrel != null && PlayWorld.Instance != null &&
            PlayWorld.Instance.PlayerDistanceTo(squirrel.transform.position) < 5f)
        {
            squirrel.ReactToSurprise();
        }
    }

    public void SetSpawnPoint(Vector3 position, Quaternion rotation)
    {
        spawnPosition = position;
        spawnRotation = rotation;
    }

    bool IsOverturned()
    {
        float angle = Vector3.Angle(transform.up, Vector3.up);
        if (angle < overturnAngle)
        {
            lastUprightTime = Time.time;
            return false;
        }

        return Time.time - lastUprightTime > 0.15f;
    }

    bool IsOutOfBounds()
    {
        if (PlayWorld.Instance == null)
            return false;
        return PlayWorld.Instance.DistanceFromCenter(transform.position) > outOfBoundsDistance ||
               transform.position.y < PlayWorld.Instance.Center.y - 4f;
    }

    void Respawn()
    {
        waitingToRespawn = false;
        Spill();
        transform.SetPositionAndRotation(spawnPosition, spawnRotation);
        if (body != null)
        {
            body.linearVelocity = Vector3.zero;
            body.angularVelocity = Vector3.zero;
        }
    }

    void CaptureNearbyApples()
    {
        if (AppleManager.Instance == null)
            return;

        var apples = AppleManager.Instance.AllApples();
        for (int i = 0; i < apples.Count; i++)
        {
            var apple = apples[i];
            if (apple == null || !apple.IsLoose)
                continue;

            if (Vector3.Distance(apple.transform.position, transform.position + transform.up * 0.15f) <= catchRadius)
                TryCatch(apple);
        }
    }

    void SnapAppleIntoBasket(AppleItem apple)
    {
        if (apple.Body != null)
        {
            apple.Body.linearVelocity = Vector3.zero;
            apple.Body.angularVelocity = Vector3.zero;
            apple.Body.isKinematic = true;
            apple.Body.useGravity = false;
        }

        apple.transform.SetParent(transform, true);
        apple.transform.localPosition = Vector3.up * (0.08f + contents.Count * 0.05f);
        apple.transform.localRotation = Random.rotation;
    }
}
