using UnityEngine;
using UnityEngine.XR.Interaction.Toolkit;
using UnityEngine.XR.Interaction.Toolkit.Interactables;

public class HangingApple : MonoBehaviour
{
    Rigidbody rb;
    XRGrabInteractable grab;
    HangingAppleSpin spin;
    Renderer appleRenderer;
    Vector3 originalScale;

    void Awake()
    {
        originalScale = transform.localScale;
        rb = GetComponent<Rigidbody>();
        grab = GetComponent<XRGrabInteractable>();
        spin = GetComponent<HangingAppleSpin>();
        appleRenderer = GetComponent<Renderer>();

        if (GetComponent<AppleItem>() == null)
            gameObject.AddComponent<AppleItem>();
        if (GetComponent<AppleImpact>() == null)
            gameObject.AddComponent<AppleImpact>();

        if (grab != null)
        {
            grab.selectEntered.AddListener(OnGrab);
            grab.selectExited.AddListener(OnRelease);
        }
    }

    void OnDestroy()
    {
        if (grab != null)
        {
            grab.selectEntered.RemoveListener(OnGrab);
            grab.selectExited.RemoveListener(OnRelease);
        }
    }

    void OnGrab(SelectEnterEventArgs args)
    {
        if (spin != null)
            Destroy(spin);

        if (rb != null)
        {
            rb.isKinematic = false;
            rb.useGravity = true;
        }
    }

    void OnRelease(SelectExitEventArgs args)
    {
        if (rb != null)
        {
            rb.isKinematic = false;
            rb.useGravity = true;
            rb.angularVelocity = Vector3.zero;
        }
    }

    public void RestoreScale()
    {
        transform.localScale = originalScale;
    }

    public void SetColour(Material material)
    {
        if (appleRenderer == null)
            appleRenderer = GetComponent<Renderer>();
        if (appleRenderer != null && material != null)
            appleRenderer.material = material;
    }
}
