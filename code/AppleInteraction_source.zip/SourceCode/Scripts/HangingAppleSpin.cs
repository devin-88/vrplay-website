using UnityEngine;


public class HangingAppleSpin : MonoBehaviour
{

    float speed;


    void Start()
    {
        speed = Random.Range(5f, 15f);
    }


    void Update()
    {

        transform.Rotate(
            Vector3.up,
            speed * Time.deltaTime,
            Space.World
        );

    }
}